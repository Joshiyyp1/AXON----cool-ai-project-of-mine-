"""A lock so two training runs can never write the same checkpoint at once.

Running `train.py` twice against one checkpoint used to be silently allowed:
both processes load the same weights, train separately, and then overwrite each
other's saves. The result is unpredictable and wastes the whole run. This module
puts a small lock file next to the checkpoint, holding the pid of the process
that owns it.
"""
from __future__ import annotations

import json
import os
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Optional


def _process_alive(pid: int) -> bool:
    """Is this pid still running? (os.kill is unsafe on Windows.)"""
    if pid <= 0:
        return False
    if sys.platform == "win32":
        import ctypes

        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        handle = ctypes.windll.kernel32.OpenProcess(
            PROCESS_QUERY_LIMITED_INFORMATION, False, pid
        )
        if not handle:
            return False
        exit_code = ctypes.c_ulong()
        ok = ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code))
        ctypes.windll.kernel32.CloseHandle(handle)
        STILL_ACTIVE = 259
        return bool(ok) and exit_code.value == STILL_ACTIVE
    try:
        os.kill(pid, 0)
    except (ProcessLookupError, ValueError):
        return False
    except PermissionError:
        return True
    return True


class CheckpointBusy(RuntimeError):
    """Raised when another process already owns this checkpoint."""


class CheckpointLock:
    """Advisory lock on one checkpoint path."""

    def __init__(self, checkpoint: str | Path, stale_after: float = 24 * 3600) -> None:
        self.checkpoint = Path(checkpoint)
        self.path = self.checkpoint.with_suffix(self.checkpoint.suffix + ".lock")
        self.stale_after = stale_after
        self._held = False

    def owner(self) -> Optional[dict]:
        """Who holds this lock, if anyone still does."""
        if not self.path.exists():
            return None
        try:
            info = json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None
        pid = int(info.get("pid", -1))
        if not _process_alive(pid):
            return None
        if time.time() - float(info.get("started", 0)) > self.stale_after:
            return None
        return info

    def acquire(self) -> "CheckpointLock":
        held_by = self.owner()
        if held_by is not None:
            raise CheckpointBusy(
                f"{self.checkpoint.name} is already being trained by process "
                f"{held_by.get('pid')} (started "
                f"{time.strftime('%H:%M', time.localtime(held_by.get('started', 0)))}). "
                "Stop that run first, or train to a different --checkpoint."
            )
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps({"pid": os.getpid(), "started": time.time(),
                        "argv": " ".join(sys.argv[:3])}),
            encoding="utf-8",
        )
        self._held = True
        return self

    def release(self) -> None:
        if not self._held:
            return
        try:
            self.path.unlink(missing_ok=True)
        except OSError:
            pass
        self._held = False

    def __enter__(self) -> "CheckpointLock":
        return self.acquire()

    def __exit__(self, *exc) -> None:
        self.release()


@contextmanager
def checkpoint_lock(checkpoint: Optional[str | Path]):
    """Hold the lock for a checkpoint, or do nothing when there isn't one."""
    if checkpoint is None:
        yield None
        return
    lock = CheckpointLock(checkpoint)
    try:
        lock.acquire()
        yield lock
    finally:
        lock.release()
