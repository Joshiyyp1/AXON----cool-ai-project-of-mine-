"""AXON - Adaptive eXperimental Online Network.

A fully local, from-scratch conversational AI:
  * byte-level BPE tokenizer  (axon.tokenizer)
  * decoder-only Transformer  (axon.model)
  * SQLite long-term memory   (axon.memory)
  * training / fine-tuning    (axon.trainer)
  * high level orchestration  (axon.engine)

No API keys. No network calls. No cloud services.
"""

__version__ = "1.0.0"

from axon.config import ModelConfig, TrainConfig, GenerationConfig, Paths  # noqa: F401

__all__ = ["ModelConfig", "TrainConfig", "GenerationConfig", "Paths", "__version__"]
