"""Local accounts: sign up, sign in, and keep people's chats apart.

Everything here is on this computer. There is no server, no email, nothing to
pay for and nothing to sign up to online. An account is a row in the same
SQLite file the rest of AXON uses, with the password stored as a scrypt hash.

What an account gets you:
  * your own conversations - other people on this computer cannot see them
  * your own long-term memory (the facts AXON remembers about you)
  * your own settings

What it is not: it does not encrypt anything. Someone with the file and the
know-how can read the database directly. It keeps people's chats separate on a
shared machine; it is not protection against an attacker with the disk.
"""
from __future__ import annotations

import hashlib
import re
import secrets
import time
from dataclasses import dataclass
from typing import List, Optional

_N, _R, _P, _DKLEN = 2 ** 14, 8, 1, 32
_MAXMEM = 64 * 1024 * 1024

USERNAME = re.compile(r"^[A-Za-z0-9_.-]{2,24}$")
MIN_PASSWORD = 4

SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    username     TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    display_name TEXT    NOT NULL DEFAULT '',
    salt         TEXT    NOT NULL,
    hash         TEXT    NOT NULL,
    is_owner     INTEGER NOT NULL DEFAULT 0,
    created_at   REAL    NOT NULL,
    last_seen    REAL    NOT NULL DEFAULT 0
);
"""


def _hash(password: str, salt: bytes) -> str:
    return hashlib.scrypt(
        password.encode("utf-8"), salt=salt,
        n=_N, r=_R, p=_P, dklen=_DKLEN, maxmem=_MAXMEM,
    ).hex()


@dataclass
class Account:
    id: int
    username: str
    display_name: str
    is_owner: bool

    @property
    def name(self) -> str:
        return self.display_name or self.username


class Accounts:
    """Sign up / sign in against the local database."""

    def __init__(self, memory) -> None:
        self.memory = memory
        with self.memory._lock:
            # Memory owns the rest of the schema, including the account columns,
            # so the CLI tools work without ever creating an Accounts object.
            self.memory._conn.executescript(SCHEMA)
            self.memory._conn.commit()

    def _scope_fact_keys(self) -> None:
        """Make fact keys unique per account rather than globally.

        The original table had `key TEXT UNIQUE`, so one person saying "my name
        is Sam" overwrote everyone else's name. SQLite cannot drop a constraint,
        so the table is rebuilt once and the rows carried across.
        """
        conn = self.memory._conn
        sql = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='facts'"
        ).fetchone()
        if not sql or "UNIQUE(account_id" in (sql[0] or ""):
            return

        conn.executescript("""
            CREATE TABLE IF NOT EXISTS facts_scoped (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id INTEGER NOT NULL DEFAULT 1,
                key        TEXT    NOT NULL,
                value      TEXT    NOT NULL,
                source     TEXT    NOT NULL DEFAULT 'user',
                weight     REAL    NOT NULL DEFAULT 1.0,
                created_at REAL    NOT NULL,
                updated_at REAL    NOT NULL,
                UNIQUE(account_id, key)
            );
            INSERT OR IGNORE INTO facts_scoped
                (account_id, key, value, source, weight, created_at, updated_at)
                SELECT account_id, key, value, source, weight, created_at, updated_at
                FROM facts;
            DROP TABLE facts;
            ALTER TABLE facts_scoped RENAME TO facts;
        """)

    def _add_column(self, table: str, column: str, spec: str) -> None:
        """Add a column to an existing database, once."""
        rows = self.memory._conn.execute(f"PRAGMA table_info({table})").fetchall()
        if any(r[1] == column for r in rows):
            return
        self.memory._conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {spec}")

    # ------------------------------------------------------------------ #
    def count(self) -> int:
        with self.memory._lock:
            return int(
                self.memory._conn.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
            )

    def list(self) -> List[Account]:
        with self.memory._lock:
            rows = self.memory._conn.execute(
                "SELECT id, username, display_name, is_owner FROM accounts"
                " ORDER BY last_seen DESC, id ASC"
            ).fetchall()
        return [Account(r[0], r[1], r[2], bool(r[3])) for r in rows]

    def exists(self, username: str) -> bool:
        with self.memory._lock:
            return self.memory._conn.execute(
                "SELECT 1 FROM accounts WHERE username = ? COLLATE NOCASE",
                (username.strip(),),
            ).fetchone() is not None

    # ------------------------------------------------------------------ #
    def sign_up(self, username: str, password: str, display_name: str = "",
                is_owner: bool = False) -> Account:
        username = username.strip()
        if not USERNAME.match(username):
            raise ValueError(
                "Usernames are 2-24 characters: letters, numbers, dot, dash "
                "or underscore."
            )
        if len(password) < MIN_PASSWORD:
            raise ValueError(f"Password must be at least {MIN_PASSWORD} characters.")
        if self.exists(username):
            raise ValueError(f"'{username}' is already taken on this computer.")

        salt = secrets.token_bytes(16)
        now = time.time()
        with self.memory._lock:
            cursor = self.memory._conn.execute(
                "INSERT INTO accounts(username, display_name, salt, hash, is_owner,"
                " created_at, last_seen) VALUES (?,?,?,?,?,?,?)",
                (username, display_name.strip() or username, salt.hex(),
                 _hash(password, salt), int(is_owner), now, now),
            )
            self.memory._conn.commit()
            account_id = int(cursor.lastrowid)
        return Account(account_id, username, display_name or username, is_owner)

    def sign_in(self, username: str, password: str) -> Optional[Account]:
        with self.memory._lock:
            row = self.memory._conn.execute(
                "SELECT id, username, display_name, salt, hash, is_owner FROM accounts"
                " WHERE username = ? COLLATE NOCASE",
                (username.strip(),),
            ).fetchone()
        if not row:
            return None
        if not secrets.compare_digest(_hash(password, bytes.fromhex(row[3])), row[4]):
            return None
        with self.memory._lock:
            self.memory._conn.execute(
                "UPDATE accounts SET last_seen = ? WHERE id = ?", (time.time(), row[0])
            )
            self.memory._conn.commit()
        return Account(row[0], row[1], row[2], bool(row[5]))

    def change_password(self, account: Account, current: str, new: str) -> None:
        if not self.sign_in(account.username, current):
            raise PermissionError("Current password is wrong.")
        if len(new) < MIN_PASSWORD:
            raise ValueError(f"Password must be at least {MIN_PASSWORD} characters.")
        salt = secrets.token_bytes(16)
        with self.memory._lock:
            self.memory._conn.execute(
                "UPDATE accounts SET salt = ?, hash = ? WHERE id = ?",
                (salt.hex(), _hash(new, salt), account.id),
            )
            self.memory._conn.commit()

    def delete(self, account: Account) -> None:
        """Remove an account and everything it owns."""
        with self.memory._lock:
            self.memory._conn.execute(
                "DELETE FROM messages WHERE conversation_id IN"
                " (SELECT id FROM conversations WHERE account_id = ?)", (account.id,)
            )
            for table in ("conversations", "facts", "samples"):
                self.memory._conn.execute(
                    f"DELETE FROM {table} WHERE account_id = ?", (account.id,)
                )
            self.memory._conn.execute("DELETE FROM accounts WHERE id = ?", (account.id,))
            self.memory._conn.commit()
