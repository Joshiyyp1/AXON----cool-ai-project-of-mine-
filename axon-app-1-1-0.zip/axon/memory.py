"""Persistent memory for AXON, backed by a local SQLite file.

Four things live in here:

conversations / messages : the full chat history, so the GUI can reopen old chats
facts                    : long-term key -> value memory injected into prompts
samples                  : every exchange, stored as training data
meta                     : app settings (checkpoint path, sampling knobs, ...)

The database is a plain file (data/axon_memory.db). Nothing leaves your machine.
"""
from __future__ import annotations

import json
import re
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS conversations (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    title      TEXT    NOT NULL DEFAULT 'New chat',
    created_at REAL    NOT NULL,
    updated_at REAL    NOT NULL,
    account_id INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS messages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role            TEXT    NOT NULL,          -- 'user' | 'bot' | 'system'
    content         TEXT    NOT NULL,
    created_at      REAL    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, id);

CREATE TABLE IF NOT EXISTS facts (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL DEFAULT 1,
    key        TEXT    NOT NULL,
    value      TEXT    NOT NULL,
    source     TEXT    NOT NULL DEFAULT 'user',
    weight     REAL    NOT NULL DEFAULT 1.0,
    created_at REAL    NOT NULL,
    updated_at REAL    NOT NULL,
    UNIQUE(account_id, key)
);

CREATE TABLE IF NOT EXISTS samples (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    prompt     TEXT    NOT NULL,
    response   TEXT    NOT NULL,
    source     TEXT    NOT NULL DEFAULT 'chat',  -- 'chat' | 'import' | 'manual'
    rating     INTEGER NOT NULL DEFAULT 0,       -- -1 bad, 0 neutral, +1 good
    trained    INTEGER NOT NULL DEFAULT 0,       -- times used in an online update
    created_at REAL    NOT NULL,
    account_id INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_samples_created ON samples(created_at);

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


@dataclass
class Message:
    id: int
    role: str
    content: str
    created_at: float


@dataclass
class Sample:
    id: int
    prompt: str
    response: str
    source: str
    rating: int
    created_at: float


# Heuristic patterns for "remember this about me" style statements. This is a
# deliberately small, transparent rule set -- it is a memory scratchpad, not an
# attempt at information extraction.
_FACT_PATTERNS: List[Tuple[re.Pattern, str]] = [
    (re.compile(r"\bmy name is\s+([\w' -]{1,40})", re.I), "user.name"),
    (re.compile(r"\bi(?:'m| am)\s+called\s+([\w' -]{1,40})", re.I), "user.name"),
    (re.compile(r"\bcall me\s+([\w' -]{1,40})", re.I), "user.name"),
    (re.compile(r"\bi live in\s+([\w' ,-]{1,60})", re.I), "user.location"),
    (re.compile(r"\bi(?:'m| am)\s+(\d{1,3})\s+years old", re.I), "user.age"),
    (re.compile(r"\bmy favou?rite\s+([\w ]{1,25}?)\s+is\s+([\w' ,-]{1,60})", re.I),
     "user.favorite.{0}"),
    (re.compile(r"\bi work as\s+(?:an?\s+)?([\w' ,-]{1,60})", re.I), "user.job"),
    (re.compile(r"\bi like\s+([\w' ,-]{1,60})", re.I), "user.likes"),
    (re.compile(r"\bremember that\s+(.{3,160})", re.I), "note"),
    (re.compile(r"\bremember:\s*(.{3,160})", re.I), "note"),
]


class Memory:
    """Thread-safe wrapper around the SQLite database."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        # Which account's data this handle reads and writes. 1 is the first
        # account created, and the value everything had before accounts existed.
        self.account_id = 1
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._migrate()
            self._conn.commit()

    def _migrate(self) -> None:
        """Bring an older database up to the current schema.

        Accounts arrived after the first release, so existing files are missing
        the account columns. Everything already there belongs to account 1.
        """
        for table in ("conversations", "facts", "samples"):
            columns = {
                row[1] for row in self._conn.execute(f"PRAGMA table_info({table})")
            }
            if "account_id" not in columns:
                self._conn.execute(
                    f"ALTER TABLE {table} ADD COLUMN account_id INTEGER NOT NULL DEFAULT 1"
                )

        # `facts.key` used to be globally unique, so one person's "my name is..."
        # overwrote everyone else's. Rebuild it as unique per account.
        row = self._conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='facts'"
        ).fetchone()
        if row and "UNIQUE(account_id" not in (row[0] or ""):
            self._conn.executescript("""
                CREATE TABLE facts_scoped (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    account_id INTEGER NOT NULL DEFAULT 1,
                    key        TEXT    NOT NULL,
                    value      TEXT    NOT NULL,
                    source     TEXT    NOT NULL DEFAULT 'user',
                    weight     REAL    NOT NULL DEFAULT 1.0,
                    created_at REAL    NOT NULL,
                    updated_at REAL    NOT NULL,
                    UNIQUE(account_id, key)
                );
                INSERT OR IGNORE INTO facts_scoped
                    (account_id, key, value, source, weight, created_at, updated_at)
                    SELECT account_id, key, value, source, weight, created_at, updated_at
                    FROM facts;
                DROP TABLE facts;
                ALTER TABLE facts_scoped RENAME TO facts;
            """)

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # ------------------------------------------------------------------ #
    # conversations & messages
    # ------------------------------------------------------------------ #
    def set_account(self, account_id: int) -> None:
        """Point this handle at one account's conversations, facts and samples."""
        self.account_id = int(account_id)

    def new_conversation(self, title: str = "New chat") -> int:
        now = time.time()
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO conversations(title, created_at, updated_at, account_id)"
                " VALUES (?,?,?,?)",
                (title, now, now, self.account_id),
            )
            self._conn.commit()
            return int(cur.lastrowid)

    def rename_conversation(self, conv_id: int, title: str) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE conversations SET title=?, updated_at=? WHERE id=?",
                (title, time.time(), conv_id),
            )
            self._conn.commit()

    def delete_conversation(self, conv_id: int) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM messages WHERE conversation_id=?", (conv_id,))
            self._conn.execute("DELETE FROM conversations WHERE id=?", (conv_id,))
            self._conn.commit()

    def list_conversations(self, limit: int = 200) -> List[sqlite3.Row]:
        with self._lock:
            return list(
                self._conn.execute(
                    "SELECT c.id, c.title, c.updated_at,"
                    " (SELECT COUNT(*) FROM messages m WHERE m.conversation_id=c.id) AS n"
                    " FROM conversations c WHERE c.account_id = ?"
                    " ORDER BY c.updated_at DESC LIMIT ?",
                    (self.account_id, limit),
                )
            )

    def add_message(self, conv_id: int, role: str, content: str) -> int:
        now = time.time()
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO messages(conversation_id, role, content, created_at)"
                " VALUES (?,?,?,?)",
                (conv_id, role, content, now),
            )
            self._conn.execute(
                "UPDATE conversations SET updated_at=? WHERE id=?", (now, conv_id)
            )
            self._conn.commit()
            return int(cur.lastrowid)

    def get_messages(self, conv_id: int, limit: int = 1000) -> List[Message]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, role, content, created_at FROM messages"
                " WHERE conversation_id=? ORDER BY id ASC LIMIT ?",
                (conv_id, limit),
            ).fetchall()
        return [Message(r["id"], r["role"], r["content"], r["created_at"]) for r in rows]

    def last_messages(self, conv_id: int, n: int = 12) -> List[Message]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, role, content, created_at FROM messages"
                " WHERE conversation_id=? ORDER BY id DESC LIMIT ?",
                (conv_id, n),
            ).fetchall()
        rows.reverse()
        return [Message(r["id"], r["role"], r["content"], r["created_at"]) for r in rows]

    def search_messages(self, query: str, limit: int = 50) -> List[sqlite3.Row]:
        with self._lock:
            return list(
                self._conn.execute(
                    "SELECT m.id, m.conversation_id, m.role, m.content, c.title"
                    " FROM messages m JOIN conversations c ON c.id=m.conversation_id"
                    " WHERE m.content LIKE ? ORDER BY m.id DESC LIMIT ?",
                    (f"%{query}%", limit),
                )
            )

    # ------------------------------------------------------------------ #
    # facts (long-term memory)
    # ------------------------------------------------------------------ #
    def upsert_fact(self, key: str, value: str, source: str = "user", weight: float = 1.0) -> None:
        now = time.time()
        with self._lock:
            self._conn.execute(
                "INSERT INTO facts(key, value, source, weight, created_at, updated_at,"
                " account_id) VALUES (?,?,?,?,?,?,?)"
                " ON CONFLICT(account_id, key) DO UPDATE SET value=excluded.value,"
                " source=excluded.source, weight=excluded.weight, updated_at=excluded.updated_at",
                (key.strip(), value.strip(), source, weight, now, now, self.account_id),
            )
            self._conn.commit()

    def get_fact(self, key: str) -> Optional[str]:
        with self._lock:
            row = self._conn.execute(
                "SELECT value FROM facts WHERE key=? AND account_id=?",
                (key, self.account_id),
            ).fetchone()
        return row["value"] if row else None

    def list_facts(self, limit: int = 500) -> List[sqlite3.Row]:
        with self._lock:
            return list(
                self._conn.execute(
                    "SELECT id, key, value, source, weight, updated_at FROM facts"
                    " WHERE account_id = ? ORDER BY weight DESC, updated_at DESC LIMIT ?",
                    (self.account_id, limit),
                )
            )

    def delete_fact(self, key: str) -> None:
        with self._lock:
            self._conn.execute(
                "DELETE FROM facts WHERE key=? AND account_id=?", (key, self.account_id)
            )
            self._conn.commit()

    def clear_facts(self) -> None:
        with self._lock:
            self._conn.execute(
                "DELETE FROM facts WHERE account_id=?", (self.account_id,)
            )
            self._conn.commit()

    def extract_facts(self, text: str, source: str = "auto") -> List[Tuple[str, str]]:
        """Pull simple self-descriptions out of a user message and store them."""
        found: List[Tuple[str, str]] = []
        for pattern, key_tpl in _FACT_PATTERNS:
            m = pattern.search(text)
            if not m:
                continue
            groups = [g.strip(" .,!?'\"") for g in m.groups() if g]
            if not groups:
                continue
            if "{0}" in key_tpl:
                if len(groups) < 2:
                    continue
                key = key_tpl.format(groups[0].replace(" ", "_").lower())
                value = groups[1]
            else:
                key = key_tpl
                value = groups[-1]
                if key == "note":
                    key = f"note.{int(time.time() * 1000) % 1_000_000}"
            if not value:
                continue
            self.upsert_fact(key, value, source=source)
            found.append((key, value))
        return found

    def relevant_facts(self, query: str, limit: int = 6) -> List[Tuple[str, str]]:
        """Rank stored facts against the current message with word overlap."""
        rows = self.list_facts(limit=500)
        if not rows:
            return []
        q_words = set(re.findall(r"\w+", query.lower()))
        scored: List[Tuple[float, str, str]] = []
        for r in rows:
            key, value = r["key"], r["value"]
            f_words = set(re.findall(r"\w+", f"{key} {value}".lower()))
            overlap = len(q_words & f_words)
            # identity facts are always somewhat relevant
            base = 0.75 if key.startswith("user.") else 0.0
            score = overlap + base + 0.1 * float(r["weight"])
            scored.append((score, key, value))
        scored.sort(key=lambda t: t[0], reverse=True)
        return [(k, v) for s, k, v in scored[:limit] if s > 0]

    # ------------------------------------------------------------------ #
    # training samples
    # ------------------------------------------------------------------ #
    def add_sample(self, prompt: str, response: str, source: str = "chat", rating: int = 0) -> int:
        prompt, response = prompt.strip(), response.strip()
        if not prompt or not response:
            return -1
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO samples(prompt, response, source, rating, created_at,"
                " account_id) VALUES (?,?,?,?,?,?)",
                (prompt, response, source, rating, time.time(), self.account_id),
            )
            self._conn.commit()
            return int(cur.lastrowid)

    def add_samples(self, pairs: Iterable[Tuple[str, str]], source: str = "import") -> int:
        now = time.time()
        rows = [(p.strip(), r.strip(), source, 0, now) for p, r in pairs if p.strip() and r.strip()]
        if not rows:
            return 0
        with self._lock:
            self._conn.executemany(
                "INSERT INTO samples(prompt, response, source, rating, created_at)"
                " VALUES (?,?,?,?,?)",
                rows,
            )
            self._conn.commit()
        return len(rows)

    def rate_sample(self, sample_id: int, rating: int) -> None:
        with self._lock:
            self._conn.execute("UPDATE samples SET rating=? WHERE id=?", (rating, sample_id))
            self._conn.commit()

    def count_samples(self, min_rating: int = -1) -> int:
        with self._lock:
            row = self._conn.execute(
                "SELECT COUNT(*) AS n FROM samples WHERE rating >= ?", (min_rating,)
            ).fetchone()
        return int(row["n"])

    def get_samples(self, limit: int = 100000, min_rating: int = 0, offset: int = 0) -> List[Sample]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, prompt, response, source, rating, created_at FROM samples"
                " WHERE rating >= ? ORDER BY id ASC LIMIT ? OFFSET ?",
                (min_rating, limit, offset),
            ).fetchall()
        return [
            Sample(r["id"], r["prompt"], r["response"], r["source"], r["rating"], r["created_at"])
            for r in rows
        ]

    def recent_samples(self, n: int = 256, min_rating: int = 0) -> List[Sample]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, prompt, response, source, rating, created_at FROM samples"
                " WHERE rating >= ? ORDER BY id DESC LIMIT ?",
                (min_rating, n),
            ).fetchall()
        return [
            Sample(r["id"], r["prompt"], r["response"], r["source"], r["rating"], r["created_at"])
            for r in rows
        ]

    def mark_trained(self, ids: Iterable[int]) -> None:
        ids = list(ids)
        if not ids:
            return
        with self._lock:
            self._conn.executemany(
                "UPDATE samples SET trained = trained + 1 WHERE id=?", [(i,) for i in ids]
            )
            self._conn.commit()

    def delete_sample(self, sample_id: int) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM samples WHERE id=?", (sample_id,))
            self._conn.commit()

    # ------------------------------------------------------------------ #
    # meta / settings
    # ------------------------------------------------------------------ #
    def set_meta(self, key: str, value: Any) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT INTO meta(key, value) VALUES (?,?)"
                " ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, json.dumps(value)),
            )
            self._conn.commit()

    def get_meta(self, key: str, default: Any = None) -> Any:
        with self._lock:
            row = self._conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value"])
        except json.JSONDecodeError:
            return default

    # ------------------------------------------------------------------ #
    def stats(self) -> Dict[str, int]:
        with self._lock:
            def one(sql: str) -> int:
                return int(self._conn.execute(sql).fetchone()[0])

            return {
                "conversations": one("SELECT COUNT(*) FROM conversations"),
                "messages": one("SELECT COUNT(*) FROM messages"),
                "facts": one("SELECT COUNT(*) FROM facts"),
                "samples": one("SELECT COUNT(*) FROM samples"),
            }
