"""Byte-level BPE tokenizer, trained from scratch on your own corpus.

Design notes
------------
* Byte level: every possible input is representable, so the tokenizer can never
  emit an <unk>. Emoji, source code, other languages -- all fine.
* Special tokens occupy the first ids and are matched *before* the regex
  pre-tokenizer, so they can never be split apart.
* Training uses an incremental pair counter with a lazy heap, which makes it
  fast enough to build an 8k-16k vocab from tens of MB of text in pure Python.
"""
from __future__ import annotations

import heapq
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

# GPT-2 style pre-tokenizer: keeps a leading space attached to a word, splits
# punctuation and digits off, and never merges across a whitespace boundary.
SPLIT_PATTERN = re.compile(
    r"'(?:[sdmt]|ll|ve|re)"      # english contractions
    r"| ?[^\W\d_]+"              # optional space + letters
    r"| ?\d+"                    # optional space + digits
    r"| ?[^\s\w]+"               # optional space + punctuation/symbols
    r"|\s+(?!\S)"                # trailing whitespace
    r"|\s+",                     # any other whitespace run
    re.UNICODE,
)

PAD = "<|pad|>"
BOS = "<|bos|>"
EOS = "<|eos|>"
USER = "<|user|>"
BOT = "<|bot|>"
SYS = "<|sys|>"
MEM = "<|mem|>"
EOT = "<|eot|>"

SPECIAL_TOKENS: Tuple[str, ...] = (PAD, BOS, EOS, USER, BOT, SYS, MEM, EOT)


class BPETokenizer:
    """A trainable byte-level BPE tokenizer."""

    def __init__(self, specials: Sequence[str] = SPECIAL_TOKENS) -> None:
        self.specials: List[str] = list(specials)
        self.merges: List[Tuple[int, int]] = []       # ordered merge rules
        self.ranks: Dict[Tuple[int, int], int] = {}   # pair -> resulting token id
        self.vocab: List[bytes] = []                  # id -> byte string
        self._cache: Dict[str, List[int]] = {}
        self._special_re = self._build_special_re()
        self._rebuild_vocab()

    # ------------------------------------------------------------------ #
    # properties
    # ------------------------------------------------------------------ #
    @property
    def vocab_size(self) -> int:
        return len(self.vocab)

    @property
    def n_specials(self) -> int:
        return len(self.specials)

    def special_id(self, token: str) -> int:
        return self.specials.index(token)

    @property
    def pad_id(self) -> int:
        return self.special_id(PAD)

    @property
    def eot_id(self) -> int:
        return self.special_id(EOT)

    # ------------------------------------------------------------------ #
    # internals
    # ------------------------------------------------------------------ #
    def _build_special_re(self) -> re.Pattern:
        if not self.specials:
            return re.compile(r"(?!x)x")  # never matches
        return re.compile("(" + "|".join(re.escape(s) for s in self.specials) + ")")

    def _rebuild_vocab(self) -> None:
        """vocab = [specials] + [256 raw bytes] + [merged tokens]."""
        vocab: List[bytes] = [s.encode("utf-8") for s in self.specials]
        vocab += [bytes([i]) for i in range(256)]
        for a, b in self.merges:
            vocab.append(vocab[a] + vocab[b])
        self.vocab = vocab
        self.ranks = {pair: self.n_specials + 256 + i for i, pair in enumerate(self.merges)}
        self._cache = {}

    def _byte_ids(self, chunk: str) -> List[int]:
        off = self.n_specials
        return [off + b for b in chunk.encode("utf-8")]

    def _merge_chunk(self, chunk: str) -> List[int]:
        cached = self._cache.get(chunk)
        if cached is not None:
            return cached

        ids = self._byte_ids(chunk)
        while len(ids) >= 2:
            best_rank = None
            best_i = -1
            for i in range(len(ids) - 1):
                r = self.ranks.get((ids[i], ids[i + 1]))
                if r is not None and (best_rank is None or r < best_rank):
                    best_rank, best_i = r, i
            if best_i < 0:
                break
            new_id = best_rank
            a, b = ids[best_i], ids[best_i + 1]
            merged: List[int] = []
            i, n = 0, len(ids)
            while i < n:
                if i < n - 1 and ids[i] == a and ids[i + 1] == b:
                    merged.append(new_id)
                    i += 2
                else:
                    merged.append(ids[i])
                    i += 1
            ids = merged

        if len(self._cache) < 200_000:
            self._cache[chunk] = ids
        return ids

    # ------------------------------------------------------------------ #
    # public API
    # ------------------------------------------------------------------ #
    def encode(self, text: str, allowed_special: bool = True) -> List[int]:
        """Turn text into token ids. Special tokens in the text are honoured."""
        if not text:
            return []
        out: List[int] = []
        pieces = self._special_re.split(text) if allowed_special else [text]
        for piece in pieces:
            if not piece:
                continue
            if allowed_special and piece in self.specials:
                out.append(self.specials.index(piece))
                continue
            for chunk in SPLIT_PATTERN.findall(piece):
                out.extend(self._merge_chunk(chunk))
        return out

    def decode(self, ids: Iterable[int], skip_special: bool = False) -> str:
        buf = bytearray()
        n_spec = self.n_specials
        size = len(self.vocab)
        for i in ids:
            i = int(i)
            if i < 0 or i >= size:
                continue
            if skip_special and i < n_spec:
                continue
            buf.extend(self.vocab[i])
        return buf.decode("utf-8", errors="replace")

    # ------------------------------------------------------------------ #
    # training
    # ------------------------------------------------------------------ #
    def train(
        self,
        texts: Iterable[str],
        vocab_size: int = 8192,
        min_frequency: int = 2,
        progress=None,
    ) -> "BPETokenizer":
        """Learn merge rules from a corpus.

        Parameters
        ----------
        texts : iterable of documents
        vocab_size : target final vocabulary size
        min_frequency : stop merging pairs rarer than this
        progress : optional callable(done, total, message)
        """
        n_base = self.n_specials + 256
        n_merges = max(0, int(vocab_size) - n_base)

        # 1. pre-tokenize into chunk frequencies (specials are stripped out)
        freqs: Counter = Counter()
        for doc in texts:
            if not doc:
                continue
            for piece in self._special_re.split(doc):
                if not piece or piece in self.specials:
                    continue
                freqs.update(SPLIT_PATTERN.findall(piece))
        if not freqs:
            raise ValueError("Tokenizer training corpus is empty.")

        words: List[List[int]] = []
        counts: List[int] = []
        for word, freq in freqs.items():
            ids = self._byte_ids(word)
            if len(ids) >= 2:
                words.append(ids)
                counts.append(freq)
        if progress:
            progress(0, n_merges, f"{len(freqs):,} unique chunks pre-tokenized")

        # 2. initial pair statistics + reverse index
        pair_counts: Counter = Counter()
        where: Dict[Tuple[int, int], set] = defaultdict(set)
        for wi, ids in enumerate(words):
            c = counts[wi]
            for pair in zip(ids, ids[1:]):
                pair_counts[pair] += c
                where[pair].add(wi)

        heap: List[Tuple[int, Tuple[int, int]]] = [(-c, p) for p, c in pair_counts.items()]
        heapq.heapify(heap)

        merges: List[Tuple[int, int]] = []
        next_id = n_base

        # 3. greedy merge loop with lazy heap invalidation
        while len(merges) < n_merges and heap:
            neg, pair = heapq.heappop(heap)
            cur = pair_counts.get(pair, 0)
            if cur != -neg:          # stale heap entry
                continue
            if cur < min_frequency:
                break

            a, b = pair
            affected = list(where.get(pair, ()))
            touched: set = set()
            for wi in affected:
                ids = words[wi]
                c = counts[wi]
                # remove this word's contribution
                for p in zip(ids, ids[1:]):
                    pair_counts[p] -= c
                    touched.add(p)
                # rewrite the word with the merge applied
                new_ids: List[int] = []
                i, n = 0, len(ids)
                while i < n:
                    if i < n - 1 and ids[i] == a and ids[i + 1] == b:
                        new_ids.append(next_id)
                        i += 2
                    else:
                        new_ids.append(ids[i])
                        i += 1
                words[wi] = new_ids
                # add the rewritten word's contribution back
                for p in zip(new_ids, new_ids[1:]):
                    pair_counts[p] += c
                    where[p].add(wi)
                    touched.add(p)

            pair_counts.pop(pair, None)
            where.pop(pair, None)
            touched.discard(pair)
            for p in touched:
                c = pair_counts.get(p, 0)
                if c > 0:
                    heapq.heappush(heap, (-c, p))
                else:
                    pair_counts.pop(p, None)
                    where.pop(p, None)

            merges.append(pair)
            next_id += 1
            if progress and len(merges) % 250 == 0:
                progress(len(merges), n_merges, f"merge {len(merges)}/{n_merges}")

        self.merges = merges
        self._rebuild_vocab()
        if progress:
            progress(n_merges, n_merges, f"vocabulary: {self.vocab_size:,} tokens")
        return self

    # ------------------------------------------------------------------ #
    # (de)serialisation
    # ------------------------------------------------------------------ #
    def to_json(self) -> str:
        return json.dumps(
            {
                "version": 1,
                "specials": self.specials,
                "merges": [[a, b] for a, b in self.merges],
            },
            ensure_ascii=False,
        )

    @classmethod
    def from_json(cls, blob: str) -> "BPETokenizer":
        data = json.loads(blob)
        tok = cls(specials=data.get("specials", SPECIAL_TOKENS))
        tok.merges = [(int(a), int(b)) for a, b in data.get("merges", [])]
        tok._rebuild_vocab()
        return tok

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.to_json(), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "BPETokenizer":
        return cls.from_json(Path(path).read_text(encoding="utf-8"))

    def __repr__(self) -> str:  # pragma: no cover
        return f"<BPETokenizer vocab={self.vocab_size} merges={len(self.merges)}>"
