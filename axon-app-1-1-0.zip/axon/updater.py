"""Publishing model versions, and installing them on other people's copies.

How it works
------------
You (the admin) publish a release: AXON copies the checkpoint into a release
folder and writes a `manifest.json` describing it. You put that folder anywhere
your friends can reach:

  * a shared folder, a USB stick, a network drive  -> channel is a path
  * a GitHub repo / release, or any web host       -> channel is an https URL

Your friends' copies read the manifest, compare versions, download the file,
check its SHA-256, and install it. Their own chats and memory are untouched.

There is no server and nothing phones home. If no channel is configured, AXON
never touches the network at all.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import sys
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, List, Optional, Sequence, Tuple

MANIFEST_NAME = "manifest.json"
USER_AGENT = "axon-updater/1.0"


# --------------------------------------------------------------------------- #
# versions
# --------------------------------------------------------------------------- #
def parse_version(text: str) -> Tuple[int, ...]:
    """'1.2.3' -> (1, 2, 3). Unparseable pieces become 0."""
    parts = []
    for piece in str(text).strip().lstrip("vV").split("."):
        digits = "".join(c for c in piece if c.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts or [0])


def is_newer(candidate: str, current: str) -> bool:
    a, b = parse_version(candidate), parse_version(current)
    length = max(len(a), len(b))
    a = a + (0,) * (length - len(a))
    b = b + (0,) * (length - len(b))
    return a > b


def sha256_file(path: str | Path, chunk: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(chunk), b""):
            digest.update(block)
    return digest.hexdigest()


# --------------------------------------------------------------------------- #
@dataclass
class Release:
    version: str
    model_name: str
    file: str
    sha256: str
    size: int
    notes: str = ""
    released: str = ""
    trained_steps: int = 0
    val_loss: Optional[float] = None

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Release":
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in known})


# --------------------------------------------------------------------------- #
# reading a channel
# --------------------------------------------------------------------------- #
def _is_url(channel: str) -> bool:
    return str(channel).lower().startswith(("http://", "https://"))


def _join(channel: str, name: str) -> str:
    if _is_url(channel):
        return channel.rstrip("/") + "/" + name
    return str(Path(channel) / name)


def _read_bytes(location: str, timeout: int = 30) -> bytes:
    if _is_url(location):
        request = urllib.request.Request(location, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.read()
    return Path(location).read_bytes()


def fetch_manifest(channel: str) -> dict:
    """Read manifest.json from a folder or a URL."""
    raw = _read_bytes(_join(channel, MANIFEST_NAME))
    return json.loads(raw.decode("utf-8"))


def check_for_update(channel: str, current_version: str) -> Optional[Release]:
    """Return the published release if it is newer than what is installed."""
    if not channel:
        return None
    manifest = fetch_manifest(channel)
    latest = manifest.get("latest")
    if not latest:
        return None
    release = Release.from_dict(latest)
    return release if is_newer(release.version, current_version) else None


def download_release(
    channel: str,
    release: Release,
    destination: str | Path,
    progress: Optional[Callable[[int, int], None]] = None,
    timeout: int = 120,
) -> Path:
    """Download a release's checkpoint, verify its hash, then install it.

    The file is written next to the destination and only moved into place once
    the SHA-256 matches, so a failed download can never replace a good model.
    """
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = destination.with_suffix(destination.suffix + ".download")
    source = _join(channel, release.file)

    if _is_url(source):
        request = urllib.request.Request(source, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(request, timeout=timeout) as response, \
                open(staging, "wb") as out:
            total = int(response.headers.get("Content-Length") or release.size or 0)
            done = 0
            while True:
                chunk = response.read(1 << 20)
                if not chunk:
                    break
                out.write(chunk)
                done += len(chunk)
                if progress:
                    progress(done, total)
    else:
        shutil.copyfile(source, staging)
        if progress:
            progress(staging.stat().st_size, staging.stat().st_size)

    actual = sha256_file(staging)
    if release.sha256 and actual != release.sha256:
        staging.unlink(missing_ok=True)
        raise ValueError(
            "Downloaded file does not match its checksum - refusing to install it.\n"
            f"  expected {release.sha256}\n  got      {actual}"
        )

    staging.replace(destination)
    return destination


# --------------------------------------------------------------------------- #
# publishing (admin side)
# --------------------------------------------------------------------------- #
def publish(
    checkpoint: str | Path,
    out_dir: str | Path,
    version: str,
    model_name: str = "",
    notes: str = "",
    trained_steps: int = 0,
    val_loss: Optional[float] = None,
    file_name: Optional[str] = None,
) -> Release:
    """Copy a checkpoint into a release folder and write/refresh the manifest."""
    checkpoint = Path(checkpoint)
    if not checkpoint.exists():
        raise FileNotFoundError(f"No checkpoint at {checkpoint}")

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    name = file_name or f"vesper-{version.replace('.', '-')}.pt"
    target = out_dir / name
    shutil.copyfile(checkpoint, target)

    release = Release(
        version=version,
        model_name=model_name,
        file=name,
        sha256=sha256_file(target),
        size=target.stat().st_size,
        notes=notes,
        released=time.strftime("%Y-%m-%d"),
        trained_steps=int(trained_steps),
        val_loss=val_loss,
    )

    manifest_path = out_dir / MANIFEST_NAME
    manifest = {"app": "AXON", "history": []}
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            manifest.setdefault("history", [])
        except json.JSONDecodeError:
            pass

    previous = manifest.get("latest")
    if previous and previous.get("version") != release.version:
        manifest["history"].insert(0, previous)
    manifest["latest"] = release.to_dict()
    manifest["updated"] = time.strftime("%Y-%m-%d %H:%M")

    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return release


# --------------------------------------------------------------------------- #
# scheduling
# --------------------------------------------------------------------------- #
def should_check(last_check: Optional[float], every_days: float = 7.0) -> bool:
    """Weekly by default, like the user asked for."""
    if not last_check:
        return True
    return (time.time() - float(last_check)) >= every_days * 86400


# --------------------------------------------------------------------------- #
# app updates (the program itself, not just the model)
# --------------------------------------------------------------------------- #
APP_KEY = "app_release"

# Never overwritten by an app update - these belong to the person using it.
PROTECTED = ("data", "checkpoints", "logs", "releases", "dist", ".venv")


@dataclass
class AppRelease:
    version: str
    file: str
    sha256: str
    size: int
    notes: str = ""
    released: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "AppRelease":
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in known})


def check_for_app_update(channel: str, current_version: str) -> Optional[AppRelease]:
    """Is there a newer version of the program itself?"""
    if not channel:
        return None
    manifest = fetch_manifest(channel)
    entry = manifest.get(APP_KEY)
    if not entry:
        return None
    release = AppRelease.from_dict(entry)
    return release if is_newer(release.version, current_version) else None


def publish_app(
    source_dir: str | Path,
    out_dir: str | Path,
    version: str,
    notes: str = "",
    include: Sequence[str] = ("axon", "run_gui.py", "chat.py", "requirements.txt"),
) -> AppRelease:
    """Zip the program's code and add it to the manifest as an app update."""
    import zipfile

    source_dir = Path(source_dir)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    name = f"axon-app-{version.replace('.', '-')}.zip"
    target = out_dir / name
    target.unlink(missing_ok=True)

    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for item in include:
            path = source_dir / item
            if not path.exists():
                continue
            if path.is_dir():
                for f in sorted(path.rglob("*")):
                    if f.is_file() and "__pycache__" not in f.parts:
                        zf.write(f, f.relative_to(source_dir))
            else:
                zf.write(path, path.relative_to(source_dir))

    release = AppRelease(
        version=version, file=name, sha256=sha256_file(target),
        size=target.stat().st_size, notes=notes, released=time.strftime("%Y-%m-%d"),
    )

    manifest_path = out_dir / MANIFEST_NAME
    manifest = {"app": "AXON", "history": []}
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    manifest[APP_KEY] = release.to_dict()
    manifest["updated"] = time.strftime("%Y-%m-%d %H:%M")
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return release


def is_frozen() -> bool:
    """Running as a built .exe rather than from source."""
    return bool(getattr(sys, "frozen", False))


def install_app_update(
    channel: str,
    release: AppRelease,
    install_dir: str | Path,
    progress: Optional[Callable[[int, int], None]] = None,
    timeout: int = 180,
) -> List[str]:
    """Download and unpack a program update over a source installation.

    Nothing is written until the whole archive has been downloaded and its
    SHA-256 matches. User data - conversations, models, logs - is never touched.
    Returns the list of files that were replaced.

    Refused inside a built .exe: the frozen app loads its code from the archive
    inside the executable, so unpacking .py files beside it would do nothing
    except leave readable source on disk. Frozen builds update by replacing the
    whole application folder - see `install_app_bundle`.
    """
    if is_frozen():
        raise RuntimeError(
            "This is the installed app. Program updates for it replace the whole "
            "application, which is handled by install_app_bundle()."
        )
    import tempfile
    import zipfile

    install_dir = Path(install_dir)
    staging = Path(tempfile.mkdtemp(prefix="axon_update_"))
    archive = staging / release.file
    source = _join(channel, release.file)

    try:
        if _is_url(source):
            request = urllib.request.Request(source, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(request, timeout=timeout) as response, \
                    open(archive, "wb") as out:
                total = int(response.headers.get("Content-Length") or release.size or 0)
                done = 0
                while True:
                    chunk = response.read(1 << 20)
                    if not chunk:
                        break
                    out.write(chunk)
                    done += len(chunk)
                    if progress:
                        progress(done, total)
        else:
            shutil.copyfile(source, archive)
            if progress:
                progress(archive.stat().st_size, archive.stat().st_size)

        actual = sha256_file(archive)
        if release.sha256 and actual != release.sha256:
            raise ValueError(
                "Update archive does not match its checksum - nothing was installed."
            )

        extracted = staging / "unpacked"
        with zipfile.ZipFile(archive) as zf:
            for member in zf.namelist():
                target = (extracted / member).resolve()
                if not str(target).startswith(str(extracted.resolve())):
                    raise ValueError(f"Refusing unsafe path in archive: {member}")
            zf.extractall(extracted)

        replaced: List[str] = []
        for src in sorted(extracted.rglob("*")):
            if not src.is_file():
                continue
            rel = src.relative_to(extracted)
            if rel.parts and rel.parts[0] in PROTECTED:
                continue
            dest = install_dir / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dest)
            replaced.append(str(rel))
        return replaced
    finally:
        shutil.rmtree(staging, ignore_errors=True)


# --------------------------------------------------------------------------- #
# app-bundle updates (for the built .exe)
# --------------------------------------------------------------------------- #
BUNDLE_KEY = "app_bundle"

# A running .exe cannot overwrite itself, so the swap is done by a tiny script
# that waits for the app to exit, replaces the folder, and starts it again.
_SWAP_SCRIPT = """@echo off
echo Updating AXON...
:wait
tasklist /FI "PID eq {pid}" 2>nul | find "{pid}" >nul
if not errorlevel 1 (
    timeout /t 1 /nobreak >nul
    goto wait
)
robocopy "{staged}" "{target}" /E /MOVE /NFL /NDL /NJH /NJS /NC /NS >nul
start "" "{exe}"
rmdir /S /Q "{staged_root}" >nul 2>&1
del "%~f0"
"""


def publish_app_bundle(
    app_dir: str | Path,
    out_dir: str | Path,
    version: str,
    notes: str = "",
) -> AppRelease:
    """Zip a built AXON-app folder and register it as a program update."""
    import zipfile

    app_dir = Path(app_dir)
    if not (app_dir / "AXON.exe").exists():
        raise FileNotFoundError(f"{app_dir} does not look like a built app folder")

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    name = f"axon-win-{version.replace('.', '-')}.zip"
    target = out_dir / name
    target.unlink(missing_ok=True)

    # The user's own data lives in this folder too; never ship it back out.
    skip = {"data", "checkpoints", "logs"}
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(app_dir.rglob("*")):
            rel = f.relative_to(app_dir)
            if f.is_file() and (not rel.parts or rel.parts[0] not in skip):
                zf.write(f, rel)

    release = AppRelease(
        version=version, file=name, sha256=sha256_file(target),
        size=target.stat().st_size, notes=notes, released=time.strftime("%Y-%m-%d"),
    )

    manifest_path = out_dir / MANIFEST_NAME
    manifest = {"app": "AXON", "history": []}
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    manifest[BUNDLE_KEY] = release.to_dict()
    manifest["updated"] = time.strftime("%Y-%m-%d %H:%M")
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return release


def check_for_app_bundle(channel: str, current_version: str) -> Optional[AppRelease]:
    """Is there a newer build of the installed application?"""
    if not channel:
        return None
    entry = fetch_manifest(channel).get(BUNDLE_KEY)
    if not entry:
        return None
    release = AppRelease.from_dict(entry)
    return release if is_newer(release.version, current_version) else None


def install_app_bundle(
    channel: str,
    release: AppRelease,
    install_dir: str | Path,
    progress: Optional[Callable[[int, int], None]] = None,
    timeout: int = 600,
) -> Path:
    """Stage a new application build and hand the swap to a helper script.

    Downloads, verifies the SHA-256, unpacks to a staging folder, and writes a
    script that waits for this process to exit before replacing the program and
    restarting it. Returns the script's path; the caller runs it and quits.

    `data/`, `checkpoints/` and `logs/` are not in the archive and are not
    touched, so conversations and models survive the update.
    """
    import os
    import subprocess
    import tempfile
    import zipfile

    install_dir = Path(install_dir).resolve()
    staging_root = Path(tempfile.mkdtemp(prefix="axon_appupdate_"))
    archive = staging_root / release.file

    source = _join(channel, release.file)
    if _is_url(source):
        request = urllib.request.Request(source, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(request, timeout=timeout) as response, \
                open(archive, "wb") as out:
            total = int(response.headers.get("Content-Length") or release.size or 0)
            done = 0
            while True:
                chunk = response.read(1 << 20)
                if not chunk:
                    break
                out.write(chunk)
                done += len(chunk)
                if progress:
                    progress(done, total)
    else:
        shutil.copyfile(source, archive)
        if progress:
            progress(archive.stat().st_size, archive.stat().st_size)

    if release.sha256 and sha256_file(archive) != release.sha256:
        shutil.rmtree(staging_root, ignore_errors=True)
        raise ValueError(
            "Update does not match its checksum - nothing was installed."
        )

    staged = staging_root / "new"
    with zipfile.ZipFile(archive) as zf:
        for member in zf.namelist():
            target = (staged / member).resolve()
            if not str(target).startswith(str(staged.resolve())):
                raise ValueError(f"Refusing unsafe path in archive: {member}")
        zf.extractall(staged)
    archive.unlink(missing_ok=True)

    script = staging_root / "apply_update.bat"
    script.write_text(
        _SWAP_SCRIPT.format(
            pid=os.getpid(), staged=staged, target=install_dir,
            exe=install_dir / "AXON.exe", staged_root=staging_root,
        ),
        encoding="utf-8",
    )
    return script
