"""Configuration objects for AXON.

Everything that is tunable lives here so the GUI, the CLI and the training
scripts all share one source of truth.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict


# --------------------------------------------------------------------------- #
# Filesystem layout
# --------------------------------------------------------------------------- #
def _root() -> Path:
    """Where AXON keeps its files.

    Frozen into an .exe, that is the folder holding the executable, so chats
    and models sit beside the app and survive an update. Running from source,
    it is the project folder. AXON_HOME overrides both.
    """
    override = os.environ.get("AXON_HOME")
    if override:
        return Path(override)
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def _bundle() -> Path:
    """Read-only files packed inside the executable (PyInstaller's _MEIPASS)."""
    return Path(getattr(sys, "_MEIPASS", _root()))


class Paths:
    """Resolved project paths. Override the root with the AXON_HOME env var."""

    ROOT = _root()
    BUNDLE = _bundle()
    DATA = ROOT / "data"
    CHECKPOINTS = ROOT / "checkpoints"
    DB = DATA / "axon_memory.db"
    DEFAULT_CHECKPOINT = CHECKPOINTS / "axon.pt"
    SEED_DIALOGUES = DATA / "seed_dialogues.json"
    SEED_CORPUS = DATA / "seed_corpus.txt"

    @classmethod
    def ensure(cls) -> None:
        cls.DATA.mkdir(parents=True, exist_ok=True)
        cls.CHECKPOINTS.mkdir(parents=True, exist_ok=True)
        cls.unpack_bundled()

    @classmethod
    def unpack_bundled(cls) -> None:
        """First run of a frozen app: copy the packed model and database out.

        They are copied rather than read in place so the app can write to them,
        and so a later update can replace the executable without touching the
        user's conversations.
        """
        if cls.BUNDLE == cls.ROOT:
            return
        import shutil

        for packed, target in (
            (cls.BUNDLE / "checkpoints" / "axon.pt", cls.DEFAULT_CHECKPOINT),
            (cls.BUNDLE / "data" / "axon_memory.db", cls.DB),
            (cls.BUNDLE / "data" / "seed_dialogues.json", cls.SEED_DIALOGUES),
            (cls.BUNDLE / "data" / "seed_corpus.txt", cls.SEED_CORPUS),
        ):
            if packed.exists() and not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(packed, target)


# --------------------------------------------------------------------------- #
# Model
# --------------------------------------------------------------------------- #
@dataclass
class ModelConfig:
    """Architecture of the decoder-only Transformer."""

    vocab_size: int = 8192
    block_size: int = 256      # context window in tokens
    n_layer: int = 6
    n_head: int = 8
    n_embd: int = 384          # must be divisible by n_head
    dropout: float = 0.1
    bias: bool = True          # bias terms in Linear / LayerNorm

    def __post_init__(self) -> None:
        if self.n_embd % self.n_head != 0:
            raise ValueError(
                f"n_embd ({self.n_embd}) must be divisible by n_head ({self.n_head})"
            )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ModelConfig":
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in known})


# --------------------------------------------------------------------------- #
# Model naming
# --------------------------------------------------------------------------- #
# AXON is the app. VESPER is the family of models it trains -- the evening star,
# the first light to appear in the purple part of the sky. The four sizes are
# named for how brightly they burn, and get brighter as they get bigger.
MODEL_FAMILY = "Vesper"
MODEL_GENERATION = 1


@dataclass(frozen=True)
class Preset:
    """One named model size."""

    tier: str          # Spark / Ember / Flare / Nova
    blurb: str         # short human description
    n_layer: int
    n_head: int
    n_embd: int
    block_size: int
    available: bool = False    # shipped to users, or still "coming soon"
    eta: str = ""              # what to show while it is not out yet

    @property
    def name(self) -> str:
        return f"{MODEL_FAMILY} {self.tier} {MODEL_GENERATION}"

    @property
    def label(self) -> str:
        return f"{self.name}  -  {self.blurb}"

    @property
    def status(self) -> str:
        return "Available" if self.available else "Coming soon"

    def dims(self) -> Dict[str, int]:
        return dict(
            n_layer=self.n_layer, n_head=self.n_head,
            n_embd=self.n_embd, block_size=self.block_size,
        )


# Keyed by the short tier name, which is also what --preset accepts.
MODEL_PRESETS: Dict[str, Preset] = {
    "spark": Preset("Spark", "Fast and light. Runs on any laptop.",
                    4, 4, 192, 192, available=True),
    "ember": Preset("Ember", "Four times the size. Longer, steadier answers.",
                    6, 8, 384, 256, eta="in training"),
    "flare": Preset("Flare", "Built for a graphics card. Much stronger.",
                    8, 8, 512, 512, eta="planned"),
    "nova":  Preset("Nova",  "The big one. Needs a real GPU and a lot of data.",
                    12, 12, 768, 512, eta="planned"),
}


def released_presets() -> Dict[str, Preset]:
    """The sizes a customer can actually pick today."""
    return {k: v for k, v in MODEL_PRESETS.items() if v.available}


def model_name(cfg: "ModelConfig") -> str:
    """Name a model from its shape, e.g. 'Vesper Spark 1'.

    A model whose dimensions were hand-tuned doesn't match any preset, so it is
    named Custom rather than being forced into the nearest tier.
    """
    for preset in MODEL_PRESETS.values():
        if (cfg.n_layer, cfg.n_head, cfg.n_embd) == (preset.n_layer, preset.n_head, preset.n_embd):
            return preset.name
    return f"{MODEL_FAMILY} Custom {MODEL_GENERATION}"


# --------------------------------------------------------------------------- #
# Training
# --------------------------------------------------------------------------- #
@dataclass
class TrainConfig:
    epochs: int = 8
    batch_size: int = 16
    learning_rate: float = 3e-4
    min_lr_ratio: float = 0.1      # cosine decay floor, as a fraction of lr
    weight_decay: float = 0.1
    beta1: float = 0.9
    beta2: float = 0.95
    grad_clip: float = 1.0
    warmup_ratio: float = 0.05     # fraction of total steps spent warming up
    val_split: float = 0.05
    log_every: int = 10            # steps
    eval_every: int = 250          # steps (0 disables mid-epoch eval)
    save_every: int = 500          # steps (0 = only at epoch end)
    grad_accum: int = 1
    amp: bool = True               # mixed precision when on CUDA
    num_workers: int = 0           # keep 0 on Windows: avoids spawn overhead

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# A model cannot be improved by training on its own unreviewed output - doing so
# amplifies whatever it already gets wrong until the weights collapse. Online
# learning therefore only ever replays exchanges a human marked as good, and the
# learning rate is hard-capped well below anything that could wreck the weights.
MAX_ONLINE_LR = 1e-3


@dataclass
class OnlineConfig:
    """Continuous learning: tiny gradient updates from approved exchanges."""

    enabled: bool = True
    every_n_exchanges: int = 4     # run an update after this many new samples
    steps: int = 6                 # gradient steps per update
    batch_size: int = 4
    learning_rate: float = 5e-5    # much lower than full training
    recent_window: int = 256       # sample from the N most recent stored samples
    min_rating: int = 1            # only replay replies rated good (thumbs up)

    def safe_learning_rate(self) -> float:
        """Clamp the learning rate into a range that cannot destroy the model."""
        return max(1e-7, min(float(self.learning_rate), MAX_ONLINE_LR))


# --------------------------------------------------------------------------- #
# Generation
# --------------------------------------------------------------------------- #
@dataclass
class GenerationConfig:
    max_new_tokens: int = 200
    # 0.9 is a normal default for a big model; at this size it tips the
    # sampler into token soup, so AXON runs cooler.
    temperature: float = 0.7
    top_k: int = 40                # 0 disables
    top_p: float = 0.92            # 1.0 disables
    repetition_penalty: float = 1.15
    presence_penalty: float = 0.0
    seed: int = -1                 # -1 = non-deterministic

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AppState:
    """Everything the GUI persists between runs (stored in the SQLite meta table)."""

    checkpoint: str = str(Paths.DEFAULT_CHECKPOINT)
    generation: GenerationConfig = field(default_factory=GenerationConfig)
    online: OnlineConfig = field(default_factory=OnlineConfig)
    use_memory: bool = True
