"""A decoder-only Transformer (GPT-style) written from scratch in PyTorch.

Pre-LayerNorm blocks, causal multi-head self-attention, GELU MLP, weight-tied
embeddings. Uses PyTorch's fused scaled_dot_product_attention when available and
falls back to an explicit masked-softmax implementation otherwise.
"""
from __future__ import annotations

import math
from typing import Callable, Iterator, List, Optional

import torch
import torch.nn as nn
from torch.nn import functional as F

from axon.config import ModelConfig

_HAS_SDPA = hasattr(F, "scaled_dot_product_attention")


class CausalSelfAttention(nn.Module):
    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.n_head = cfg.n_head
        self.n_embd = cfg.n_embd
        self.head_dim = cfg.n_embd // cfg.n_head
        self.dropout_p = cfg.dropout

        self.qkv = nn.Linear(cfg.n_embd, 3 * cfg.n_embd, bias=cfg.bias)
        self.proj = nn.Linear(cfg.n_embd, cfg.n_embd, bias=cfg.bias)
        self.attn_drop = nn.Dropout(cfg.dropout)
        self.resid_drop = nn.Dropout(cfg.dropout)

        if not _HAS_SDPA:
            mask = torch.tril(torch.ones(cfg.block_size, cfg.block_size))
            self.register_buffer("mask", mask.view(1, 1, cfg.block_size, cfg.block_size))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        q, k, v = self.qkv(x).split(self.n_embd, dim=2)
        # (B, nh, T, hd)
        q = q.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        k = k.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        v = v.view(B, T, self.n_head, self.head_dim).transpose(1, 2)

        if _HAS_SDPA:
            y = F.scaled_dot_product_attention(
                q, k, v,
                dropout_p=self.dropout_p if self.training else 0.0,
                is_causal=True,
            )
        else:
            att = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
            att = att.masked_fill(self.mask[:, :, :T, :T] == 0, float("-inf"))
            att = self.attn_drop(F.softmax(att, dim=-1))
            y = att @ v

        y = y.transpose(1, 2).contiguous().view(B, T, C)
        return self.resid_drop(self.proj(y))


class MLP(nn.Module):
    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.fc = nn.Linear(cfg.n_embd, 4 * cfg.n_embd, bias=cfg.bias)
        self.proj = nn.Linear(4 * cfg.n_embd, cfg.n_embd, bias=cfg.bias)
        self.drop = nn.Dropout(cfg.dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.drop(self.proj(F.gelu(self.fc(x), approximate="tanh")))


class Block(nn.Module):
    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.ln1 = nn.LayerNorm(cfg.n_embd, bias=cfg.bias)
        self.attn = CausalSelfAttention(cfg)
        self.ln2 = nn.LayerNorm(cfg.n_embd, bias=cfg.bias)
        self.mlp = MLP(cfg)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.ln1(x))
        x = x + self.mlp(self.ln2(x))
        return x


class AxonTransformer(nn.Module):
    """The language model itself."""

    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.cfg = cfg
        self.tok_emb = nn.Embedding(cfg.vocab_size, cfg.n_embd)
        self.pos_emb = nn.Embedding(cfg.block_size, cfg.n_embd)
        self.drop = nn.Dropout(cfg.dropout)
        self.blocks = nn.ModuleList([Block(cfg) for _ in range(cfg.n_layer)])
        self.ln_f = nn.LayerNorm(cfg.n_embd, bias=cfg.bias)
        self.head = nn.Linear(cfg.n_embd, cfg.vocab_size, bias=False)

        # weight tying: input embedding and output projection share parameters
        self.head.weight = self.tok_emb.weight

        self.apply(self._init_weights)
        # scaled init for residual projections (GPT-2 recipe)
        for name, p in self.named_parameters():
            if name.endswith("proj.weight"):
                nn.init.normal_(p, mean=0.0, std=0.02 / math.sqrt(2 * cfg.n_layer))

    @staticmethod
    def _init_weights(module: nn.Module) -> None:
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    # ------------------------------------------------------------------ #
    def num_parameters(self, non_embedding: bool = False) -> int:
        n = sum(p.numel() for p in self.parameters())
        if non_embedding:
            n -= self.pos_emb.weight.numel()
        return n

    def forward(
        self, idx: torch.Tensor, targets: Optional[torch.Tensor] = None,
        ignore_index: int = -100,
    ):
        B, T = idx.shape
        if T > self.cfg.block_size:
            raise ValueError(f"sequence length {T} exceeds block size {self.cfg.block_size}")

        pos = torch.arange(T, device=idx.device, dtype=torch.long)
        x = self.drop(self.tok_emb(idx) + self.pos_emb(pos))
        for block in self.blocks:
            x = block(x)
        x = self.ln_f(x)

        if targets is None:
            # inference shortcut: only the last position is needed
            logits = self.head(x[:, [-1], :])
            return logits, None

        logits = self.head(x)
        loss = F.cross_entropy(
            logits.view(-1, logits.size(-1)),
            targets.reshape(-1),
            ignore_index=ignore_index,
        )
        return logits, loss

    # ------------------------------------------------------------------ #
    # sampling
    # ------------------------------------------------------------------ #
    @torch.no_grad()
    def generate_stream(
        self,
        idx: torch.Tensor,
        max_new_tokens: int = 200,
        temperature: float = 0.9,
        top_k: int = 50,
        top_p: float = 0.95,
        repetition_penalty: float = 1.1,
        presence_penalty: float = 0.0,
        stop_ids: Optional[List[int]] = None,
        banned_ids: Optional[List[int]] = None,
        generator: Optional[torch.Generator] = None,
        should_stop: Optional[Callable[[], bool]] = None,
    ) -> Iterator[int]:
        """Yield one token id at a time. `idx` is a (1, T) LongTensor prompt."""
        self.eval()
        stop = set(stop_ids or [])
        banned = list(banned_ids or [])
        seen: dict[int, int] = {}
        for t in idx[0].tolist():
            seen[t] = seen.get(t, 0) + 1

        for _ in range(int(max_new_tokens)):
            if should_stop is not None and should_stop():
                return

            idx_cond = idx[:, -self.cfg.block_size:]
            logits, _ = self(idx_cond)
            logits = logits[:, -1, :].float()

            if banned:
                logits[:, banned] = float("-inf")

            if seen and (repetition_penalty != 1.0 or presence_penalty != 0.0):
                ids = torch.tensor(list(seen.keys()), device=logits.device, dtype=torch.long)
                vals = logits[0, ids]
                if repetition_penalty != 1.0:
                    vals = torch.where(
                        vals > 0, vals / repetition_penalty, vals * repetition_penalty
                    )
                if presence_penalty != 0.0:
                    vals = vals - presence_penalty
                logits[0, ids] = vals

            if temperature <= 0:
                next_id = int(torch.argmax(logits, dim=-1).item())
            else:
                logits = logits / max(1e-5, float(temperature))

                if top_k and top_k > 0:
                    k = min(int(top_k), logits.size(-1))
                    kth = torch.topk(logits, k, dim=-1).values[:, -1, None]
                    logits = logits.masked_fill(logits < kth, float("-inf"))

                if top_p and 0 < top_p < 1.0:
                    sorted_logits, sorted_idx = torch.sort(logits, descending=True, dim=-1)
                    probs = F.softmax(sorted_logits, dim=-1)
                    cum = torch.cumsum(probs, dim=-1)
                    remove = cum - probs > top_p
                    sorted_logits = sorted_logits.masked_fill(remove, float("-inf"))
                    logits = torch.full_like(logits, float("-inf")).scatter(
                        1, sorted_idx, sorted_logits
                    )

                probs = F.softmax(logits, dim=-1)
                probs = torch.nan_to_num(probs, nan=0.0)
                if float(probs.sum()) <= 0:
                    return
                next_id = int(torch.multinomial(probs, num_samples=1, generator=generator).item())

            if next_id in stop:
                return

            seen[next_id] = seen.get(next_id, 0) + 1
            idx = torch.cat(
                [idx, torch.tensor([[next_id]], device=idx.device, dtype=torch.long)], dim=1
            )
            yield next_id

    @torch.no_grad()
    def generate(self, idx: torch.Tensor, **kwargs) -> List[int]:
        """Non-streaming convenience wrapper: returns the new token ids."""
        return list(self.generate_stream(idx, **kwargs))


def pick_device(preference: str = "auto") -> torch.device:
    """'auto' | 'cuda' | 'cpu' -> a concrete torch.device."""
    pref = (preference or "auto").lower()
    if pref == "cpu":
        return torch.device("cpu")
    if pref == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but not available on this machine.")
        return torch.device("cuda")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def device_description(device: torch.device) -> str:
    if device.type == "cuda":
        i = device.index or 0
        name = torch.cuda.get_device_name(i)
        total = torch.cuda.get_device_properties(i).total_memory / (1024 ** 3)
        return f"CUDA - {name} ({total:.1f} GB)"
    return "CPU"
