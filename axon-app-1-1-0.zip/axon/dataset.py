"""Dataset loading and construction.

Supported inputs
----------------
.txt   plain text. Blank-line separated paragraphs become documents. If the
       file uses "User: ... / Bot: ..." lines, those are parsed as dialogue.
.json  any of:
         [{"prompt": ..., "response": ...}, ...]
         [{"instruction": ..., "output": ...}, ...]     (optional "input")
         [{"input": ..., "output": ...}, ...]
         [{"messages": [{"role": "user", "content": ...}, ...]}, ...]
         [["question", "answer"], ...]
         ["free text", "free text", ...]
.jsonl same shapes, one object per line.

Everything is converted into either a (prompt, response) pair or a raw document,
then into token sequences the Transformer trains on.
"""
from __future__ import annotations

import json
import random
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch
from torch.utils.data import Dataset

from axon.tokenizer import BOS, BOT, EOT, MEM, SYS, USER, BPETokenizer

IGNORE_INDEX = -100

DEFAULT_SYSTEM = (
    "You are AXON, a helpful, curious and concise assistant that learns from "
    "every conversation."
)

_DIALOGUE_LINE = re.compile(
    r"^\s*(user|human|you|q|question|me|bot|axon|assistant|ai|a|answer)\s*[:>-]\s*(.*)$",
    re.I,
)
_USER_ROLES = {"user", "human", "you", "q", "question", "me"}


# --------------------------------------------------------------------------- #
# prompt formatting
# --------------------------------------------------------------------------- #
def format_pair(prompt: str, response: str, system: Optional[str] = None,
                memory: Optional[str] = None) -> str:
    """Render one training example in AXON's chat format."""
    parts = [BOS]
    if system:
        parts.append(f"{SYS}{system.strip()}{EOT}")
    if memory:
        parts.append(f"{MEM}{memory.strip()}{EOT}")
    parts.append(f"{USER}{prompt.strip()}{EOT}")
    parts.append(f"{BOT}{response.strip()}{EOT}")
    return "".join(parts)


def build_chat_prompt(
    user_message: str,
    history: Sequence[Tuple[str, str]] = (),
    system: Optional[str] = DEFAULT_SYSTEM,
    memory: Optional[str] = None,
) -> str:
    """Render an inference prompt; the model continues after the final <|bot|>."""
    parts = [BOS]
    if system:
        parts.append(f"{SYS}{system.strip()}{EOT}")
    if memory:
        parts.append(f"{MEM}{memory.strip()}{EOT}")
    for role, content in history:
        tag = USER if role == "user" else BOT
        parts.append(f"{tag}{content.strip()}{EOT}")
    parts.append(f"{USER}{user_message.strip()}{EOT}")
    parts.append(BOT)
    return "".join(parts)


# --------------------------------------------------------------------------- #
# file loaders
# --------------------------------------------------------------------------- #
def _pairs_from_dialogue_lines(lines: List[str]) -> List[Tuple[str, str]]:
    pairs: List[Tuple[str, str]] = []
    pending_user: Optional[str] = None
    buf_role: Optional[str] = None
    buf: List[str] = []

    def flush() -> None:
        nonlocal pending_user, buf_role, buf
        if buf_role is None:
            buf = []
            return
        text = " ".join(x.strip() for x in buf if x.strip()).strip()
        buf = []
        if not text:
            buf_role = None
            return
        if buf_role in _USER_ROLES:
            pending_user = text
        elif pending_user:
            pairs.append((pending_user, text))
            pending_user = None
        buf_role = None

    for line in lines:
        m = _DIALOGUE_LINE.match(line)
        if m:
            flush()
            buf_role = m.group(1).lower()
            buf = [m.group(2)]
        elif buf_role is not None:
            buf.append(line)
    flush()
    return pairs


def load_txt(path: Path) -> Tuple[List[Tuple[str, str]], List[str]]:
    text = path.read_text(encoding="utf-8", errors="replace")

    # Many public corpora (TinyStories, OpenWebText dumps, ...) separate their
    # documents with a literal <|endoftext|> marker rather than a blank line.
    if "<|endoftext|>" in text:
        docs = [d.strip() for d in text.split("<|endoftext|>") if d.strip()]
        return [], docs

    lines = text.splitlines()
    dialogue_hits = sum(1 for ln in lines[:400] if _DIALOGUE_LINE.match(ln))
    if dialogue_hits >= 4:
        pairs = _pairs_from_dialogue_lines(lines)
        if pairs:
            return pairs, []
    docs = [blk.strip() for blk in re.split(r"\n\s*\n", text) if blk.strip()]
    return [], docs


def _pair_from_obj(obj: dict) -> Optional[Tuple[str, str]]:
    if "prompt" in obj and "response" in obj:
        return str(obj["prompt"]), str(obj["response"])
    if "instruction" in obj and ("output" in obj or "response" in obj):
        instr = str(obj["instruction"])
        # "input" (Alpaca) and "context" (Dolly) both carry the passage the answer
        # depends on - dropping it teaches the model to invent facts
        extra = str(obj.get("input", "") or obj.get("context", "")).strip()
        if extra:
            instr = f"{instr}\n{extra}"
        return instr, str(obj.get("output", obj.get("response", "")))
    if "input" in obj and "output" in obj:
        return str(obj["input"]), str(obj["output"])
    if "question" in obj and "answer" in obj:
        return str(obj["question"]), str(obj["answer"])
    if "user" in obj and ("bot" in obj or "assistant" in obj):
        return str(obj["user"]), str(obj.get("bot", obj.get("assistant", "")))
    return None


def _pairs_from_messages(messages: List[dict]) -> List[Tuple[str, str]]:
    pairs: List[Tuple[str, str]] = []
    pending: Optional[str] = None
    for m in messages:
        if not isinstance(m, dict):
            continue
        role = str(m.get("role", "")).lower()
        content = str(m.get("content", "")).strip()
        if not content:
            continue
        if role in ("user", "human"):
            pending = content
        elif role in ("assistant", "bot", "ai", "axon") and pending:
            pairs.append((pending, content))
            pending = None
    return pairs


def _consume_json_item(item, pairs: List[Tuple[str, str]], docs: List[str]) -> None:
    if isinstance(item, str):
        if item.strip():
            docs.append(item.strip())
    elif isinstance(item, (list, tuple)):
        if len(item) == 2 and all(isinstance(x, str) for x in item):
            pairs.append((item[0], item[1]))
        else:
            for sub in item:
                _consume_json_item(sub, pairs, docs)
    elif isinstance(item, dict):
        if isinstance(item.get("messages"), list):
            pairs.extend(_pairs_from_messages(item["messages"]))
            return
        pair = _pair_from_obj(item)
        if pair:
            pairs.append(pair)
        elif isinstance(item.get("text"), str):
            docs.append(item["text"])


def load_json(path: Path) -> Tuple[List[Tuple[str, str]], List[str]]:
    pairs: List[Tuple[str, str]] = []
    docs: List[str] = []
    raw = path.read_text(encoding="utf-8", errors="replace").strip()
    if not raw:
        return pairs, docs

    if path.suffix.lower() == ".jsonl":
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                _consume_json_item(json.loads(line), pairs, docs)
            except json.JSONDecodeError:
                continue
        return pairs, docs

    data = json.loads(raw)
    if isinstance(data, dict):
        if isinstance(data.get("messages"), list):
            pairs.extend(_pairs_from_messages(data["messages"]))
            return pairs, docs
        for value in data.values():
            _consume_json_item(value, pairs, docs)
    else:
        _consume_json_item(data, pairs, docs)
    return pairs, docs


def load_path(path: str | Path) -> Tuple[List[Tuple[str, str]], List[str]]:
    """Load one file or every supported file inside a directory."""
    p = Path(path)
    pairs: List[Tuple[str, str]] = []
    docs: List[str] = []
    if p.is_dir():
        files = sorted(
            f for f in p.rglob("*")
            if f.is_file() and f.suffix.lower() in (".txt", ".json", ".jsonl", ".md")
        )
    else:
        files = [p]
    for f in files:
        if not f.exists():
            continue
        try:
            if f.suffix.lower() in (".json", ".jsonl"):
                fp, fd = load_json(f)
            else:
                fp, fd = load_txt(f)
        except Exception as exc:  # keep going on a malformed file
            print(f"[dataset] skipped {f}: {exc}")
            continue
        pairs.extend(fp)
        docs.extend(fd)
    return pairs, docs


# --------------------------------------------------------------------------- #
# torch datasets
# --------------------------------------------------------------------------- #
class ConversationDataset(Dataset):
    """(prompt, response) pairs. Loss is computed on the response only."""

    def __init__(
        self,
        pairs: Sequence[Tuple[str, str]],
        tokenizer: BPETokenizer,
        block_size: int,
        system: Optional[str] = DEFAULT_SYSTEM,
    ) -> None:
        self.block_size = block_size
        self.pad_id = tokenizer.pad_id
        self.examples: List[Tuple[List[int], List[bool]]] = []

        sys_ids = tokenizer.encode(f"{SYS}{system.strip()}{EOT}") if system else []
        bos = [tokenizer.special_id(BOS)]

        for prompt, response in pairs:
            prompt, response = prompt.strip(), response.strip()
            if not prompt or not response:
                continue
            head = bos + sys_ids + tokenizer.encode(f"{USER}{prompt}{EOT}{BOT}")
            tail = tokenizer.encode(f"{response}{EOT}")
            ids = head + tail
            mask = [False] * len(head) + [True] * len(tail)
            if len(ids) > block_size + 1:            # keep the answer, drop old context
                ids = ids[-(block_size + 1):]
                mask = mask[-(block_size + 1):]
            if not any(mask):
                continue
            self.examples.append((ids, mask))

    def __len__(self) -> int:
        return len(self.examples)

    @property
    def lengths(self) -> List[int]:
        """Token length of each example, for length-grouped batching."""
        return [len(ids) - 1 for ids, _ in self.examples]

    def __getitem__(self, i: int):
        # Deliberately NOT padded to block_size: the collate function pads each
        # batch to its own longest member instead. The median example is ~70
        # tokens, so padding everything to 256 would waste most of the compute.
        ids, mask = self.examples[i]
        x = torch.tensor(ids[:-1], dtype=torch.long)
        y = torch.tensor(
            [t if m else IGNORE_INDEX for t, m in zip(ids[1:], mask[1:])], dtype=torch.long
        )
        return x, y


class TokenBlockDataset(Dataset):
    """Raw documents packed into a contiguous token stream of fixed blocks."""

    def __init__(
        self,
        docs: Sequence[str],
        tokenizer: BPETokenizer,
        block_size: int,
        stride: Optional[int] = None,
    ) -> None:
        self.block_size = block_size
        stream: List[int] = []
        eot = tokenizer.eot_id
        bos = tokenizer.special_id(BOS)
        for doc in docs:
            doc = doc.strip()
            if not doc:
                continue
            stream.append(bos)
            stream.extend(tokenizer.encode(doc))
            stream.append(eot)
        self.data = torch.tensor(stream, dtype=torch.long)
        self.stride = stride or block_size
        n = max(0, (len(self.data) - block_size - 1))
        self.n_blocks = (n // self.stride) + 1 if len(self.data) > block_size + 1 else 0

    def __len__(self) -> int:
        return self.n_blocks

    @property
    def lengths(self) -> List[int]:
        return [self.block_size] * self.n_blocks

    def __getitem__(self, i: int):
        start = i * self.stride
        chunk = self.data[start: start + self.block_size + 1]
        return chunk[:-1].clone(), chunk[1:].clone()


class MixedDataset(Dataset):
    """Concatenates any number of datasets and shuffles deterministically."""

    def __init__(self, datasets: Sequence[Dataset], seed: int = 1234) -> None:
        self.parts = [d for d in datasets if len(d) > 0]
        self.index: List[Tuple[int, int]] = [
            (di, i) for di, d in enumerate(self.parts) for i in range(len(d))
        ]
        random.Random(seed).shuffle(self.index)

    def __len__(self) -> int:
        return len(self.index)

    @property
    def lengths(self) -> List[int]:
        part_lengths = [p.lengths for p in self.parts]
        return [part_lengths[di][ii] for di, ii in self.index]

    def __getitem__(self, i: int):
        di, ii = self.index[i]
        return self.parts[di][ii]


# --------------------------------------------------------------------------- #
# batching
# --------------------------------------------------------------------------- #
def example_lengths(dataset) -> Optional[List[int]]:
    """Token length of every example, seeing through Subset wrappers."""
    if isinstance(dataset, torch.utils.data.Subset):
        inner = example_lengths(dataset.dataset)
        return None if inner is None else [inner[i] for i in dataset.indices]
    lengths = getattr(dataset, "lengths", None)
    return list(lengths) if lengths is not None else None


def make_collate(pad_id: int):
    """Pad each batch to its own longest member, not to the full block size."""

    def collate(batch):
        xs, ys = zip(*batch)
        width = max(x.size(0) for x in xs)
        n = len(xs)
        x_out = torch.full((n, width), pad_id, dtype=torch.long)
        y_out = torch.full((n, width), IGNORE_INDEX, dtype=torch.long)
        for i, (x, y) in enumerate(zip(xs, ys)):
            x_out[i, : x.size(0)] = x
            y_out[i, : y.size(0)] = y
        return x_out, y_out

    return collate


class LengthGroupedBatchSampler(torch.utils.data.Sampler):
    """Batch together examples of similar length, while staying shuffled.

    Indices are shuffled, cut into large chunks, and each chunk is sorted by
    length before being split into batches. Batch order is then shuffled again.
    Batches end up nearly uniform in length -- so padding almost vanishes --
    without the model ever seeing the data in a fixed order.
    """

    def __init__(self, lengths: Sequence[int], batch_size: int,
                 shuffle: bool = True, seed: int = 0, chunk_factor: int = 32) -> None:
        self.lengths = list(lengths)
        self.batch_size = max(1, int(batch_size))
        self.shuffle = shuffle
        self.seed = seed
        self.chunk = self.batch_size * max(1, chunk_factor)
        self.epoch = 0

    def __len__(self) -> int:
        return (len(self.lengths) + self.batch_size - 1) // self.batch_size

    def set_epoch(self, epoch: int) -> None:
        self.epoch = epoch

    def __iter__(self):
        idx = list(range(len(self.lengths)))
        rng = random.Random(self.seed + self.epoch)
        if self.shuffle:
            rng.shuffle(idx)

        batches: List[List[int]] = []
        for start in range(0, len(idx), self.chunk):
            block = sorted(idx[start: start + self.chunk], key=lambda i: self.lengths[i])
            for b in range(0, len(block), self.batch_size):
                batches.append(block[b: b + self.batch_size])

        if self.shuffle:
            rng.shuffle(batches)
        return iter(batches)


# --------------------------------------------------------------------------- #
# corpus assembly
# --------------------------------------------------------------------------- #
def gather_corpus(
    paths: Iterable[str | Path] = (),
    memory=None,
    include_memory: bool = True,
    min_rating: int = 0,
    max_pairs: int = 0,
    max_prompt_chars: int = 0,
    max_response_chars: int = 0,
    max_docs: int = 0,
    seed: int = 1234,
) -> Dict[str, list]:
    """Collect pairs + documents from files and (optionally) stored chat samples.

    The three limits exist so a large corpus stays trainable on a CPU:
    `max_prompt_chars` / `max_response_chars` drop over-long examples (a small
    model cannot learn them anyway), and `max_pairs` takes a deterministic
    random subsample of whatever survives. 0 means "no limit".
    """
    pairs: List[Tuple[str, str]] = []
    docs: List[str] = []
    for p in paths:
        fp, fd = load_path(p)
        pairs.extend(fp)
        docs.extend(fd)

    if include_memory and memory is not None:
        for s in memory.get_samples(min_rating=min_rating):
            pairs.append((s.prompt, s.response))

    if max_prompt_chars > 0:
        pairs = [(p, r) for p, r in pairs if len(p) <= max_prompt_chars]
    if max_response_chars > 0:
        pairs = [(p, r) for p, r in pairs if len(r) <= max_response_chars]
    if max_pairs > 0 and len(pairs) > max_pairs:
        rng = random.Random(seed)
        pairs = rng.sample(pairs, max_pairs)
    if max_docs > 0 and len(docs) > max_docs:
        docs = random.Random(seed + 1).sample(docs, max_docs)

    return {"pairs": pairs, "docs": docs}


def corpus_texts(corpus: Dict[str, list], system: Optional[str] = DEFAULT_SYSTEM) -> List[str]:
    """Flatten a corpus into plain strings, used for tokenizer training."""
    texts = [format_pair(p, r, system=system) for p, r in corpus["pairs"]]
    texts.extend(corpus["docs"])
    return texts


def build_datasets(
    corpus: Dict[str, list],
    tokenizer: BPETokenizer,
    block_size: int,
    val_split: float = 0.05,
    seed: int = 1234,
) -> Tuple[Dataset, Optional[Dataset], Dict[str, int]]:
    """Turn a corpus into (train_dataset, val_dataset, stats)."""
    conv = ConversationDataset(corpus["pairs"], tokenizer, block_size)
    text = TokenBlockDataset(corpus["docs"], tokenizer, block_size)
    full = MixedDataset([conv, text], seed=seed)

    stats = {
        "pairs": len(corpus["pairs"]),
        "documents": len(corpus["docs"]),
        "conversation_examples": len(conv),
        "text_blocks": len(text),
        "total_examples": len(full),
        "text_tokens": int(text.data.numel()),
    }
    if len(full) == 0:
        return full, None, stats

    n_val = int(len(full) * max(0.0, min(0.5, val_split)))
    if n_val < 1 or len(full) - n_val < 1:
        return full, None, stats

    generator = torch.Generator().manual_seed(seed)
    train_set, val_set = torch.utils.data.random_split(
        full, [len(full) - n_val, n_val], generator=generator
    )
    stats["train_examples"] = len(train_set)
    stats["val_examples"] = len(val_set)
    return train_set, val_set, stats
