"""Training loop, checkpointing and online (continuous) learning."""
from __future__ import annotations

import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import torch
from torch.utils.data import DataLoader, Dataset

from axon.config import ModelConfig, TrainConfig
from axon.dataset import (
    IGNORE_INDEX,
    ConversationDataset,
    LengthGroupedBatchSampler,
    example_lengths,
    make_collate,
)
from axon.locking import checkpoint_lock
from axon.model import AxonTransformer
from axon.tokenizer import BPETokenizer

CHECKPOINT_VERSION = 1


# --------------------------------------------------------------------------- #
# checkpoints
# --------------------------------------------------------------------------- #
def save_checkpoint(
    path: str | Path,
    model: AxonTransformer,
    tokenizer: BPETokenizer,
    step: int = 0,
    epoch: int = 0,
    val_loss: Optional[float] = None,
    train_loss: Optional[float] = None,
    extra: Optional[dict] = None,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": CHECKPOINT_VERSION,
        "model_config": model.cfg.to_dict(),
        "model_state": model.state_dict(),
        "tokenizer": tokenizer.to_json(),
        "step": int(step),
        "epoch": int(epoch),
        "val_loss": val_loss,
        "train_loss": train_loss,
        "saved_at": time.time(),
        "extra": extra or {},
    }
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, tmp)
    tmp.replace(path)                      # atomic-ish: never leave a half file
    return path


def load_checkpoint(
    path: str | Path, device: Optional[torch.device] = None
) -> Tuple[AxonTransformer, BPETokenizer, dict]:
    path = Path(path)
    payload = torch.load(path, map_location=device or "cpu", weights_only=False)
    cfg = ModelConfig.from_dict(payload["model_config"])
    tokenizer = BPETokenizer.from_json(payload["tokenizer"])
    model = AxonTransformer(cfg)
    model.load_state_dict(payload["model_state"])
    if device is not None:
        model.to(device)
    meta = {k: v for k, v in payload.items() if k not in ("model_state", "tokenizer")}
    return model, tokenizer, meta


def inspect_checkpoint(path: str | Path) -> dict:
    """Read a checkpoint's metadata without building the model."""
    payload = torch.load(Path(path), map_location="cpu", weights_only=False)
    return {
        "model_config": payload.get("model_config", {}),
        "step": payload.get("step", 0),
        "epoch": payload.get("epoch", 0),
        "val_loss": payload.get("val_loss"),
        "train_loss": payload.get("train_loss"),
        "saved_at": payload.get("saved_at"),
        "vocab_size": payload.get("model_config", {}).get("vocab_size"),
        "extra": payload.get("extra", {}) or {},
    }


# --------------------------------------------------------------------------- #
# optimizer / schedule
# --------------------------------------------------------------------------- #
def build_optimizer(model: AxonTransformer, cfg: TrainConfig) -> torch.optim.Optimizer:
    """AdamW with weight decay on matrices only (not on biases / LayerNorms)."""
    decay, no_decay = [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        (decay if p.dim() >= 2 else no_decay).append(p)
    groups = [
        {"params": decay, "weight_decay": cfg.weight_decay},
        {"params": no_decay, "weight_decay": 0.0},
    ]
    fused_ok = torch.cuda.is_available()
    try:
        return torch.optim.AdamW(
            groups, lr=cfg.learning_rate, betas=(cfg.beta1, cfg.beta2), fused=fused_ok
        )
    except (TypeError, RuntimeError):
        return torch.optim.AdamW(groups, lr=cfg.learning_rate, betas=(cfg.beta1, cfg.beta2))


def lr_at(step: int, total: int, cfg: TrainConfig) -> float:
    """Linear warmup then cosine decay to min_lr_ratio * lr."""
    warmup = max(1, int(total * cfg.warmup_ratio))
    if step < warmup:
        return cfg.learning_rate * (step + 1) / warmup
    if total <= warmup:
        return cfg.learning_rate
    progress = (step - warmup) / max(1, total - warmup)
    progress = min(1.0, max(0.0, progress))
    coeff = 0.5 * (1.0 + math.cos(math.pi * progress))
    min_lr = cfg.learning_rate * cfg.min_lr_ratio
    return min_lr + coeff * (cfg.learning_rate - min_lr)


# --------------------------------------------------------------------------- #
# trainer
# --------------------------------------------------------------------------- #
@dataclass
class TrainProgress:
    epoch: int
    total_epochs: int
    step: int
    total_steps: int
    loss: float
    lr: float
    tokens_per_sec: float
    elapsed: float
    val_loss: Optional[float] = None


class Trainer:
    """Full training run over a dataset, with progress callbacks and a stop hook."""

    def __init__(
        self,
        model: AxonTransformer,
        tokenizer: BPETokenizer,
        device: torch.device,
        cfg: TrainConfig,
        checkpoint_path: Optional[str | Path] = None,
        on_log: Optional[Callable[[str], None]] = None,
        on_progress: Optional[Callable[[TrainProgress], None]] = None,
        should_stop: Optional[Callable[[], bool]] = None,
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.cfg = cfg
        self.checkpoint_path = Path(checkpoint_path) if checkpoint_path else None
        self.on_log = on_log or (lambda msg: print(msg))
        self.on_progress = on_progress or (lambda p: None)
        self.should_stop = should_stop or (lambda: False)
        self.history: List[Dict[str, float]] = []

        self.use_amp = bool(cfg.amp and device.type == "cuda")
        if self.use_amp:
            self.amp_dtype = (
                torch.bfloat16
                if torch.cuda.is_available() and torch.cuda.is_bf16_supported()
                else torch.float16
            )
        else:
            self.amp_dtype = torch.float32
        self.scaler = torch.amp.GradScaler(
            "cuda", enabled=self.use_amp and self.amp_dtype is torch.float16
        )

    # ------------------------------------------------------------------ #
    def _autocast(self):
        if self.use_amp:
            return torch.amp.autocast("cuda", dtype=self.amp_dtype)
        return torch.amp.autocast("cpu", enabled=False)

    @torch.no_grad()
    def evaluate(self, loader: DataLoader, max_batches: int = 50) -> float:
        self.model.eval()
        total, n = 0.0, 0
        for i, (x, y) in enumerate(loader):
            if i >= max_batches or self.should_stop():
                break
            x = x.to(self.device, non_blocking=True)
            y = y.to(self.device, non_blocking=True)
            with self._autocast():
                _, loss = self.model(x, y, ignore_index=IGNORE_INDEX)
            if loss is not None and torch.isfinite(loss):
                total += float(loss.item())
                n += 1
        self.model.train()
        return total / max(1, n)

    # ------------------------------------------------------------------ #
    def train(
        self, train_set: Dataset, val_set: Optional[Dataset] = None
    ) -> Dict[str, float]:
        """Train, holding an exclusive lock on the checkpoint for the whole run.

        The lock is what stops a second `train.py` (or the GUI) from training
        the same file at the same time and overwriting this run's saves.
        """
        with checkpoint_lock(self.checkpoint_path):
            return self._train(train_set, val_set)

    def _train(
        self, train_set: Dataset, val_set: Optional[Dataset] = None
    ) -> Dict[str, float]:
        cfg = self.cfg
        if len(train_set) == 0:
            raise ValueError("Training set is empty - add some data first.")

        pin = self.device.type == "cuda"
        collate = make_collate(self.tokenizer.pad_id)

        # Group examples of similar length into the same batch. Chat examples
        # have a median length of ~70 tokens against a 256-token block, so
        # padding every batch to the full block wastes most of the compute.
        train_lengths = example_lengths(train_set)
        self.batch_sampler = (
            LengthGroupedBatchSampler(train_lengths, cfg.batch_size, shuffle=True)
            if train_lengths is not None else None
        )
        if self.batch_sampler is not None:
            train_loader = DataLoader(
                train_set, batch_sampler=self.batch_sampler,
                num_workers=cfg.num_workers, pin_memory=pin, collate_fn=collate,
            )
        else:
            train_loader = DataLoader(
                train_set, batch_size=cfg.batch_size, shuffle=True, drop_last=False,
                num_workers=cfg.num_workers, pin_memory=pin, collate_fn=collate,
            )

        val_lengths = example_lengths(val_set) if val_set is not None else None
        if val_set is not None and len(val_set) > 0:
            if val_lengths is not None:
                val_loader = DataLoader(
                    val_set,
                    batch_sampler=LengthGroupedBatchSampler(
                        val_lengths, cfg.batch_size, shuffle=False
                    ),
                    num_workers=0, pin_memory=pin, collate_fn=collate,
                )
            else:
                val_loader = DataLoader(
                    val_set, batch_size=cfg.batch_size, shuffle=False,
                    num_workers=0, pin_memory=pin, collate_fn=collate,
                )
        else:
            val_loader = None

        self.model.to(self.device).train()
        optimizer = build_optimizer(self.model, cfg)

        steps_per_epoch = max(1, math.ceil(len(train_loader) / max(1, cfg.grad_accum)))
        total_steps = steps_per_epoch * cfg.epochs
        block = self.model.cfg.block_size

        self.on_log(
            f"Training on {len(train_set):,} examples "
            f"({len(val_set) if val_set else 0:,} held out for validation)"
        )
        self.on_log(
            f"{total_steps:,} optimizer steps | batch {cfg.batch_size}"
            f"{f' x{cfg.grad_accum} accum' if cfg.grad_accum > 1 else ''} | "
            f"lr {cfg.learning_rate:g} | device {self.device.type}"
            f"{f' | amp {str(self.amp_dtype).split(chr(46))[-1]}' if self.use_amp else ''}"
        )

        step = 0
        best_val = float("inf")
        last_val: Optional[float] = None
        started = time.time()
        last_report = started
        tokens_since = 0
        running: List[float] = []
        stopped = False

        for epoch in range(cfg.epochs):
            if stopped:
                break
            if self.batch_sampler is not None:
                self.batch_sampler.set_epoch(epoch)
            optimizer.zero_grad(set_to_none=True)
            micro = 0

            for x, y in train_loader:
                if self.should_stop():
                    self.on_log("Stop requested - finishing up.")
                    stopped = True
                    break

                x = x.to(self.device, non_blocking=True)
                y = y.to(self.device, non_blocking=True)

                with self._autocast():
                    _, loss = self.model(x, y, ignore_index=IGNORE_INDEX)
                    loss_value = float(loss.item())
                    loss = loss / cfg.grad_accum

                if not math.isfinite(loss_value):
                    optimizer.zero_grad(set_to_none=True)
                    micro = 0
                    self.on_log("Non-finite loss on a batch - skipped.")
                    continue

                self.scaler.scale(loss).backward()
                running.append(loss_value)
                tokens_since += x.numel()
                micro += 1

                if micro < cfg.grad_accum:
                    continue
                micro = 0

                lr = lr_at(step, total_steps, cfg)
                for group in optimizer.param_groups:
                    group["lr"] = lr

                if cfg.grad_clip > 0:
                    self.scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), cfg.grad_clip)
                self.scaler.step(optimizer)
                self.scaler.update()
                optimizer.zero_grad(set_to_none=True)
                step += 1

                if step % max(1, cfg.log_every) == 0 or step == total_steps:
                    now = time.time()
                    dt = max(1e-6, now - last_report)
                    tps = tokens_since / dt
                    avg = sum(running) / max(1, len(running))
                    running.clear()
                    tokens_since = 0
                    last_report = now
                    prog = TrainProgress(
                        epoch=epoch + 1, total_epochs=cfg.epochs, step=step,
                        total_steps=total_steps, loss=avg, lr=lr,
                        tokens_per_sec=tps, elapsed=now - started,
                    )
                    self.history.append({"step": step, "loss": avg, "lr": lr})
                    self.on_progress(prog)
                    self.on_log(
                        f"epoch {epoch + 1}/{cfg.epochs}  step {step}/{total_steps}  "
                        f"loss {avg:.4f}  ppl {math.exp(min(20, avg)):.1f}  "
                        f"lr {lr:.2e}  {tps:,.0f} tok/s"
                    )

                if val_loader is not None and cfg.eval_every and step % cfg.eval_every == 0:
                    vloss = self.evaluate(val_loader)
                    last_val = vloss
                    self.on_log(f"  validation loss {vloss:.4f}")
                    if vloss < best_val:
                        best_val = vloss
                    self.on_progress(
                        TrainProgress(epoch + 1, cfg.epochs, step, total_steps,
                                      vloss, lr, 0.0, time.time() - started, val_loss=vloss)
                    )

                if self.checkpoint_path and cfg.save_every and step % cfg.save_every == 0:
                    save_checkpoint(self.checkpoint_path, self.model, self.tokenizer,
                                    step=step, epoch=epoch + 1, val_loss=last_val,
                                    extra={"best_val_loss": None if best_val == float("inf")
                                           else best_val})
                    self.on_log(f"  checkpoint saved -> {self.checkpoint_path}")

            # end of epoch
            if val_loader is not None and not stopped:
                vloss = self.evaluate(val_loader)
                last_val = vloss
                best_val = min(best_val, vloss)
                self.on_log(f"epoch {epoch + 1} complete - validation loss {vloss:.4f}")
            if self.checkpoint_path:
                save_checkpoint(self.checkpoint_path, self.model, self.tokenizer,
                                step=step, epoch=epoch + 1, val_loss=last_val,
                                extra={"best_val_loss": None if best_val == float("inf")
                                       else best_val})

        elapsed = time.time() - started
        if self.checkpoint_path:
            save_checkpoint(self.checkpoint_path, self.model, self.tokenizer,
                            step=step, epoch=cfg.epochs, val_loss=last_val,
                            extra={"best_val_loss": None if best_val == float("inf")
                                   else best_val})
            self.on_log(f"Final checkpoint -> {self.checkpoint_path}")
        if last_val is not None and best_val < float("inf") and last_val > best_val * 1.05:
            self.on_log(
                f"Warning: final validation loss {last_val:.4f} is above the best seen "
                f"({best_val:.4f}) - the model is overfitting. Use fewer epochs or more data."
            )
        self.on_log(f"Done in {elapsed / 60:.1f} min ({step:,} steps).")
        return {
            "steps": step,
            "elapsed": elapsed,
            "val_loss": last_val,
            "best_val_loss": None if best_val == float("inf") else best_val,
            "stopped_early": stopped,
        }


# --------------------------------------------------------------------------- #
# online learning
# --------------------------------------------------------------------------- #
class OnlineLearner:
    """Small gradient updates applied after conversations, without a full run.

    This is what makes AXON "learn from every chat": recent exchanges are
    replayed through the model at a very low learning rate. Replaying a window
    of older samples alongside the newest one limits catastrophic forgetting.
    """

    def __init__(
        self,
        model: AxonTransformer,
        tokenizer: BPETokenizer,
        device: torch.device,
        learning_rate: float = 5e-5,
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.learning_rate = learning_rate
        self.optimizer = torch.optim.AdamW(
            [p for p in model.parameters() if p.requires_grad],
            lr=learning_rate, betas=(0.9, 0.95), weight_decay=0.01,
        )

    def set_learning_rate(self, lr: float) -> None:
        self.learning_rate = lr
        for g in self.optimizer.param_groups:
            g["lr"] = lr

    def update(
        self,
        pairs: Sequence[Tuple[str, str]],
        steps: int = 6,
        batch_size: int = 4,
        grad_clip: float = 1.0,
    ) -> Optional[float]:
        """Run `steps` gradient steps over `pairs`. Returns the mean loss."""
        if not pairs:
            return None
        ds = ConversationDataset(pairs, self.tokenizer, self.model.cfg.block_size)
        if len(ds) == 0:
            return None

        loader = DataLoader(
            ds, batch_size=min(batch_size, len(ds)), shuffle=True, drop_last=False,
            collate_fn=make_collate(self.tokenizer.pad_id),
        )
        self.model.to(self.device).train()
        losses: List[float] = []
        done = 0
        while done < steps:
            for x, y in loader:
                if done >= steps:
                    break
                x = x.to(self.device)
                y = y.to(self.device)
                _, loss = self.model(x, y, ignore_index=IGNORE_INDEX)
                if loss is None or not torch.isfinite(loss):
                    continue
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                if grad_clip > 0:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), grad_clip)
                self.optimizer.step()
                losses.append(float(loss.item()))
                done += 1
        self.model.eval()
        return sum(losses) / len(losses) if losses else None
