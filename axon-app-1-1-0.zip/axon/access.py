"""Who is allowed to change the models.

AXON has two roles:

  admin  -- you. Can train, create models, publish versions, install updates.
  user   -- your friends. Can chat, and nothing else.

Be clear about what this is: a lock on the interface, not real security. It
stops a friend clicking Train and ruining your model. It does NOT stop someone
who edits the Python files or swaps the .pt file by hand. The password is
stored as a scrypt hash, so the password itself is never written to disk, but
anyone with the folder still owns the files.
"""
from __future__ import annotations

import hashlib
import os
import secrets
import time
from dataclasses import dataclass
from typing import Optional

ROLE_ADMIN = "admin"
ROLE_USER = "user"

META_KEY = "access.admin"
ATTEMPTS_KEY = "access.attempts"

# Guessing is throttled: after a few wrong passwords the lock closes for a
# while, and the wait doubles each time. Without this, a four character
# password falls to a script in seconds.
FREE_ATTEMPTS = 3
BASE_LOCKOUT = 15.0        # seconds, doubling per further failure
MAX_LOCKOUT = 15 * 60.0

# scrypt parameters: strong enough that guessing is slow, cheap enough that
# unlocking feels instant on a laptop. scrypt needs 128 * N * r bytes, so
# N = 2**14 with r = 8 costs ~16 MB; maxmem is passed explicitly because
# OpenSSL's own default cap is 32 MB and refuses anything larger.
_N, _R, _P, _DKLEN = 2 ** 14, 8, 1, 32
_MAXMEM = 64 * 1024 * 1024


def _hash(password: str, salt: bytes) -> str:
    return hashlib.scrypt(
        password.encode("utf-8"),
        salt=salt, n=_N, r=_R, p=_P, dklen=_DKLEN, maxmem=_MAXMEM,
    ).hex()


@dataclass
class Capabilities:
    """What the current role is allowed to do.

    Anything that only affects this one copy - temperature, sampling, what it
    remembers about you - is open to everyone. Anything that changes the model
    itself, or what other people receive, is owner only.
    """

    chat: bool = True
    view_memory: bool = True
    rate_replies: bool = True
    device_settings: bool = True      # temperature, top-k, reply length
    install_update: bool = True       # receiving what the owner published
    edit_memory: bool = False
    train: bool = False
    create_model: bool = False
    load_checkpoint: bool = False
    save_checkpoint: bool = False
    publish_version: bool = False

    @classmethod
    def for_role(cls, role: str) -> "Capabilities":
        if role == ROLE_ADMIN:
            return cls(
                edit_memory=True, train=True, create_model=True,
                load_checkpoint=True, save_checkpoint=True,
                publish_version=True,
            )
        return cls()


def read_seal(checkpoint) -> Optional[dict]:
    """Read the lock sealed into a model file, if it has one."""
    try:
        from axon.trainer import inspect_checkpoint
        record = (inspect_checkpoint(checkpoint).get("extra") or {}).get("access")
        return record if record and record.get("hash") and record.get("salt") else None
    except Exception:
        return None


class AccessControl:
    """Holds the current role and checks the owner password.

    The lock lives in two places: the settings database, and - for shipped
    copies - sealed inside the model file itself. Deleting the database is the
    obvious way to try to remove protection, so the sealed copy is what makes
    that pointless: the lock travels with the thing people actually want.
    """

    def __init__(self, memory, seal: Optional[dict] = None) -> None:
        self.memory = memory
        self.seal = seal
        # With no password set, the app is single-user: you are the admin.
        # Once you set one, every launch starts locked.
        self._role = ROLE_USER if self.is_protected else ROLE_ADMIN

    # ------------------------------------------------------------------ #
    @property
    def is_protected(self) -> bool:
        """Is a password set, either in the database or sealed in the model?"""
        if self.seal:
            return True
        record = self.memory.get_meta(META_KEY)
        return bool(record and record.get("hash") and record.get("salt"))

    @property
    def role(self) -> str:
        return self._role

    @property
    def is_admin(self) -> bool:
        return self._role == ROLE_ADMIN

    @property
    def capabilities(self) -> Capabilities:
        return Capabilities.for_role(self._role)

    def can(self, action: str) -> bool:
        return bool(getattr(self.capabilities, action, False))

    # ------------------------------------------------------------------ #
    def set_password(self, password: str, current: Optional[str] = None) -> None:
        """Set or change the admin password.

        Changing an existing password requires the current one, unless this
        session is already unlocked as admin.
        """
        if not password or len(password) < 4:
            raise ValueError("Password must be at least 4 characters.")
        if self.is_protected and not self.is_admin:
            if current is None or not self.verify(current):
                raise PermissionError("Current password is wrong.")

        salt = secrets.token_bytes(16)
        self.memory.set_meta(
            META_KEY, {"salt": salt.hex(), "hash": _hash(password, salt), "version": 1}
        )
        self._role = ROLE_ADMIN

    def clear_password(self, current: str) -> None:
        """Remove protection entirely (needs the current password)."""
        if self.is_protected and not self.verify(current):
            raise PermissionError("Current password is wrong.")
        if self.seal:
            raise PermissionError(
                "This copy's lock is sealed into the model file and cannot be "
                "removed from inside the app."
            )
        self.memory.set_meta(META_KEY, {})
        self._role = ROLE_ADMIN

    def verify(self, password: str) -> bool:
        """True when the password matches the database lock or the sealed one."""
        for record in (self.memory.get_meta(META_KEY) or {}, self.seal or {}):
            stored, salt = record.get("hash"), record.get("salt")
            if not stored or not salt:
                continue
            if secrets.compare_digest(_hash(password, bytes.fromhex(salt)), stored):
                return True
        return False

    # ------------------------------------------------------------------ #
    # ------------------------------------------------------------------ #
    def lockout_remaining(self) -> float:
        """Seconds left before another password may be tried."""
        record = self.memory.get_meta(ATTEMPTS_KEY) or {}
        return max(0.0, float(record.get("until", 0)) - time.time())

    def _record_failure(self) -> None:
        record = self.memory.get_meta(ATTEMPTS_KEY) or {}
        count = int(record.get("count", 0)) + 1
        until = 0.0
        if count > FREE_ATTEMPTS:
            wait = min(MAX_LOCKOUT, BASE_LOCKOUT * (2 ** (count - FREE_ATTEMPTS - 1)))
            until = time.time() + wait
        self.memory.set_meta(ATTEMPTS_KEY, {"count": count, "until": until})

    def _clear_failures(self) -> None:
        self.memory.set_meta(ATTEMPTS_KEY, {"count": 0, "until": 0})

    def unlock(self, password: str) -> bool:
        if not self.is_protected:
            self._role = ROLE_ADMIN
            return True
        if self.lockout_remaining() > 0:
            return False
        if self.verify(password):
            self._role = ROLE_ADMIN
            self._clear_failures()
            self.memory.set_meta("access.last_unlock", time.time())
            return True
        self._record_failure()
        return False

    def lock(self) -> None:
        """Drop back to user mode. Only meaningful when a password exists."""
        self._role = ROLE_USER if self.is_protected else ROLE_ADMIN

    def describe(self) -> str:
        if not self.is_protected:
            return "unprotected - anyone using this copy can edit the models"
        where = " (sealed to the model)" if self.seal else ""
        return ("owner (unlocked)" if self.is_admin else "user (locked)") + where


def env_admin_password() -> Optional[str]:
    """Allow AXON_ADMIN_PASSWORD for headless/admin scripts."""
    return os.environ.get("AXON_ADMIN_PASSWORD") or None
