"""Release history, shown in the app as What's New.

Add a new Release at the TOP of the list when you ship something. The app shows
the newest entry automatically the first time someone opens a version they have
not seen before, and Help -> What's New shows the full history.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass(frozen=True)
class Release:
    version: str
    date: str
    headline: str
    added: List[str] = field(default_factory=list)
    improved: List[str] = field(default_factory=list)
    fixed: List[str] = field(default_factory=list)

    def sections(self):
        for title, items in (("New", self.added), ("Improved", self.improved),
                             ("Fixed", self.fixed)):
            if items:
                yield title, items


RELEASES: List[Release] = [
    Release(
        version="1.0.0",
        date="2026-08-28",
        headline="Vesper Spark 1 - the first release",
        added=[
            "Vesper Spark 1: a 3.4 million parameter language model that runs "
            "entirely on your own computer.",
            "Chat with streaming replies, saved conversation history, and a "
            "memory that remembers things you tell it.",
            "Good / Bad buttons under every reply. Marking a reply Good is what "
            "lets AXON learn from it.",
            "Model switcher, so you can move between Vesper models as they are "
            "released.",
            "Command Center for owners: model versions, publishing and updates.",
            "Weekly update checks, with every download checked against its "
            "SHA-256 before it is installed.",
        ],
        improved=[
            "Training is around 16% faster: batches are now grouped by length, "
            "so padding dropped from 67% of every batch to under 2%.",
            "Replies run cooler by default (temperature 0.7), which this model "
            "size holds together far better than 0.9.",
        ],
        fixed=[
            "Replies that collapse into nonsense are now detected, kept out of "
            "the conversation history and never used as training data. "
            "Previously one bad reply dragged down every reply after it.",
            "Continuous learning can no longer damage the model: the learning "
            "rate is capped, and only replies you mark Good are ever learned "
            "from.",
            "Two training runs can no longer overwrite each other's work.",
            "Ctrl+C during training now saves properly instead of losing the run.",
            "The side panel no longer gets cut off on smaller windows.",
        ],
    ),
]


def latest() -> Optional[Release]:
    return RELEASES[0] if RELEASES else None


def since(version: Optional[str]) -> List[Release]:
    """Releases newer than `version` (all of them when it is unknown)."""
    if not version:
        return list(RELEASES)
    out = []
    for release in RELEASES:
        if release.version == version:
            break
        out.append(release)
    return out


def as_html(releases: List[Release], accent: str = "#A97BFF",
            muted: str = "#9A93AB") -> str:
    """Render releases for the What's New dialog."""
    blocks = []
    for release in releases:
        blocks.append(
            f"<div style='margin-bottom:20px'>"
            f"<div style='font-size:16px;font-weight:700'>{release.headline}</div>"
            f"<div style='color:{muted};font-size:11px;letter-spacing:1px;"
            f"margin:2px 0 10px 0'>VERSION {release.version} &nbsp;·&nbsp; "
            f"{release.date}</div>"
        )
        for title, items in release.sections():
            blocks.append(
                f"<div style='color:{accent};font-size:11px;font-weight:700;"
                f"letter-spacing:1px;margin:12px 0 4px 0'>{title.upper()}</div><ul "
                f"style='margin:0 0 0 16px;padding:0'>"
            )
            blocks.extend(f"<li style='margin-bottom:5px'>{i}</li>" for i in items)
            blocks.append("</ul>")
        blocks.append("</div>")
    return "".join(blocks)
