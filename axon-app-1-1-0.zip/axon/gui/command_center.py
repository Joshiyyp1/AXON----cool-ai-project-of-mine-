"""The Command Center: admin-only control over models, versions and updates."""
from __future__ import annotations

import shutil
import time
from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from axon import __version__
from axon.access import AccessControl
from axon.config import ModelConfig, Paths, model_name
from axon.trainer import inspect_checkpoint
from axon.updater import (
    AppRelease,
    Release,
    check_for_app_bundle,
    check_for_app_update,
    check_for_update,
    install_app_bundle,
    is_frozen,
    download_release,
    install_app_update,
    publish,
    should_check,
)


# --------------------------------------------------------------------------- #
# workers
# --------------------------------------------------------------------------- #
class UpdateCheckWorker(QThread):
    """Looks for both a newer model and a newer version of the program."""

    found = Signal(object, object)   # model Release or None, AppRelease or None
    failed = Signal(str)

    def __init__(self, channel: str, current_version: str, app_version: str) -> None:
        super().__init__()
        self.channel = channel
        self.current_version = current_version
        self.app_version = app_version

    def run(self) -> None:
        try:
            model = check_for_update(self.channel, self.current_version)
            try:
                # A built .exe updates by replacing the whole application;
                # a source install swaps its .py files.
                app = (
                    check_for_app_bundle(self.channel, self.app_version)
                    if is_frozen() else
                    check_for_app_update(self.channel, self.app_version)
                )
            except Exception:
                app = None          # a channel with models but no app release
            self.found.emit(model, app)
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class AppUpdateWorker(QThread):
    """Downloads and unpacks a new version of the program itself."""

    progress = Signal(int, int)
    done = Signal(int)
    failed = Signal(str)

    def __init__(self, channel: str, release: AppRelease, install_dir: Path) -> None:
        super().__init__()
        self.channel = channel
        self.release = release
        self.install_dir = install_dir
        self.staged_script = ""

    def run(self) -> None:
        try:
            if is_frozen():
                script = install_app_bundle(
                    self.channel, self.release, self.install_dir,
                    progress=lambda d, t: self.progress.emit(d, t),
                )
                self.staged_script = str(script)
                self.done.emit(-1)          # -1 = staged, needs a restart
            else:
                changed = install_app_update(
                    self.channel, self.release, self.install_dir,
                    progress=lambda d, t: self.progress.emit(d, t),
                )
                self.done.emit(len(changed))
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class UpdateInstallWorker(QThread):
    progress = Signal(int, int)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, channel: str, release: Release, destination: Path) -> None:
        super().__init__()
        self.channel = channel
        self.release = release
        self.destination = destination

    def run(self) -> None:
        try:
            path = download_release(
                self.channel, self.release, self.destination,
                progress=lambda d, t: self.progress.emit(d, t),
            )
            self.done.emit(str(path))
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


# --------------------------------------------------------------------------- #
class CommandCenter(QWidget):
    """Access control, model versions, publishing and updates in one panel."""

    accessChanged = Signal()
    modelChanged = Signal()

    def __init__(self, engine, access: AccessControl, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setObjectName("RightPanel")
        self.engine = engine
        self.access = access
        self.check_worker: Optional[UpdateCheckWorker] = None
        self.install_worker: Optional[UpdateInstallWorker] = None
        self.app_worker: Optional[AppUpdateWorker] = None
        self.pending: Optional[Release] = None
        self.pending_app: Optional[AppRelease] = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(12)

        layout.addWidget(self._build_access_box())
        layout.addWidget(self._build_versions_box(), 1)
        layout.addWidget(self._build_updates_box())

        self.refresh()

    # ------------------------------------------------------------------ #
    def _build_access_box(self) -> QGroupBox:
        box = QGroupBox("WHO CAN EDIT THIS")
        layout = QVBoxLayout(box)

        self.role_label = QLabel("-")
        self.role_label.setWordWrap(True)
        layout.addWidget(self.role_label)

        row = QHBoxLayout()
        self.password_btn = QPushButton("Set password")
        self.password_btn.clicked.connect(self.set_password)
        self.lock_btn = QPushButton("Lock")
        self.lock_btn.clicked.connect(self.lock)
        row.addWidget(self.password_btn)
        row.addWidget(self.lock_btn)
        layout.addLayout(row)

        note = QLabel(
            "Locking hides training and model controls so other people can only chat. "
            "It is a lock on the buttons, not real security - anyone who can edit the "
            "Python files or swap the .pt file still can."
        )
        note.setObjectName("Muted")
        note.setWordWrap(True)
        layout.addWidget(note)
        return box

    # ------------------------------------------------------------------ #
    def _build_versions_box(self) -> QGroupBox:
        box = QGroupBox("MODEL VERSIONS")
        layout = QVBoxLayout(box)

        self.versions_table = QTableWidget(0, 5)
        self.versions_table.setHorizontalHeaderLabels(
            ["File", "Model", "Steps", "Val loss", "Saved"]
        )
        self.versions_table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.Stretch
        )
        self.versions_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.versions_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.versions_table.setMinimumHeight(150)
        layout.addWidget(self.versions_table)

        row = QHBoxLayout()
        for text, slot in (
            ("Use this one", self.activate_selected),
            ("Duplicate", self.duplicate_selected),
            ("Publish...", self.publish_selected),
            ("Refresh", self.refresh_versions),
        ):
            btn = QPushButton(text)
            btn.clicked.connect(slot)
            row.addWidget(btn)
        layout.addLayout(row)

        delete_btn = QPushButton("Delete version")
        delete_btn.setObjectName("Danger")
        delete_btn.clicked.connect(self.delete_selected)
        layout.addWidget(delete_btn)
        return box

    # ------------------------------------------------------------------ #
    def _build_updates_box(self) -> QGroupBox:
        box = QGroupBox("UPDATES")
        layout = QFormLayout(box)
        layout.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        layout.setFieldGrowthPolicy(
            QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow
        )

        self.channel_edit = QLineEdit()
        self.channel_edit.setPlaceholderText(
            "folder or https://... with manifest.json"
        )
        self.channel_edit.editingFinished.connect(self._save_channel)
        layout.addRow("Channel", self.channel_edit)

        browse_row = QHBoxLayout()
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self.browse_channel)
        self.check_btn = QPushButton("Check now")
        self.check_btn.clicked.connect(self.check_updates)
        browse_row.addWidget(browse_btn)
        browse_row.addWidget(self.check_btn)
        layout.addRow(browse_row)

        self.auto_check = QCheckBox("Check weekly on startup")
        self.auto_check.setChecked(True)
        self.auto_check.toggled.connect(self._save_channel)
        layout.addRow(self.auto_check)

        self.update_status = QLabel("not checked yet")
        self.update_status.setObjectName("Muted")
        self.update_status.setWordWrap(True)
        layout.addRow(self.update_status)

        self.update_progress = QProgressBar()
        self.update_progress.setVisible(False)
        layout.addRow(self.update_progress)

        self.install_btn = QPushButton("Install update")
        self.install_btn.setObjectName("Primary")
        self.install_btn.setEnabled(False)
        self.install_btn.clicked.connect(self.install_update)
        layout.addRow(self.install_btn)
        return box

    # ================================================================== #
    # access
    # ================================================================== #
    def refresh(self) -> None:
        self.role_label.setText(f"This copy is: <b>{self.access.describe()}</b>")
        self.password_btn.setText(
            "Change admin password" if self.access.is_protected else "Set admin password"
        )
        self.lock_btn.setEnabled(self.access.is_protected and self.access.is_admin)
        self.channel_edit.setText(str(self.engine.memory.get_meta("update.channel", "")))
        auto = self.engine.memory.get_meta("update.auto", True)
        self.auto_check.setChecked(bool(auto))
        self.refresh_versions()

    def set_password(self) -> None:
        if self.access.is_protected and not self.access.is_admin:
            QMessageBox.information(self, "Locked", "Unlock as admin first.")
            return
        new, ok = QInputDialog.getText(
            self, "Admin password", "New admin password (at least 4 characters):",
            QLineEdit.EchoMode.Password,
        )
        if not ok or not new:
            return
        again, ok = QInputDialog.getText(
            self, "Admin password", "Type it once more:", QLineEdit.EchoMode.Password
        )
        if not ok:
            return
        if new != again:
            QMessageBox.warning(self, "Not the same", "The two passwords do not match.")
            return
        try:
            self.access.set_password(new)
        except (ValueError, PermissionError) as exc:
            QMessageBox.warning(self, "Could not set password", str(exc))
            return
        QMessageBox.information(
            self, "Password set",
            "Done. AXON now starts in friend mode, and only someone with this "
            "password can train or change the models.\n\n"
            "If you forget it, delete data/axon_memory.db to reset - that also "
            "erases your chats and memory.",
        )
        self.refresh()
        self.accessChanged.emit()

    def lock(self) -> None:
        self.access.lock()
        self.refresh()
        self.accessChanged.emit()

    # ================================================================== #
    # versions
    # ================================================================== #
    def _checkpoints(self) -> List[Path]:
        return sorted(Paths.CHECKPOINTS.glob("*.pt"))

    def refresh_versions(self) -> None:
        files = self._checkpoints()
        self.versions_table.setRowCount(len(files))
        active = Path(self.engine.checkpoint_path).resolve()
        for row, path in enumerate(files):
            try:
                meta = inspect_checkpoint(path)
                name = model_name(ModelConfig.from_dict(meta["model_config"]))
                steps = f"{meta.get('step', 0):,}"
                val = meta.get("val_loss")
                val_text = f"{val:.4f}" if isinstance(val, float) else "-"
                saved = time.strftime("%d %b %H:%M", time.localtime(meta.get("saved_at", 0)))
            except Exception:
                name, steps, val_text, saved = "unreadable", "-", "-", "-"

            label = path.name + ("   (in use)" if path.resolve() == active else "")
            for col, text in enumerate([label, name, steps, val_text, saved]):
                self.versions_table.setItem(row, col, QTableWidgetItem(text))

    def _selected_path(self) -> Optional[Path]:
        rows = self.versions_table.selectionModel().selectedRows()
        if not rows:
            QMessageBox.information(self, "Pick one", "Select a version in the list first.")
            return None
        item = self.versions_table.item(rows[0].row(), 0)
        return Paths.CHECKPOINTS / item.text().replace("   (in use)", "")

    def activate_selected(self) -> None:
        path = self._selected_path()
        if path is None:
            return
        try:
            self.engine.load(path)
        except Exception as exc:
            QMessageBox.critical(self, "Could not load", str(exc))
            return
        self.refresh_versions()
        self.modelChanged.emit()

    def duplicate_selected(self) -> None:
        path = self._selected_path()
        if path is None:
            return
        name, ok = QInputDialog.getText(
            self, "Duplicate", "Name for the copy:", text=f"{path.stem}_copy.pt"
        )
        if not ok or not name.strip():
            return
        if not name.endswith(".pt"):
            name += ".pt"
        shutil.copyfile(path, Paths.CHECKPOINTS / name)
        self.refresh_versions()

    def delete_selected(self) -> None:
        path = self._selected_path()
        if path is None:
            return
        if path.resolve() == Path(self.engine.checkpoint_path).resolve():
            QMessageBox.information(
                self, "In use", "That is the model currently loaded. Switch to another first."
            )
            return
        answer = QMessageBox.question(
            self, "Delete version", f"Delete {path.name} permanently?"
        )
        if answer == QMessageBox.StandardButton.Yes:
            path.unlink(missing_ok=True)
            self.refresh_versions()

    def publish_selected(self) -> None:
        path = self._selected_path()
        if path is None:
            return
        version, ok = QInputDialog.getText(
            self, "Publish version", "Version number for this release:", text="1.1.0"
        )
        if not ok or not version.strip():
            return
        notes, _ = QInputDialog.getText(self, "Publish version", "What changed? (optional)")

        out_dir = QFileDialog.getExistingDirectory(
            self, "Release folder", str(Paths.ROOT / "releases")
        )
        if not out_dir:
            return
        try:
            meta = inspect_checkpoint(path)
            release = publish(
                checkpoint=path, out_dir=out_dir, version=version.strip(),
                model_name=model_name(ModelConfig.from_dict(meta["model_config"])),
                notes=notes or "", trained_steps=meta.get("step", 0),
                val_loss=meta.get("val_loss"),
            )
        except Exception as exc:
            QMessageBox.critical(self, "Publish failed", str(exc))
            return
        QMessageBox.information(
            self, "Published",
            f"Published v{release.version} ({release.size / 1e6:.1f} MB) into:\n{out_dir}\n\n"
            "Share that folder with your friends and set it as their update channel.",
        )

    # ================================================================== #
    # updates
    # ================================================================== #
    def _save_channel(self) -> None:
        self.engine.memory.set_meta("update.channel", self.channel_edit.text().strip())
        self.engine.memory.set_meta("update.auto", self.auto_check.isChecked())

    def browse_channel(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Update folder", str(Paths.ROOT))
        if folder:
            self.channel_edit.setText(folder)
            self._save_channel()

    def check_updates(self, silent: bool = False) -> None:
        channel = self.channel_edit.text().strip()
        if not channel:
            if not silent:
                QMessageBox.information(
                    self, "No channel",
                    "Set an update channel first - the folder or web address where "
                    "the manifest.json lives.",
                )
            return
        if self.check_worker is not None and self.check_worker.isRunning():
            return

        self._save_channel()
        self.check_btn.setEnabled(False)
        self.update_status.setText("checking...")
        current = str(self.engine.memory.get_meta("update.installed_version", __version__))

        app_version = str(self.engine.memory.get_meta("app.version", __version__))
        self.check_worker = UpdateCheckWorker(channel, current, app_version)
        self.check_worker.found.connect(self._on_update_found)
        self.check_worker.failed.connect(self._on_update_failed)
        self.check_worker.start()
        self.engine.memory.set_meta("update.last_check", time.time())

    def maybe_auto_check(self) -> None:
        """Weekly check on startup, if a channel is configured."""
        if not self.auto_check.isChecked() or not self.channel_edit.text().strip():
            return
        if should_check(self.engine.memory.get_meta("update.last_check"), every_days=7):
            self.check_updates(silent=True)

    def _on_update_found(self, release: Optional[Release],
                         app: Optional[AppRelease]) -> None:
        self.check_btn.setEnabled(True)
        self.pending, self.pending_app = release, app

        if release is None and app is None:
            self.install_btn.setEnabled(False)
            self.update_status.setText("you are up to date")
            return

        lines = []
        if release is not None:
            notes = f" - {release.notes}" if release.notes else ""
            lines.append(
                f"<b>Model v{release.version}</b> ({release.size / 1e6:.1f} MB)"
                f"{notes}<br>{release.model_name}, {release.trained_steps:,} trained steps"
            )
        if app is not None:
            notes = f" - {app.notes}" if app.notes else ""
            lines.append(f"<b>App v{app.version}</b> ({app.size / 1e6:.2f} MB){notes}")

        self.install_btn.setText(
            "Install update" if len(lines) == 1 else "Install both updates"
        )
        self.install_btn.setEnabled(self.access.can("install_update"))
        self.update_status.setText("<br><br>".join(lines))

    def _on_update_failed(self, message: str) -> None:
        self.check_btn.setEnabled(True)
        self.update_status.setText(f"could not check: {message}")

    def install_update(self) -> None:
        if self.pending is None and self.pending_app is None:
            return
        if not self.access.can("install_update"):
            QMessageBox.information(self, "Locked", "Unlock as admin to install updates.")
            return

        if self.pending is None:
            self._install_app()
            return

        destination = Paths.CHECKPOINTS / f"vesper-{self.pending.version}.pt"
        self.install_btn.setEnabled(False)
        self.update_progress.setVisible(True)
        self.update_progress.setRange(0, 100)
        self.update_status.setText("downloading...")

        self.install_worker = UpdateInstallWorker(
            self.channel_edit.text().strip(), self.pending, destination
        )
        self.install_worker.progress.connect(self._on_download_progress)
        self.install_worker.done.connect(self._on_installed)
        self.install_worker.failed.connect(self._on_install_failed)
        self.install_worker.start()

    def _on_download_progress(self, done: int, total: int) -> None:
        if total > 0:
            self.update_progress.setValue(int(100 * done / total))

    def _install_app(self) -> None:
        """Update the program itself - no reinstall, no new download of the model."""
        if self.pending_app is None:
            return
        self.install_btn.setEnabled(False)
        self.update_progress.setVisible(True)
        self.update_progress.setRange(0, 100)
        self.update_status.setText("downloading the app update...")

        self.app_worker = AppUpdateWorker(
            self.channel_edit.text().strip(), self.pending_app, Paths.ROOT
        )
        self.app_worker.progress.connect(self._on_download_progress)
        self.app_worker.done.connect(self._on_app_installed)
        self.app_worker.failed.connect(self._on_install_failed)
        self.app_worker.start()

    def _on_app_installed(self, count: int) -> None:
        self.update_progress.setVisible(False)
        version = self.pending_app.version if self.pending_app else "?"

        if count == -1:            # frozen build: staged, needs a restart
            self.engine.memory.set_meta("app.version", version)
            script = getattr(self.app_worker, "staged_script", "")
            answer = QMessageBox.question(
                self, "Update ready",
                f"AXON {version} has been downloaded and checked. "
                "AXON will close, update itself and reopen. Your conversations "
                "and models are not affected. Update now?",
            )
            if answer == QMessageBox.StandardButton.Yes and script:
                import subprocess
                subprocess.Popen(["cmd", "/c", script],
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                QApplication.quit()
            return
        self.engine.memory.set_meta("app.version", version)
        self.engine.memory.set_meta("seen_version", None)     # show the new notes
        self.update_status.setText(f"app updated to v{version} - restart to apply")
        self.pending_app = None
        QMessageBox.information(
            self, "App updated",
            f"AXON has been updated to v{version} ({count} files). "
            "Close and reopen AXON to start using it. Your chats, memory and "
            "models were not touched.",
        )

    def _on_installed(self, path: str) -> None:
        self.update_progress.setVisible(False)
        version = self.pending.version if self.pending else "?"
        self.engine.memory.set_meta("update.installed_version", version)
        self.update_status.setText(f"installed v{version}")
        self.pending = None
        self.refresh_versions()

        answer = QMessageBox.question(
            self, "Update installed",
            f"Downloaded and verified:\n{path}\n\nLoad it now?",
        )
        if answer == QMessageBox.StandardButton.Yes:
            self.engine.load(path)
            self.refresh_versions()
            self.modelChanged.emit()
        if self.pending_app is not None:
            self._install_app()

    def _on_install_failed(self, message: str) -> None:
        self.update_progress.setVisible(False)
        self.install_btn.setEnabled(True)
        self.update_status.setText("install failed")
        QMessageBox.critical(self, "Update failed", message)
