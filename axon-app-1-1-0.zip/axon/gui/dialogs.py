"""Product dialogs: What's New, and the model switcher."""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import QPoint, Qt, Signal
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from axon import __version__
from axon.config import MODEL_PRESETS, ModelConfig, Paths, model_name
from axon.patchnotes import RELEASES, as_html, latest, since
from axon.gui.style import ACCENT, MUTED
from axon.trainer import inspect_checkpoint


class WhatsNewDialog(QDialog):
    """Release notes. Opens by itself the first time a new version runs."""

    def __init__(self, releases: Optional[List] = None, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("What's new in AXON")
        self.setMinimumSize(560, 520)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 20)
        layout.setSpacing(14)

        title = QLabel("What's new")
        title.setObjectName("DialogTitle")
        layout.addWidget(title)

        body = QTextBrowser()
        body.setOpenExternalLinks(False)
        body.setObjectName("NotesBody")
        body.setHtml(as_html(releases if releases is not None else RELEASES,
                             accent=ACCENT, muted=MUTED))
        layout.addWidget(body, 1)

        row = QHBoxLayout()
        row.addStretch(1)
        close = QPushButton("Got it")
        close.setObjectName("Primary")
        close.clicked.connect(self.accept)
        row.addWidget(close)
        layout.addLayout(row)


class ModelCard(QFrame):
    """One Vesper model in the switcher."""

    chosen = Signal(str)          # preset key

    def __init__(self, key: str, preset, installed: Optional[Path],
                 is_active: bool, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.key = key
        self.preset = preset
        self.installed = installed
        available = preset.available and installed is not None

        self.setObjectName("ModelCardActive" if is_active else
                           ("ModelCard" if available else "ModelCardSoon"))
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 13, 16, 13)
        layout.setSpacing(3)

        head = QHBoxLayout()
        head.setSpacing(8)
        name = QLabel(preset.name)
        name.setObjectName("CardTitle" if available else "CardTitleSoon")
        head.addWidget(name)
        head.addStretch(1)

        badge = QLabel("IN USE" if is_active else
                       ("COMING SOON" if not preset.available else
                        ("READY" if available else "NOT INSTALLED")))
        badge.setObjectName("BadgeActive" if is_active else
                            ("Badge" if available else "BadgeSoon"))
        head.addWidget(badge)
        layout.addLayout(head)

        blurb = QLabel(preset.blurb)
        blurb.setObjectName("CardBlurb" if available else "CardBlurbSoon")
        blurb.setWordWrap(True)
        layout.addWidget(blurb)

        detail = f"{preset.n_layer} layers  ·  {preset.n_embd} wide  ·  {preset.block_size} token memory"
        if not preset.available and preset.eta:
            detail = f"{detail}   —   {preset.eta}"
        meta = QLabel(detail)
        meta.setObjectName("CardMeta")
        meta.setWordWrap(True)
        layout.addWidget(meta)

        if available and not is_active:
            row = QHBoxLayout()
            row.addStretch(1)
            use = QPushButton("Use this model")
            use.setObjectName("CardButton")
            use.setCursor(Qt.CursorShape.PointingHandCursor)
            use.clicked.connect(lambda: self.chosen.emit(self.key))
            row.addWidget(use)
            layout.addLayout(row)


class ModelSwitcher(QWidget):
    """Pick which Vesper model to talk to. Unreleased sizes show Coming soon."""

    modelChosen = Signal(str)     # path to the checkpoint

    def __init__(self, engine, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.engine = engine
        self.setObjectName("RightPanel")

        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(10)
        self.refresh()

    # ------------------------------------------------------------------ #
    def _installed_for(self, key: str) -> Optional[Path]:
        """Find a checkpoint on disk whose shape matches this preset."""
        preset = MODEL_PRESETS[key]
        for path in sorted(Paths.CHECKPOINTS.glob("*.pt")):
            try:
                cfg = ModelConfig.from_dict(inspect_checkpoint(path)["model_config"])
            except Exception:
                continue
            if (cfg.n_layer, cfg.n_head, cfg.n_embd) == (
                preset.n_layer, preset.n_head, preset.n_embd
            ):
                return path
        return None

    def refresh(self) -> None:
        while self._layout.count():
            item = self._layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        active_name = ""
        if self.engine.ready:
            active_name = model_name(self.engine.model.cfg)

        for key, preset in MODEL_PRESETS.items():
            installed = self._installed_for(key) if preset.available else None
            card = ModelCard(key, preset, installed, preset.name == active_name)
            card.chosen.connect(self._on_chosen)
            self._layout.addWidget(card)

        note = QLabel(
            "More Vesper models are on the way. Updates arrive through the app - "
            "you will not have to reinstall anything."
        )
        note.setObjectName("Muted")
        note.setWordWrap(True)
        self._layout.addWidget(note)

    def _on_chosen(self, key: str) -> None:
        path = self._installed_for(key)
        if path is not None:
            self.modelChosen.emit(str(path))


class ModelPicker(QPushButton):
    """Compact model chooser that sits under the message box.

    Shows the model in use; clicking opens the list. Sizes that are not out
    yet appear greyed with 'Coming soon' rather than being hidden, so people
    can see what is on the way.
    """

    modelChosen = Signal(str)     # checkpoint path

    def __init__(self, engine, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.engine = engine
        self.setObjectName("ModelPicker")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFlat(True)
        self.clicked.connect(self._open_menu)
        self.refresh()

    # ------------------------------------------------------------------ #
    def _installed_for(self, key: str) -> Optional[Path]:
        preset = MODEL_PRESETS[key]
        for path in sorted(Paths.CHECKPOINTS.glob("*.pt")):
            try:
                cfg = ModelConfig.from_dict(inspect_checkpoint(path)["model_config"])
            except Exception:
                continue
            if (cfg.n_layer, cfg.n_head, cfg.n_embd) == (
                preset.n_layer, preset.n_head, preset.n_embd
            ):
                return path
        return None

    def refresh(self) -> None:
        if self.engine.ready:
            self.setText(f"{model_name(self.engine.model.cfg)}   \u25be")
        else:
            self.setText("No model loaded   \u25be")

    def _open_menu(self) -> None:
        from PySide6.QtWidgets import QMenu

        menu = QMenu(self)
        active = model_name(self.engine.model.cfg) if self.engine.ready else ""

        for key, preset in MODEL_PRESETS.items():
            installed = self._installed_for(key) if preset.available else None
            usable = preset.available and installed is not None

            label = preset.name
            if preset.name == active:
                label = f"{preset.name}      in use"
            elif not preset.available:
                label = f"{preset.name}      coming soon"
            elif installed is None:
                label = f"{preset.name}      not installed"

            action = menu.addAction(label)
            action.setEnabled(usable and preset.name != active)
            if usable and preset.name != active:
                action.triggered.connect(
                    lambda _=False, p=str(installed): self.modelChosen.emit(p)
                )

        menu.exec(self.mapToGlobal(self.rect().topLeft()) - QPoint(0, menu.sizeHint().height()))


class SignInDialog(QDialog):
    """Sign in, or make an account. Local only - nothing is sent anywhere."""

    def __init__(self, accounts, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.accounts = accounts
        self.account = None
        self.first_run = accounts.count() == 0

        self.setWindowTitle("AXON")
        self.setMinimumWidth(400)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(34, 30, 34, 26)
        layout.setSpacing(6)

        title = QLabel("Welcome to AXON" if self.first_run else "Welcome back")
        title.setObjectName("DialogTitle")
        layout.addWidget(title)

        self.subtitle = QLabel(
            "Create an account to keep your chats private on this computer."
            if self.first_run else
            "Sign in to your account."
        )
        self.subtitle.setObjectName("Muted")
        self.subtitle.setWordWrap(True)
        layout.addWidget(self.subtitle)
        layout.addSpacing(16)

        self.username = QLineEdit()
        self.username.setPlaceholderText("username")
        self.password = QLineEdit()
        self.password.setPlaceholderText("password")
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm = QLineEdit()
        self.confirm.setPlaceholderText("password again")
        self.confirm.setEchoMode(QLineEdit.EchoMode.Password)
        for box in (self.username, self.password, self.confirm):
            box.returnPressed.connect(self._submit)
            layout.addWidget(box)
        self.confirm.setVisible(self.first_run)

        self.error = QLabel("")
        self.error.setObjectName("ErrorText")
        self.error.setWordWrap(True)
        self.error.setVisible(False)
        layout.addWidget(self.error)
        layout.addSpacing(10)

        self.submit_btn = QPushButton("Create account" if self.first_run else "Sign in")
        self.submit_btn.setObjectName("Primary")
        self.submit_btn.clicked.connect(self._submit)
        layout.addWidget(self.submit_btn)

        self.switch_btn = QPushButton(
            "" if self.first_run else "Create a new account"
        )
        self.switch_btn.setObjectName("LinkButton")
        self.switch_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.switch_btn.setVisible(not self.first_run)
        self.switch_btn.clicked.connect(self._toggle_mode)
        layout.addWidget(self.switch_btn)

        note = QLabel("Your account lives on this computer. Nothing is sent anywhere.")
        note.setObjectName("CardMeta")
        note.setWordWrap(True)
        layout.addSpacing(8)
        layout.addWidget(note)

        self.signing_up = self.first_run
        self.username.setFocus()

    # ------------------------------------------------------------------ #
    def _toggle_mode(self) -> None:
        self.signing_up = not self.signing_up
        self.confirm.setVisible(self.signing_up)
        self.confirm.clear()
        self.error.setVisible(False)
        self.submit_btn.setText("Create account" if self.signing_up else "Sign in")
        self.switch_btn.setText(
            "I already have an account" if self.signing_up else "Create a new account"
        )
        self.subtitle.setText(
            "Create an account to keep your chats private on this computer."
            if self.signing_up else "Sign in to your account."
        )

    def _fail(self, message: str) -> None:
        self.error.setText(message)
        self.error.setVisible(True)

    def _submit(self) -> None:
        username = self.username.text().strip()
        password = self.password.text()
        if not username or not password:
            self._fail("Fill in both boxes.")
            return

        if self.signing_up:
            if password != self.confirm.text():
                self._fail("The two passwords are not the same.")
                return
            try:
                self.account = self.accounts.sign_up(
                    username, password, is_owner=self.first_run
                )
            except ValueError as exc:
                self._fail(str(exc))
                return
            self.accept()
            return

        account = self.accounts.sign_in(username, password)
        if account is None:
            self._fail("Wrong username or password.")
            return
        self.account = account
        self.accept()
