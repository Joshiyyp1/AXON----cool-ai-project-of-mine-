"""Reusable widgets: chat bubbles, the scrolling transcript and the composer."""
from __future__ import annotations

import html
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

# The reading column is capped so the chat stays centred and legible on a wide
# window instead of bubbles clinging to the far edges of the screen.
COLUMN_WIDTH = 820

# The reading column should soak up all spare width until it hits
# COLUMN_WIDTH; only the leftover is split between the two side spacers,
# which is what actually centres it.
COLUMN_STRETCH = 1000


class ChatBubble(QFrame):
    """One message. `append_text` is used for token-by-token streaming.

    Bot bubbles carry a thumbs up / down control. A thumbs up is the only thing
    that lets an exchange be replayed into the weights, so approving a reply is
    deliberately one click away.
    """

    rated = Signal(int, int)      # sample_id, rating

    def __init__(self, role: str, text: str = "", parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.role = role
        self._text = text
        self.sample_id: Optional[int] = None
        self.setObjectName(
            {"user": "UserBubble", "bot": "BotBubble"}.get(role, "SystemBubble")
        )
        self.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Preferred)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(4)

        self.role_label = QLabel({"user": "YOU", "bot": "AXON"}.get(role, "SYSTEM"))
        self.role_label.setObjectName("BubbleRole")
        layout.addWidget(self.role_label)

        self.body = QLabel()
        self.body.setObjectName("BubbleText")
        self.body.setWordWrap(True)
        self.body.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.body.setTextFormat(Qt.TextFormat.RichText)
        layout.addWidget(self.body)

        self.rating_row: Optional[QWidget] = None
        if role == "bot":
            self.rating_row = QWidget()
            self.rating_row.setObjectName("RatingRow")
            rl = QHBoxLayout(self.rating_row)
            rl.setContentsMargins(0, 4, 0, 0)
            rl.setSpacing(6)

            self.good_btn = QPushButton("Good")
            self.bad_btn = QPushButton("Bad")
            for btn, value, tip in (
                (self.good_btn, 1, "Approve this reply - it can then be learned from"),
                (self.bad_btn, -1, "Reject this reply - it is excluded from training"),
            ):
                btn.setObjectName("RateButton")
                btn.setToolTip(tip)
                btn.setCursor(Qt.CursorShape.PointingHandCursor)
                btn.clicked.connect(lambda _=False, v=value: self._emit_rating(v))
                rl.addWidget(btn)

            self.rating_note = QLabel("")
            self.rating_note.setObjectName("BubbleRole")
            rl.addWidget(self.rating_note)
            rl.addStretch(1)
            self.rating_row.setVisible(False)
            layout.addWidget(self.rating_row)

        self.set_text(text)

    # ------------------------------------------------------------------ #
    def enable_rating(self, sample_id: Optional[int]) -> None:
        """Show the rating buttons once the exchange has been stored."""
        if self.rating_row is None or sample_id is None or sample_id < 0:
            return
        self.sample_id = sample_id
        self.rating_row.setVisible(True)

    def _emit_rating(self, value: int) -> None:
        if self.sample_id is None:
            return
        self.good_btn.setEnabled(False)
        self.bad_btn.setEnabled(False)
        self.rating_note.setText("MARKED GOOD" if value > 0 else "MARKED BAD")
        self.rated.emit(self.sample_id, value)

    # ------------------------------------------------------------------ #
    def set_text(self, text: str) -> None:
        self._text = text
        rendered = html.escape(text).replace("\n", "<br>")
        self.body.setText(rendered or "<i style='color:#7d869c'>...</i>")

    def append_text(self, chunk: str) -> None:
        self.set_text(self._text + chunk)

    def text(self) -> str:
        return self._text


class ChatTranscript(QScrollArea):
    """Vertical, auto-scrolling list of chat bubbles."""

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self._container = QWidget()
        self._container.setObjectName("ChatArea")

        # centred fixed-width reading column, with the scroll area's own
        # background either side of it
        outer = QHBoxLayout(self._container)
        outer.setContentsMargins(16, 18, 16, 18)
        outer.setSpacing(0)
        outer.addStretch(1)

        self._column = QWidget()
        self._column.setObjectName("ChatArea")
        self._column.setMaximumWidth(COLUMN_WIDTH)
        self._layout = QVBoxLayout(self._column)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(12)
        self._layout.addStretch(1)

        outer.addWidget(self._column, COLUMN_STRETCH)
        outer.addStretch(1)
        self.setWidget(self._container)

        self._last_bubble: Optional[ChatBubble] = None

    def _bubble_width(self) -> int:
        usable = min(COLUMN_WIDTH, max(320, self.viewport().width() - 32))
        return max(300, int(usable * 0.82))

    # ------------------------------------------------------------------ #
    def add_message(self, role: str, text: str = "") -> ChatBubble:
        bubble = ChatBubble(role, text)
        bubble.setMaximumWidth(self._bubble_width())

        row = QWidget()
        row.setObjectName("ChatArea")
        hl = QHBoxLayout(row)
        hl.setContentsMargins(0, 0, 0, 0)
        if role == "user":
            hl.addStretch(1)
            hl.addWidget(bubble)
        elif role == "bot":
            hl.addWidget(bubble)
            hl.addStretch(1)
        else:
            hl.addStretch(1)
            hl.addWidget(bubble)
            hl.addStretch(1)

        self._layout.insertWidget(self._layout.count() - 1, row)
        self._last_bubble = bubble
        self.scroll_to_bottom()
        return bubble

    def show_welcome(self, model: str, subtitle: str = "") -> None:
        """The first thing someone sees in an empty chat."""
        self.clear()
        panel = QWidget()
        panel.setObjectName("ChatArea")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(4, 60, 4, 20)
        layout.setSpacing(10)

        title = QLabel("What would you like to talk about?")
        title.setObjectName("WelcomeTitle")
        title.setWordWrap(True)
        layout.addWidget(title)

        body = QLabel(
            subtitle or
            "Everything runs on this computer. Nothing you type is sent anywhere."
        )
        body.setObjectName("WelcomeBody")
        body.setWordWrap(True)
        layout.addWidget(body)

        hint = QLabel(f"Talking to {model}" if model else "No model loaded")
        hint.setObjectName("WelcomeHint")
        layout.addWidget(hint)

        self._layout.insertWidget(self._layout.count() - 1, panel)
        self._welcome = panel

    def clear(self) -> None:
        while self._layout.count() > 1:
            item = self._layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        self._last_bubble = None

    def scroll_to_bottom(self) -> None:
        bar = self.verticalScrollBar()
        bar.setValue(bar.maximum())

    def resizeEvent(self, event) -> None:  # noqa: N802 (Qt naming)
        super().resizeEvent(event)
        width = self._bubble_width()
        for bubble in self._container.findChildren(ChatBubble):
            bubble.setMaximumWidth(width)


class Composer(QTextEdit):
    """Input box. Enter sends, Shift+Enter inserts a newline."""

    submitted = Signal(str)

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setObjectName("Composer")
        self.setPlaceholderText("Message AXON...   (Enter to send, Shift+Enter for a new line)")
        self.setAcceptRichText(False)
        self.setFixedHeight(84)

    def keyPressEvent(self, event: QKeyEvent) -> None:  # noqa: N802
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                super().keyPressEvent(event)
                return
            text = self.toPlainText().strip()
            if text:
                self.submitted.emit(text)
            return
        super().keyPressEvent(event)


class StatTile(QFrame):
    """Small labelled value shown in the Model tab."""

    def __init__(self, title: str, value: str = "-", parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setObjectName("BotBubble")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(2)

        self.title_label = QLabel(title.upper())
        self.title_label.setObjectName("BubbleRole")
        self.value_label = QLabel(value)
        self.value_label.setObjectName("StatBig")
        self.value_label.setWordWrap(True)

        layout.addWidget(self.title_label)
        layout.addWidget(self.value_label)

    def set_value(self, value: str) -> None:
        self.value_label.setText(value)
