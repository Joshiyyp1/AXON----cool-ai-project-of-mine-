"""AXON desktop application (PySide6)."""
from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction, QGuiApplication, QIcon, QPixmap, QPainter, QColor, QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QApplication,
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from axon import __version__
from axon import patchnotes
from axon.config import (
    MAX_ONLINE_LR,
    MODEL_FAMILY,
    MODEL_PRESETS,
    GenerationConfig,
    ModelConfig,
    OnlineConfig,
    Paths,
    TrainConfig,
    model_name,
)
from axon.access import AccessControl, read_seal
from axon.accounts import Accounts
from axon.engine import AxonEngine
from axon.gui.command_center import CommandCenter
from axon.gui.dialogs import (
    ModelPicker,
    ModelSwitcher,
    SignInDialog,
    WhatsNewDialog,
)
from axon.gui.style import ACCENT, BG, STYLESHEET
from axon.gui.widgets import (
    COLUMN_STRETCH,
    COLUMN_WIDTH,
    ChatBubble,
    ChatTranscript,
    Composer,
    StatTile,
)
from axon.gui.workers import (
    BuildWorker,
    GenerateWorker,
    ImportWorker,
    OnlineWorker,
    TrainWorker,
)

DATA_FILTER = "Datasets (*.txt *.json *.jsonl *.md);;All files (*)"
CKPT_FILTER = "AXON checkpoint (*.pt);;All files (*)"


def _app_icon() -> QIcon:
    """A tiny generated logo so the app has an icon without shipping a file."""
    pix = QPixmap(64, 64)
    pix.fill(QColor(BG))
    painter = QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(QColor(ACCENT))
    font = QFont("Segoe UI", 30, QFont.Weight.Bold)
    painter.setFont(font)
    painter.drawText(pix.rect(), Qt.AlignmentFlag.AlignCenter, "A")
    painter.end()
    return QIcon(pix)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"AXON  -  {MODEL_FAMILY} models  -  v{__version__}")
        self.resize(1420, 900)
        self.setWindowIcon(_app_icon())

        Paths.ensure()
        self.engine = AxonEngine(log=self._engine_log)
        self.access = AccessControl(
            self.engine.memory, seal=read_seal(self.engine.checkpoint_path)
        )
        self.accounts = Accounts(self.engine.memory)
        self.account = None

        self.gen_worker: Optional[GenerateWorker] = None
        self.train_worker: Optional[TrainWorker] = None
        self.build_worker: Optional[BuildWorker] = None
        self.online_worker: Optional[OnlineWorker] = None
        self.import_worker: Optional[ImportWorker] = None
        self.current_bubble: Optional[ChatBubble] = None
        self.dataset_paths: List[str] = []

        self._build_ui()
        self._restore_settings()
        QTimer.singleShot(0, self._sign_in)
        QTimer.singleShot(80, self._startup)

    # ================================================================== #
    # UI construction
    # ================================================================== #
    def _build_ui(self) -> None:
        self._build_menu()

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(self._build_sidebar())
        splitter.addWidget(self._build_chat_area())
        splitter.addWidget(self._build_right_panel())
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setStretchFactor(2, 0)
        splitter.setSizes([240, 700, 480])
        self.setCentralWidget(splitter)

        self.status_device = QLabel("device: -")
        self.status_model = QLabel("model: -")
        self.status_msg = QLabel("ready")
        self.status_role = QLabel("-")
        self.status_account = QLabel("")
        bar = self.statusBar()
        bar.addWidget(self.status_msg, 1)
        bar.addPermanentWidget(self.status_account)
        bar.addPermanentWidget(self.status_role)
        bar.addPermanentWidget(self.status_model)
        bar.addPermanentWidget(self.status_device)

    def _build_menu(self) -> None:
        menu = self.menuBar()

        file_menu = menu.addMenu("&File")
        self._add_action(file_menu, "New chat", self.new_chat, "Ctrl+N")
        self._add_action(file_menu, "Sign out...", self.sign_out)
        file_menu.addSeparator()
        self._add_action(file_menu, "Load checkpoint...", self.load_checkpoint_dialog, "Ctrl+O")
        self._add_action(file_menu, "Save checkpoint", self.save_checkpoint, "Ctrl+S")
        self._add_action(file_menu, "Save checkpoint as...", self.save_checkpoint_as)
        file_menu.addSeparator()
        self._add_action(file_menu, "Import dataset into memory...", self.import_dataset_dialog)
        self._add_action(file_menu, "Export conversations (JSON)...", self.export_conversations)
        file_menu.addSeparator()
        self._add_action(file_menu, "Quit", self.close, "Ctrl+Q")

        model_menu = menu.addMenu("&Model")
        self._add_action(model_menu, "Create new model...", self.create_model)
        self._add_action(model_menu, "Run online learning now", self.run_online_update)
        self._add_action(model_menu, "Reload from checkpoint", lambda: self.load_checkpoint(None))

        access_menu = menu.addMenu("&Access")
        self._add_action(access_menu, "Unlock admin...", self.unlock_admin, "Ctrl+U")
        self._add_action(access_menu, "Lock (friend mode)", self.lock_admin)
        self._add_action(access_menu, "Open Command Center", self.open_command_center)

        help_menu = menu.addMenu("&Help")
        self._add_action(help_menu, "Check for updates", self.check_updates_now)
        self._add_action(help_menu, "What's new", self.show_whats_new)
        self._add_action(help_menu, "About AXON", self.show_about)

    @staticmethod
    def _add_action(menu: QMenu, text: str, slot, shortcut: str = "") -> QAction:
        action = QAction(text, menu)
        if shortcut:
            action.setShortcut(shortcut)
        action.triggered.connect(slot)
        menu.addAction(action)
        return action

    # ------------------------------------------------------------------ #
    def _build_sidebar(self) -> QWidget:
        panel = QWidget()
        panel.setObjectName("Sidebar")
        panel.setMinimumWidth(210)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 12)
        layout.setSpacing(8)

        brand = QLabel("A X O N")
        brand.setObjectName("Brand")
        sub = QLabel(f"{MODEL_FAMILY} models  -  fully local")
        sub.setObjectName("BrandSub")
        sub.setWordWrap(True)
        layout.addWidget(brand)
        layout.addWidget(sub)

        row = QHBoxLayout()
        row.setContentsMargins(12, 0, 12, 0)
        new_btn = QPushButton("+  New chat")
        new_btn.setObjectName("Primary")
        new_btn.clicked.connect(self.new_chat)
        row.addWidget(new_btn)
        layout.addLayout(row)

        title = QLabel("HISTORY")
        title.setObjectName("SectionTitle")
        title.setContentsMargins(14, 8, 0, 0)
        layout.addWidget(title)

        self.conv_list = QListWidget()
        self.conv_list.itemClicked.connect(self._open_conversation_item)
        self.conv_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.conv_list.customContextMenuRequested.connect(self._conversation_context_menu)
        wrap = QVBoxLayout()
        wrap.setContentsMargins(10, 0, 10, 0)
        wrap.addWidget(self.conv_list)
        layout.addLayout(wrap, 1)

        return panel

    # ------------------------------------------------------------------ #
    def _build_chat_area(self) -> QWidget:
        panel = QWidget()
        panel.setObjectName("ChatArea")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.transcript = ChatTranscript()
        layout.addWidget(self.transcript, 1)

        bottom = QWidget()
        bottom.setObjectName("ChatArea")
        bottom_row = QHBoxLayout(bottom)
        bottom_row.setContentsMargins(16, 6, 16, 18)
        bottom_row.setSpacing(0)
        bottom_row.addStretch(1)

        composer_col = QWidget()
        composer_col.setObjectName("ChatArea")
        composer_col.setMaximumWidth(COLUMN_WIDTH)
        card = QFrame()
        card.setObjectName("InputCard")
        bl = QVBoxLayout(card)
        bl.setContentsMargins(6, 6, 6, 6)
        bl.setSpacing(2)

        col_layout = QVBoxLayout(composer_col)
        col_layout.setContentsMargins(0, 0, 0, 0)
        col_layout.addWidget(card)
        bottom_row.addWidget(composer_col, COLUMN_STRETCH)
        bottom_row.addStretch(1)

        self.composer = Composer()
        self.composer.submitted.connect(self.send_message)
        bl.addWidget(self.composer)

        # These two live in Settings, not in the message box - the input area
        # stays clear of things you never touch mid-sentence.
        self.memory_check = QCheckBox("Use what AXON remembers about me")
        self.memory_check.setChecked(True)
        self.memory_check.setToolTip("Insert relevant stored facts into the prompt")
        self.learn_check = QCheckBox("Save my chats as training data")
        self.learn_check.setChecked(True)
        self.learn_check.setToolTip("Store every exchange so it can be trained on later")

        controls = QHBoxLayout()
        controls.setContentsMargins(8, 0, 6, 4)
        controls.addStretch(1)

        self.model_picker = ModelPicker(self.engine)
        self.model_picker.modelChosen.connect(self._switch_model)
        controls.addWidget(self.model_picker)

        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop_generation)
        self.send_btn = QPushButton("Send  ⏎")
        self.send_btn.setObjectName("Primary")
        self.send_btn.clicked.connect(lambda: self.send_message(self.composer.toPlainText()))
        controls.addWidget(self.stop_btn)
        controls.addWidget(self.send_btn)
        bl.addLayout(controls)

        layout.addWidget(bottom)
        return panel

    # ------------------------------------------------------------------ #
    def _build_right_panel(self) -> QWidget:
        panel = QWidget()
        panel.setObjectName("RightPanel")
        panel.setMinimumWidth(300)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)

        self.tabs = QTabWidget()
        self.model_switcher = ModelSwitcher(self.engine)
        self.model_switcher.modelChosen.connect(self._switch_model)
        self._models_tab = self._scrollable(self._build_models_tab())
        self.tabs.addTab(self._models_tab, "Models")
        self.tabs.addTab(self._scrollable(self._build_model_tab()), "Settings")
        self._training_tab = self._scrollable(self._build_training_tab())
        self.tabs.addTab(self._training_tab, "Training")
        self.tabs.addTab(self._scrollable(self._build_memory_tab()), "Memory")
        self.command_center = CommandCenter(self.engine, self.access)
        self._command_tab = self._scrollable(self.command_center)
        self.command_center.accessChanged.connect(self._apply_access)
        self.command_center.modelChanged.connect(self.refresh_status)
        self.command_center.modelChanged.connect(
            lambda: (self.model_switcher.refresh(), self.model_picker.refresh()))
        self.tabs.addTab(self._command_tab, "Command")
        layout.addWidget(self.tabs)
        return panel

    @staticmethod
    def _tighten(form: QFormLayout) -> QFormLayout:
        """Let a form shrink: fields grow, long rows wrap to two lines."""
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        form.setFieldGrowthPolicy(
            QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow
        )
        form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        return form

    @staticmethod
    def _scrollable(widget: QWidget) -> QScrollArea:
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(QScrollArea.Shape.NoFrame)
        area.setWidget(widget)
        return area

    # ------------------------------------------------------------------ #
    def _build_model_tab(self) -> QWidget:
        page = QWidget()
        page.setObjectName("RightPanel")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(12)

        # --- status tiles ---
        grid = QGridLayout()
        grid.setSpacing(8)
        self.tile_name = StatTile("Model", "-")
        self.tile_device = StatTile("Device", "-")
        self.tile_params = StatTile("Parameters", "-")
        self.tile_vocab = StatTile("Vocabulary", "-")
        self.tile_ctx = StatTile("Context", "-")
        self.tile_steps = StatTile("Trained steps", "-")
        self.tile_loss = StatTile("Val loss", "-")
        for i, tile in enumerate(
            [self.tile_name, self.tile_device, self.tile_params,
             self.tile_vocab, self.tile_ctx, self.tile_steps, self.tile_loss]
        ):
            grid.addWidget(tile, i // 2, i % 2)
        layout.addLayout(grid)

        # --- checkpoint ---
        ckpt_box = QGroupBox("CHECKPOINT")
        self.checkpoint_box = ckpt_box
        cl = QVBoxLayout(ckpt_box)
        self.ckpt_edit = QLineEdit(str(Paths.DEFAULT_CHECKPOINT))
        self.ckpt_edit.setReadOnly(True)
        cl.addWidget(self.ckpt_edit)
        row = QHBoxLayout()
        for text, slot in (
            ("Load...", self.load_checkpoint_dialog),
            ("Save", self.save_checkpoint),
            ("Save as...", self.save_checkpoint_as),
        ):
            btn = QPushButton(text)
            btn.clicked.connect(slot)
            row.addWidget(btn)
        cl.addLayout(row)
        layout.addWidget(ckpt_box)

        # --- new model ---
        new_box = QGroupBox("CREATE A NEW MODEL")
        self.new_model_box = new_box
        nl = self._tighten(QFormLayout(new_box))
        nl.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)

        self.preset_combo = QComboBox()
        # Without this the combo demands room for its longest item, which
        # dragged the whole panel past the edge of the window.
        self.preset_combo.setSizeAdjustPolicy(
            QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
        )
        self.preset_combo.setMinimumContentsLength(14)
        for key, preset in MODEL_PRESETS.items():
            self.preset_combo.addItem(preset.label, key)
        self.preset_combo.setCurrentIndex(0)      # Spark: the laptop-friendly one
        self.preset_combo.currentIndexChanged.connect(self._apply_preset)
        nl.addRow("Preset", self.preset_combo)

        self.vocab_spin = self._spin(1024, 65536, 8192, step=512)
        self.layer_spin = self._spin(1, 48, 6)
        self.head_spin = self._spin(1, 32, 8)
        self.embd_spin = self._spin(32, 2048, 384, step=32)
        self.block_spin = self._spin(32, 4096, 256, step=32)
        self.dropout_spin = self._dspin(0.0, 0.9, 0.10, 0.05)
        nl.addRow("Vocab size", self.vocab_spin)
        nl.addRow("Layers", self.layer_spin)
        nl.addRow("Heads", self.head_spin)
        nl.addRow("Width (n_embd)", self.embd_spin)
        nl.addRow("Context", self.block_spin)
        nl.addRow("Dropout", self.dropout_spin)
        self._apply_preset()      # the spin boxes must match the shown preset

        self.build_progress = QProgressBar()
        self.build_progress.setVisible(False)
        nl.addRow(self.build_progress)

        self.create_btn = QPushButton("Create new model")
        self.create_btn.setToolTip("Builds a fresh tokenizer and random weights")
        self.create_btn.clicked.connect(self.create_model)
        nl.addRow(self.create_btn)
        layout.addWidget(new_box)

        # --- sampling ---
        device_note = QLabel(
            "These settings change how AXON behaves on this computer only. "
            "They never alter the model itself."
        )
        device_note.setObjectName("Muted")
        device_note.setWordWrap(True)
        layout.addWidget(device_note)

        chat_box = QGroupBox("CHAT")
        cbl = QVBoxLayout(chat_box)
        cbl.addWidget(self.memory_check)
        cbl.addWidget(self.learn_check)
        layout.addWidget(chat_box)

        gen_box = QGroupBox("GENERATION")
        gl = self._tighten(QFormLayout(gen_box))
        self.temp_spin = self._dspin(0.0, 2.0, 0.90, 0.05)
        self.topk_spin = self._spin(0, 2000, 50, step=5)
        self.topp_spin = self._dspin(0.0, 1.0, 0.92, 0.01)
        self.rep_spin = self._dspin(1.0, 2.5, 1.15, 0.05)
        self.maxtok_spin = self._spin(16, 2048, 200, step=16)
        self.seed_spin = self._spin(-1, 999_999, -1)
        gl.addRow("Temperature", self.temp_spin)
        gl.addRow("Top-k (0 = off)", self.topk_spin)
        gl.addRow("Top-p", self.topp_spin)
        gl.addRow("Repeat penalty", self.rep_spin)
        gl.addRow("Max tokens", self.maxtok_spin)
        gl.addRow("Seed", self.seed_spin)
        for w in (self.temp_spin, self.topk_spin, self.topp_spin,
                  self.rep_spin, self.maxtok_spin, self.seed_spin):
            w.valueChanged.connect(self._sync_generation)
        layout.addWidget(gen_box)

        # --- online learning ---
        on_box = QGroupBox("CONTINUOUS LEARNING")
        self.online_box = on_box
        ol = self._tighten(QFormLayout(on_box))
        self.online_check = QCheckBox("Learn from Good replies")
        self.online_check.setChecked(True)
        self.online_every_spin = self._spin(1, 100, 4)
        self.online_steps_spin = self._spin(1, 200, 6)
        self.online_lr_spin = self._dspin(0.000001, MAX_ONLINE_LR, 0.00005, 0.00001, decimals=6)
        self.online_lr_spin.setToolTip(
            "How big each nudge is. Keep this tiny. Large values destroy the model "
            "in a few updates, which is why it is capped."
        )
        ol.addRow(self.online_check)
        ol.addRow("Every N replies", self.online_every_spin)
        ol.addRow("Gradient steps", self.online_steps_spin)
        ol.addRow("Learning rate", self.online_lr_spin)
        self.online_btn = QPushButton("Update now")
        self.online_btn.clicked.connect(self.run_online_update)
        ol.addRow(self.online_btn)
        self.online_check.toggled.connect(self._sync_online)
        for w in (self.online_every_spin, self.online_steps_spin, self.online_lr_spin):
            w.valueChanged.connect(self._sync_online)
        layout.addWidget(on_box)

        layout.addStretch(1)
        return page

    # ------------------------------------------------------------------ #
    def _build_training_tab(self) -> QWidget:
        page = QWidget()
        page.setObjectName("RightPanel")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(12)

        data_box = QGroupBox("DATASETS")
        dl = QVBoxLayout(data_box)
        self.dataset_list = QListWidget()
        self.dataset_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.dataset_list.setMinimumHeight(110)
        dl.addWidget(self.dataset_list)

        row = QHBoxLayout()
        for text, slot in (
            ("Add files...", self.add_dataset_files),
            ("Add folder...", self.add_dataset_folder),
            ("Remove", self.remove_dataset),
        ):
            btn = QPushButton(text)
            btn.clicked.connect(slot)
            row.addWidget(btn)
        dl.addLayout(row)

        self.include_memory_check = QCheckBox("Include my chats")
        self.include_memory_check.setChecked(True)
        dl.addWidget(self.include_memory_check)
        self.dataset_hint = QLabel("Supported: .txt, .json, .jsonl, .md, or a folder.")
        self.dataset_hint.setObjectName("Muted")
        self.dataset_hint.setWordWrap(True)
        dl.addWidget(self.dataset_hint)
        layout.addWidget(data_box)

        hp_box = QGroupBox("HYPERPARAMETERS")
        hl = self._tighten(QFormLayout(hp_box))
        self.epochs_spin = self._spin(1, 500, 8)
        self.batch_spin = self._spin(1, 512, 16)
        self.lr_spin = self._dspin(0.000001, 0.01, 0.0003, 0.00005, decimals=6)
        self.accum_spin = self._spin(1, 64, 1)
        self.val_spin = self._dspin(0.0, 0.5, 0.05, 0.01)
        self.max_pairs_spin = self._spin(0, 5_000_000, 0, step=1000)
        self.max_pairs_spin.setToolTip(
            "Train on a random subsample of this many prompt/response pairs. "
            "0 uses everything. Lower this to keep CPU training times sane."
        )
        self.max_resp_spin = self._spin(0, 100_000, 0, step=100)
        self.max_resp_spin.setToolTip(
            "Skip pairs whose response is longer than this many characters. "
            "0 keeps everything. Small models cannot learn long answers anyway."
        )
        self.amp_check = QCheckBox("Mixed precision (GPU)")
        self.amp_check.setChecked(True)
        hl.addRow("Epochs", self.epochs_spin)
        hl.addRow("Batch size", self.batch_spin)
        hl.addRow("Learning rate", self.lr_spin)
        hl.addRow("Grad accum", self.accum_spin)
        hl.addRow("Val split", self.val_spin)
        hl.addRow("Max pairs (0 = all)", self.max_pairs_spin)
        hl.addRow("Max reply chars", self.max_resp_spin)
        hl.addRow(self.amp_check)
        layout.addWidget(hp_box)

        run_box = QGroupBox("RUN")
        rl = QVBoxLayout(run_box)
        btn_row = QHBoxLayout()
        self.train_btn = QPushButton("Start training")
        self.train_btn.setObjectName("Primary")
        self.train_btn.clicked.connect(self.start_training)
        self.train_stop_btn = QPushButton("Stop")
        self.train_stop_btn.setEnabled(False)
        self.train_stop_btn.clicked.connect(self.stop_training)
        btn_row.addWidget(self.train_btn)
        btn_row.addWidget(self.train_stop_btn)
        rl.addLayout(btn_row)

        self.train_progress = QProgressBar()
        self.train_progress.setRange(0, 100)
        rl.addWidget(self.train_progress)

        self.train_status = QLabel("idle")
        self.train_status.setObjectName("Muted")
        rl.addWidget(self.train_status)

        self.train_log = QPlainTextEdit()
        self.train_log.setReadOnly(True)
        self.train_log.setMinimumHeight(200)
        self.train_log.setPlaceholderText("Training output appears here.")
        rl.addWidget(self.train_log, 1)
        layout.addWidget(run_box, 1)

        return page

    # ------------------------------------------------------------------ #
    def _build_memory_tab(self) -> QWidget:
        page = QWidget()
        page.setObjectName("RightPanel")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        facts_note = QLabel("Long-term memory. These are added to the prompt when they look relevant.")
        facts_note.setObjectName("Muted")
        facts_note.setWordWrap(True)
        self.mem_stats = QLabel("-")
        self.mem_stats.setObjectName("Muted")
        self.mem_stats.setWordWrap(True)
        layout.addWidget(self.mem_stats)

        layout.addWidget(self._label("FACTS"))
        layout.addWidget(facts_note)
        self.facts_table = QTableWidget(0, 3)
        self.facts_table.setHorizontalHeaderLabels(["Key", "Value", "Source"])
        self.facts_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.ResizeMode.Stretch
        )
        self.facts_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.facts_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.facts_table.setMinimumHeight(160)
        layout.addWidget(self.facts_table, 1)

        self._memory_edit_widgets = []
        frow = QHBoxLayout()
        for text, slot, obj, needs_admin in (
            ("Add fact", self.add_fact, "", True),
            ("Delete", self.delete_fact, "Danger", True),
            ("Clear all", self.clear_facts, "Danger", True),
            ("Refresh", self.refresh_memory, "", False),
        ):
            btn = QPushButton(text)
            if obj:
                btn.setObjectName(obj)
            btn.clicked.connect(slot)
            if needs_admin:
                self._memory_edit_widgets.append(btn)
            frow.addWidget(btn)
        layout.addLayout(frow)

        layout.addWidget(self._label("TRAINING SAMPLES"))
        self.samples_table = QTableWidget(0, 4)
        self.samples_table.setHorizontalHeaderLabels(["#", "You said", "AXON replied", "Rating"])
        self.samples_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.ResizeMode.Stretch
        )
        self.samples_table.horizontalHeader().setSectionResizeMode(
            2, QHeaderView.ResizeMode.Stretch
        )
        self.samples_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.samples_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.samples_table.setMinimumHeight(220)
        layout.addWidget(self.samples_table, 2)

        srow = QHBoxLayout()
        for text, slot, obj in (
            ("Good", lambda: self.rate_sample(1), ""),
            ("Bad", lambda: self.rate_sample(-1), ""),
            ("Delete", self.delete_sample, "Danger"),
        ):
            btn = QPushButton(text)
            if obj:
                btn.setObjectName(obj)
            btn.clicked.connect(slot)
            if text.startswith("Delete"):
                self._memory_edit_widgets.append(btn)
            srow.addWidget(btn)
        layout.addLayout(srow)

        note = QLabel(
            "Replies marked Bad are never trained on. All of this lives in "
            "data/axon_memory.db on this machine."
        )
        note.setObjectName("Muted")
        note.setWordWrap(True)
        layout.addWidget(note)
        return page

    @staticmethod
    def _label(text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setObjectName("SectionTitle")
        lbl.setWordWrap(True)          # otherwise it sets the panel's minimum width
        return lbl

    @staticmethod
    def _spin(lo: int, hi: int, value: int, step: int = 1) -> QSpinBox:
        s = QSpinBox()
        s.setRange(lo, hi)
        s.setSingleStep(step)
        s.setValue(value)
        return s

    @staticmethod
    def _dspin(lo: float, hi: float, value: float, step: float, decimals: int = 2) -> QDoubleSpinBox:
        s = QDoubleSpinBox()
        s.setDecimals(decimals)
        s.setRange(lo, hi)
        s.setSingleStep(step)
        s.setValue(value)
        return s

    # ================================================================== #
    # startup / settings
    # ================================================================== #
    def _sign_in(self) -> None:
        """Ask who is using AXON, so each person keeps their own chats."""
        dialog = SignInDialog(self.accounts, self)
        if dialog.exec() != QDialog.DialogCode.Accepted or dialog.account is None:
            # No account, no session - close rather than show someone else's chats.
            QTimer.singleShot(0, self.close)
            return
        self.account = dialog.account
        self.engine.memory.set_account(self.account.id)
        self.setWindowTitle(
            f"AXON  -  {MODEL_FAMILY} models  -  {self.account.name}"
        )
        self.status_account.setText(self.account.name)
        self.refresh_conversations()
        self.refresh_memory()

    def sign_out(self) -> None:
        self.engine.conversation_id = None
        self.transcript.clear()
        self.account = None
        self._sign_in()

    def _startup(self) -> None:
        self._apply_access()
        self.refresh_conversations()
        self.refresh_memory()
        loaded = self.engine.load()
        self.refresh_status()
        self.model_switcher.refresh()
        self.model_picker.refresh()
        self.command_center.maybe_auto_check()
        if self.engine.memory.get_meta("seen_version") != __version__:
            QTimer.singleShot(400, lambda: self.show_whats_new(only_new=True))
        if loaded:
            self.transcript.show_welcome(model_name(self.engine.model.cfg))
        else:
            self.transcript.add_message(
                "system",
                "No checkpoint found yet.\n\n"
                "Open the Model tab and press 'Create new model' to build a tokenizer and "
                "network from the seed data in data/, then use the Training tab to train it. "
                "Nothing here talks to the internet.",
            )
            self.tabs.setCurrentIndex(0)

    def _restore_settings(self) -> None:
        gen = self.engine.memory.get_meta("generation")
        if isinstance(gen, dict):
            self.temp_spin.setValue(float(gen.get("temperature", 0.9)))
            self.topk_spin.setValue(int(gen.get("top_k", 50)))
            self.topp_spin.setValue(float(gen.get("top_p", 0.92)))
            self.rep_spin.setValue(float(gen.get("repetition_penalty", 1.15)))
            self.maxtok_spin.setValue(int(gen.get("max_new_tokens", 200)))
            self.seed_spin.setValue(int(gen.get("seed", -1)))
        online = self.engine.memory.get_meta("online")
        if isinstance(online, dict):
            self.online_check.setChecked(bool(online.get("enabled", True)))
            self.online_every_spin.setValue(int(online.get("every_n_exchanges", 4)))
            self.online_steps_spin.setValue(int(online.get("steps", 6)))
            self.online_lr_spin.setValue(
                min(float(online.get("learning_rate", 5e-5)), MAX_ONLINE_LR)
            )
        ckpt = self.engine.memory.get_meta("checkpoint")
        if isinstance(ckpt, str) and ckpt:
            self.engine.checkpoint_path = Path(ckpt)
            self.ckpt_edit.setText(ckpt)
        paths = self.engine.memory.get_meta("dataset_paths")
        if isinstance(paths, list):
            for p in paths:
                if Path(p).exists():
                    self._add_dataset_path(p)
        self._sync_generation()
        self._sync_online()

    def _persist_settings(self) -> None:
        self.engine.memory.set_meta("generation", self.engine.generation.to_dict())
        self.engine.memory.set_meta(
            "online",
            {
                "enabled": self.online_check.isChecked(),
                "every_n_exchanges": self.online_every_spin.value(),
                "steps": self.online_steps_spin.value(),
                "learning_rate": self.online_lr_spin.value(),
            },
        )
        self.engine.memory.set_meta("checkpoint", str(self.engine.checkpoint_path))
        self.engine.memory.set_meta("dataset_paths", self.dataset_paths)

    def _sync_generation(self) -> None:
        self.engine.generation = GenerationConfig(
            max_new_tokens=self.maxtok_spin.value(),
            temperature=self.temp_spin.value(),
            top_k=self.topk_spin.value(),
            top_p=self.topp_spin.value(),
            repetition_penalty=self.rep_spin.value(),
            seed=self.seed_spin.value(),
        )

    def _sync_online(self) -> None:
        self.engine.online_cfg = OnlineConfig(
            enabled=self.online_check.isChecked(),
            every_n_exchanges=self.online_every_spin.value(),
            steps=self.online_steps_spin.value(),
            learning_rate=self.online_lr_spin.value(),
        )

    def _apply_preset(self, *_args) -> None:
        preset = MODEL_PRESETS.get(self.preset_combo.currentData())
        if not preset:
            return
        self.layer_spin.setValue(preset.n_layer)
        self.head_spin.setValue(preset.n_head)
        self.embd_spin.setValue(preset.n_embd)
        self.block_spin.setValue(preset.block_size)

    # ------------------------------------------------------------------ #
    def _build_models_tab(self) -> QWidget:
        """The customer-facing page: which Vesper model is in use."""
        page = QWidget()
        page.setObjectName("RightPanel")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(14, 16, 14, 16)
        layout.setSpacing(12)

        heading = QLabel("Vesper models")
        heading.setObjectName("StatBig")
        layout.addWidget(heading)

        sub = QLabel("Every model runs on this computer. Nothing you type is sent anywhere.")
        sub.setObjectName("Muted")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        layout.addWidget(self.model_switcher)
        layout.addStretch(1)
        return page

    def _switch_model(self, path: str) -> None:
        if self._workers_busy():
            return
        try:
            self.engine.load(path)
        except Exception as exc:
            QMessageBox.critical(self, "Could not switch model", str(exc))
            return
        self.refresh_status()
        self.model_switcher.refresh()
        self.model_picker.refresh()
        self.transcript.add_message(
            "system", f"Switched to {model_name(self.engine.model.cfg)}."
        )

    def check_updates_now(self) -> None:
        """Available to everyone: receiving an update is not an owner action."""
        self.tabs.setCurrentIndex(max(0, self._tab_index("Command")))
        self.command_center.check_updates()
        self.status_msg.setText("checking for updates...")

    def show_whats_new(self, only_new: bool = False) -> None:
        releases = (
            patchnotes.since(self.engine.memory.get_meta("seen_version"))
            if only_new else patchnotes.RELEASES
        )
        if not releases:
            return
        # Record it first: the dialog is modal, and if the window is closed
        # while it is open the database is already gone by the time it returns.
        self.engine.memory.set_meta("seen_version", __version__)
        WhatsNewDialog(releases, self).exec()

    # ================================================================== #
    # access control
    # ================================================================== #
    def unlock_admin(self) -> None:
        if not self.access.is_protected:
            QMessageBox.information(
                self, "No password set",
                "This copy has no admin password, so everything is already "
                "unlocked. Set one in the Command Center to put it in friend mode.",
            )
            return
        if self.access.is_admin:
            self.status_msg.setText("already unlocked")
            return
        waiting = self.access.lockout_remaining()
        if waiting > 0:
            QMessageBox.warning(
                self, "Too many attempts",
                f"Wait {int(waiting) + 1} seconds before trying again.",
            )
            return
        password, ok = QInputDialog.getText(
            self, "Unlock AXON", "Owner password:", QLineEdit.EchoMode.Password
        )
        if not ok:
            return
        if self.access.unlock(password):
            self._apply_access()
            self.status_msg.setText("unlocked - owner mode")
        else:
            waiting = self.access.lockout_remaining()
            QMessageBox.warning(
                self, "Wrong password",
                "That password is not right."
                + (f"  Too many attempts - locked for {int(waiting) + 1} seconds."
                   if waiting > 0 else ""),
            )

    def lock_admin(self) -> None:
        if not self.access.is_protected:
            QMessageBox.information(
                self, "No password set",
                "Set an admin password in the Command Center first, otherwise "
                "locking does nothing.",
            )
            return
        self.access.lock()
        self._apply_access()
        self.status_msg.setText("locked - friend mode")

    def open_command_center(self) -> None:
        index = self._tab_index("Command")
        if index < 0:
            QMessageBox.information(
                self, "Locked", "Unlock as admin to open the Command Center."
            )
            return
        self.tabs.setCurrentIndex(index)

    def _tab_index(self, label: str) -> int:
        for i in range(self.tabs.count()):
            if self.tabs.tabText(i) == label:
                return i
        return -1

    def _apply_access(self) -> None:
        """Show admin-only controls only to an admin."""
        caps = self.access.capabilities
        admin = self.access.is_admin

        # Whole tabs come and go. They are re-inserted at their usual position
        # so unlocking does not shuffle the tab bar.
        for position, label, widget, allowed in (
            (0, "Models", self._models_tab, admin),
            (2, "Training", self._training_tab, caps.train),
            (4, "Command", self._command_tab, admin),
        ):
            index = self._tab_index(label)
            if allowed and index < 0:
                self.tabs.insertTab(min(position, self.tabs.count()), widget, label)
            elif not allowed and index >= 0:
                self.tabs.removeTab(index)

        # model editing
        for widget in (self.create_btn, self.preset_combo, self.vocab_spin,
                       self.layer_spin, self.head_spin, self.embd_spin,
                       self.block_spin, self.dropout_spin):
            widget.setEnabled(caps.create_model)
        self.new_model_box.setVisible(caps.create_model)
        self.checkpoint_box.setVisible(caps.load_checkpoint or caps.save_checkpoint)
        self.online_box.setVisible(admin)

        # settings that only affect this machine stay open to everyone
        for widget in (self.temp_spin, self.topk_spin, self.topp_spin, self.rep_spin,
                       self.maxtok_spin, self.seed_spin, self.memory_check,
                       self.learn_check):
            widget.setEnabled(caps.device_settings)

        # memory editing (friends may still read and rate)
        for widget in self._memory_edit_widgets:
            widget.setEnabled(caps.edit_memory)

        self.command_center.refresh()
        self.status_role.setText(
            "owner" if admin else ("user mode" if self.access.is_protected else "unprotected")
        )

    # ================================================================== #
    # status
    # ================================================================== #
    def _engine_log(self, message: str) -> None:
        print(f"[axon] {message}")
        if hasattr(self, "train_log"):
            self.train_log.appendPlainText(str(message))

    def refresh_status(self) -> None:
        s = self.engine.status()
        self.tile_device.set_value(str(s["device"]))
        self.status_device.setText(str(s['device']).split(' - ')[0])
        if s.get("loaded"):
            name = model_name(self.engine.model.cfg)
            self.tile_name.set_value(name)
            self.tile_params.set_value(f"{s['parameters']:,}")
            self.tile_vocab.set_value(f"{s['vocab_size']:,}")
            self.tile_ctx.set_value(
                f"{s['block_size']} tok  ({s['layers']}L x {s['heads']}H x {s['width']})"
            )
            self.tile_steps.set_value(f"{s['trained_steps']:,}")
            vl = s.get("val_loss")
            self.tile_loss.set_value(f"{vl:.4f}" if isinstance(vl, float) else "-")
            self.status_model.setText(f"{name}  ·  {s['parameters'] / 1e6:.1f}M")
        else:
            for tile in (self.tile_name, self.tile_params, self.tile_vocab,
                         self.tile_ctx, self.tile_steps, self.tile_loss):
                tile.set_value("-")
            self.status_model.setText("no model loaded")
        self.ckpt_edit.setText(str(self.engine.checkpoint_path))

    def set_busy(self, busy: bool, message: str = "") -> None:
        self.send_btn.setEnabled(not busy)
        self.composer.setEnabled(not busy)
        self.stop_btn.setEnabled(busy)
        self.status_msg.setText(message or ("working..." if busy else "ready"))

    # ================================================================== #
    # chat
    # ================================================================== #
    def new_chat(self) -> None:
        self.engine.conversation_id = None
        self.transcript.show_welcome(
            model_name(self.engine.model.cfg) if self.engine.ready else ""
        )
        self.conv_list.clearSelection()

    def send_message(self, text: str) -> None:
        text = (text or "").strip()
        if not text:
            return
        if not self.engine.ready:
            QMessageBox.information(
                self, "No model",
                "There is no model loaded yet.\n\n"
                "Go to the Model tab and press 'Create new model', or load a checkpoint.",
            )
            return
        if self.gen_worker is not None and self.gen_worker.isRunning():
            return
        if self.train_worker is not None and self.train_worker.isRunning():
            QMessageBox.information(self, "Busy", "Training is running - wait for it to finish.")
            return

        self.composer.clear()
        self.transcript.add_message("user", text)
        self.current_bubble = self.transcript.add_message("bot", "")
        self.current_bubble.rated.connect(self._on_rated)
        self.set_busy(True, "generating...")

        self._sync_generation()
        self._sync_online()
        self.gen_worker = GenerateWorker(
            self.engine, text, self.engine.generation,
            use_memory=self.memory_check.isChecked(),
            learn=self.learn_check.isChecked(),
        )
        self.gen_worker.chunk.connect(self._on_chunk)
        self.gen_worker.finished_ok.connect(self._on_reply_done)
        self.gen_worker.failed.connect(self._on_worker_error)
        self.gen_worker.start()

    def _on_chunk(self, piece: str) -> None:
        if self.current_bubble is not None:
            self.current_bubble.append_text(piece)
            self.transcript.scroll_to_bottom()

    def _on_reply_done(self, reply: str, info: dict) -> None:
        bubble = self.current_bubble
        if bubble is not None and not bubble.text().strip():
            bubble.set_text(reply)
        if bubble is not None:
            bubble.enable_rating(info.get("sample_id"))
        self.current_bubble = None
        self.set_busy(False)

        facts = info.get("facts") or []
        if facts:
            pairs = ", ".join(f"{k.split('.')[-1]} = {v}" for k, v in facts)
            self.transcript.add_message("system", f"Remembered: {pairs}")
        if info.get("auto_rejected"):
            self.transcript.add_message(
                "system",
                "That reply came out broken, so it was marked Bad automatically "
                "and will not be trained on. Lower the temperature in the Model "
                "tab, or start a new chat.",
            )
        loss = info.get("online_loss")
        if isinstance(loss, float):
            self.status_msg.setText(f"learned from recent chats (loss {loss:.4f})")
        self.refresh_conversations()
        self.refresh_memory()
        self.refresh_status()

    def _on_rated(self, sample_id: int, rating: int) -> None:
        """A rating is the supervision signal - a Good reply may be learned from."""
        self.engine.memory.rate_sample(sample_id, rating)
        self.refresh_memory()
        if rating > 0 and self.online_check.isChecked() and self.learn_check.isChecked():
            self.status_msg.setText("marked good - learning from it...")
            self.run_online_update()
        else:
            self.status_msg.setText(
                "marked good" if rating > 0 else "marked bad - excluded from training"
            )

    def stop_generation(self) -> None:
        if self.gen_worker is not None and self.gen_worker.isRunning():
            self.gen_worker.stop()
            self.status_msg.setText("stopping...")

    def _on_worker_error(self, message: str) -> None:
        self.set_busy(False)
        self.current_bubble = None
        QMessageBox.critical(self, "Error", message)
        self.status_msg.setText("error")

    # ================================================================== #
    # conversations
    # ================================================================== #
    @staticmethod
    def _ago(when: float) -> str:
        """'just now', '5m', '2h', '3d' - short enough for a narrow sidebar."""
        seconds = max(0.0, time.time() - float(when or 0))
        if seconds < 90:
            return "just now"
        for cutoff, divisor, suffix in (
            (3600, 60, "m"), (86400, 3600, "h"), (7 * 86400, 86400, "d")
        ):
            if seconds < cutoff:
                return f"{int(seconds // divisor)}{suffix} ago"
        return time.strftime("%d %b", time.localtime(when))

    def refresh_conversations(self) -> None:
        self.conv_list.clear()
        for row in self.engine.memory.list_conversations():
            title = (row["title"] or "New chat").strip()
            if len(title) > 32:
                title = title[:31].rstrip() + "…"
            item = QListWidgetItem(f"{title}\n{self._ago(row['updated_at'])}")
            item.setData(Qt.ItemDataRole.UserRole, int(row["id"]))
            self.conv_list.addItem(item)
            if self.engine.conversation_id == int(row["id"]):
                item.setSelected(True)

    def _open_conversation_item(self, item: QListWidgetItem) -> None:
        conv_id = int(item.data(Qt.ItemDataRole.UserRole))
        messages = self.engine.open_conversation(conv_id)
        self.transcript.clear()
        for m in messages:
            self.transcript.add_message(m.role, m.content)
        self.transcript.scroll_to_bottom()

    def _conversation_context_menu(self, pos) -> None:
        item = self.conv_list.itemAt(pos)
        if item is None:
            return
        conv_id = int(item.data(Qt.ItemDataRole.UserRole))
        menu = QMenu(self)
        rename = menu.addAction("Rename...")
        delete = menu.addAction("Delete")
        action = menu.exec(self.conv_list.mapToGlobal(pos))
        if action == rename:
            title, ok = QInputDialog.getText(self, "Rename conversation", "New title:")
            if ok and title.strip():
                self.engine.memory.rename_conversation(conv_id, title.strip())
                self.refresh_conversations()
        elif action == delete:
            self.engine.memory.delete_conversation(conv_id)
            if self.engine.conversation_id == conv_id:
                self.new_chat()
            self.refresh_conversations()

    def export_conversations(self) -> None:
        import json

        path, _ = QFileDialog.getSaveFileName(
            self, "Export conversations", str(Paths.DATA / "conversations.json"),
            "JSON (*.json)",
        )
        if not path:
            return
        out = []
        for row in self.engine.memory.list_conversations(limit=10000):
            msgs = self.engine.memory.get_messages(int(row["id"]))
            out.append(
                {
                    "title": row["title"],
                    "messages": [
                        {"role": "user" if m.role == "user" else "assistant",
                         "content": m.content}
                        for m in msgs if m.role in ("user", "bot")
                    ],
                }
            )
        Path(path).write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
        QMessageBox.information(self, "Exported", f"{len(out)} conversations written to\n{path}")

    # ================================================================== #
    # model actions
    # ================================================================== #
    def create_model(self) -> None:
        if self._workers_busy():
            return
        answer = QMessageBox.question(
            self, "Create new model",
            "This trains a fresh tokenizer and initialises new random weights.\n"
            "The current model in memory will be replaced (your checkpoint file "
            "on disk is untouched until you save).\n\nContinue?",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return

        try:
            cfg = ModelConfig(
                vocab_size=self.vocab_spin.value(),
                block_size=self.block_spin.value(),
                n_layer=self.layer_spin.value(),
                n_head=self.head_spin.value(),
                n_embd=self.embd_spin.value(),
                dropout=self.dropout_spin.value(),
            )
        except ValueError as exc:
            QMessageBox.warning(self, "Invalid configuration", str(exc))
            return

        self.create_btn.setEnabled(False)
        self.build_progress.setVisible(True)
        self.build_progress.setRange(0, 0)
        self.set_busy(True, "building tokenizer + model...")
        self.tabs.setCurrentIndex(0)

        self.build_worker = BuildWorker(
            self.engine, self.dataset_paths, cfg, self.vocab_spin.value(),
            include_memory=self.include_memory_check.isChecked(),
        )
        self.build_worker.progress.connect(self._on_build_progress)
        self.build_worker.finished_ok.connect(self._on_build_done)
        self.build_worker.failed.connect(self._on_build_failed)
        self.build_worker.start()

    def _on_build_progress(self, done: int, total: int, message: str) -> None:
        if total > 0:
            self.build_progress.setRange(0, total)
            self.build_progress.setValue(done)
        self.status_msg.setText(message)

    def _on_build_done(self, info: dict) -> None:
        self.build_progress.setVisible(False)
        self.create_btn.setEnabled(True)
        self.set_busy(False)
        self.refresh_status()
        self.transcript.add_message(
            "system",
            f"New model created: {info['parameters']:,} parameters, "
            f"vocabulary {info['vocab_size']:,}.\n"
            f"Seed corpus: {info['pairs']:,} pairs and {info['documents']:,} documents.\n\n"
            "The weights are random right now - open the Training tab and press "
            "'Start training' to teach it.",
        )
        self.tabs.setCurrentIndex(1)

    def _on_build_failed(self, message: str) -> None:
        self.build_progress.setVisible(False)
        self.create_btn.setEnabled(True)
        self._on_worker_error(message)

    def load_checkpoint_dialog(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Load checkpoint", str(Paths.CHECKPOINTS), CKPT_FILTER
        )
        if path:
            self.load_checkpoint(path)

    def load_checkpoint(self, path: Optional[str]) -> None:
        if self._workers_busy():
            return
        try:
            ok = self.engine.load(path)
        except Exception as exc:
            QMessageBox.critical(self, "Load failed", str(exc))
            return
        if not ok:
            QMessageBox.information(self, "Not found", "No checkpoint at that location.")
            return
        self.refresh_status()
        self.transcript.add_message(
            "system", f"Loaded checkpoint: {Path(self.engine.checkpoint_path).name}"
        )

    def save_checkpoint(self) -> None:
        if not self.engine.ready:
            QMessageBox.information(self, "Nothing to save", "No model is loaded.")
            return
        try:
            path = self.engine.save()
        except Exception as exc:
            QMessageBox.critical(self, "Save failed", str(exc))
            return
        self.refresh_status()
        self.status_msg.setText(f"saved -> {path}")

    def save_checkpoint_as(self) -> None:
        if not self.engine.ready:
            QMessageBox.information(self, "Nothing to save", "No model is loaded.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save checkpoint as", str(Paths.CHECKPOINTS / "axon.pt"), CKPT_FILTER
        )
        if not path:
            return
        self.engine.save(path)
        self.refresh_status()
        self.status_msg.setText(f"saved -> {path}")

    def run_online_update(self) -> None:
        if not self.engine.ready:
            QMessageBox.information(self, "No model", "Load or create a model first.")
            return
        if self._workers_busy():
            return
        self.online_btn.setEnabled(False)
        self.set_busy(True, "running an online learning update...")
        self.online_worker = OnlineWorker(self.engine)
        self.online_worker.finished_ok.connect(self._on_online_done)
        self.online_worker.failed.connect(self._on_worker_error)
        self.online_worker.start()

    def _on_online_done(self, loss) -> None:
        self.online_btn.setEnabled(True)
        self.set_busy(False)
        self.refresh_status()
        if loss is None:
            self.transcript.add_message(
                "system", "Nothing to learn from yet - have a few conversations first."
            )
        else:
            self.transcript.add_message("system", f"Online update finished. Loss {loss:.4f}.")

    # ================================================================== #
    # training
    # ================================================================== #
    def _add_dataset_path(self, path: str) -> None:
        if path in self.dataset_paths:
            return
        self.dataset_paths.append(path)
        self.dataset_list.addItem(path)

    def add_dataset_files(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Add dataset files", str(Paths.DATA), DATA_FILTER
        )
        for p in paths:
            self._add_dataset_path(p)

    def add_dataset_folder(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Add dataset folder", str(Paths.DATA))
        if path:
            self._add_dataset_path(path)

    def remove_dataset(self) -> None:
        for item in self.dataset_list.selectedItems():
            path = item.text()
            if path in self.dataset_paths:
                self.dataset_paths.remove(path)
            self.dataset_list.takeItem(self.dataset_list.row(item))

    def start_training(self) -> None:
        if not self.engine.ready:
            QMessageBox.information(
                self, "No model", "Create or load a model before training."
            )
            return
        if self._workers_busy():
            return
        if not self.dataset_paths and not self.include_memory_check.isChecked():
            QMessageBox.information(
                self, "No data",
                "Add at least one dataset file, or enable "
                "'Also train on stored conversations'.",
            )
            return

        cfg = TrainConfig(
            epochs=self.epochs_spin.value(),
            batch_size=self.batch_spin.value(),
            learning_rate=self.lr_spin.value(),
            grad_accum=self.accum_spin.value(),
            val_split=self.val_spin.value(),
            amp=self.amp_check.isChecked(),
        )
        paths = list(self.dataset_paths)
        if not paths:
            paths = [str(p) for p in (Paths.SEED_DIALOGUES, Paths.SEED_CORPUS) if p.exists()]

        self.train_log.clear()
        self.train_progress.setValue(0)
        self.train_btn.setEnabled(False)
        self.train_stop_btn.setEnabled(True)
        self.set_busy(True, "training...")
        self.tabs.setCurrentIndex(1)

        self.train_worker = TrainWorker(
            self.engine, paths, cfg,
            include_memory=self.include_memory_check.isChecked(),
            checkpoint=str(self.engine.checkpoint_path),
            max_pairs=self.max_pairs_spin.value(),
            max_response_chars=self.max_resp_spin.value(),
        )
        self.train_worker.log.connect(self.train_log.appendPlainText)
        self.train_worker.progress.connect(self._on_train_progress)
        self.train_worker.finished_ok.connect(self._on_train_done)
        self.train_worker.failed.connect(self._on_train_failed)
        self.train_worker.start()

    def _on_train_progress(self, p: dict) -> None:
        total = max(1, int(p["total_steps"]))
        self.train_progress.setValue(int(100 * int(p["step"]) / total))
        vl = p.get("val_loss")
        extra = f"   val {vl:.4f}" if isinstance(vl, float) else ""
        self.train_status.setText(
            f"epoch {p['epoch']}/{p['total_epochs']}   step {p['step']}/{p['total_steps']}   "
            f"loss {p['loss']:.4f}   {p['tokens_per_sec']:,.0f} tok/s{extra}"
        )

    def _on_train_done(self, result: dict) -> None:
        self.train_btn.setEnabled(True)
        self.train_stop_btn.setEnabled(False)
        self.train_progress.setValue(100)
        self.set_busy(False)
        self.refresh_status()
        vl = result.get("val_loss")
        self.train_status.setText(
            f"finished: {result['steps']:,} steps in {result['elapsed'] / 60:.1f} min"
            + (f", val loss {vl:.4f}" if isinstance(vl, float) else "")
        )
        self.transcript.add_message(
            "system",
            f"Training finished - {result['steps']:,} steps over "
            f"{result.get('total_examples', 0):,} examples. Checkpoint saved.",
        )

    def _on_train_failed(self, message: str) -> None:
        self.train_btn.setEnabled(True)
        self.train_stop_btn.setEnabled(False)
        self._on_worker_error(message)

    def stop_training(self) -> None:
        if self.train_worker is not None and self.train_worker.isRunning():
            self.train_worker.stop()
            self.train_status.setText("stopping after the current batch...")

    def import_dataset_dialog(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Import dataset into memory", str(Paths.DATA), DATA_FILTER
        )
        if not paths:
            return
        self.import_worker = ImportWorker(self.engine, paths)
        self.import_worker.finished_ok.connect(
            lambda info: (
                self.refresh_memory(),
                QMessageBox.information(
                    self, "Imported",
                    f"{info['pairs_imported']:,} prompt/response pairs added to memory.",
                ),
            )
        )
        self.import_worker.failed.connect(self._on_worker_error)
        self.import_worker.start()

    # ================================================================== #
    # memory tab
    # ================================================================== #
    def refresh_memory(self) -> None:
        stats = self.engine.memory.stats()
        self.mem_stats.setText(
            f"{stats['conversations']:,} conversations   -   {stats['messages']:,} messages   -   "
            f"{stats['facts']:,} facts   -   {stats['samples']:,} training samples"
        )

        facts = self.engine.memory.list_facts()
        self.facts_table.setRowCount(len(facts))
        for r, row in enumerate(facts):
            self.facts_table.setItem(r, 0, QTableWidgetItem(row["key"]))
            self.facts_table.setItem(r, 1, QTableWidgetItem(row["value"]))
            self.facts_table.setItem(r, 2, QTableWidgetItem(row["source"]))

        samples = self.engine.memory.recent_samples(n=200, min_rating=-1)
        self.samples_table.setRowCount(len(samples))
        for r, s in enumerate(samples):
            self.samples_table.setItem(r, 0, QTableWidgetItem(str(s.id)))
            self.samples_table.setItem(r, 1, QTableWidgetItem(s.prompt[:200]))
            self.samples_table.setItem(r, 2, QTableWidgetItem(s.response[:200]))
            self.samples_table.setItem(r, 3, QTableWidgetItem({1: "+1", -1: "-1"}.get(s.rating, "0")))

    def add_fact(self) -> None:
        key, ok = QInputDialog.getText(self, "New fact", "Key (e.g. user.name):")
        if not ok or not key.strip():
            return
        value, ok = QInputDialog.getText(self, "New fact", f"Value for '{key.strip()}':")
        if not ok or not value.strip():
            return
        self.engine.memory.upsert_fact(key.strip(), value.strip(), source="manual")
        self.refresh_memory()

    def _selected_fact_key(self) -> Optional[str]:
        rows = self.facts_table.selectionModel().selectedRows()
        if not rows:
            return None
        item = self.facts_table.item(rows[0].row(), 0)
        return item.text() if item else None

    def delete_fact(self) -> None:
        key = self._selected_fact_key()
        if not key:
            return
        self.engine.memory.delete_fact(key)
        self.refresh_memory()

    def clear_facts(self) -> None:
        answer = QMessageBox.question(
            self, "Clear memory", "Delete every stored fact? This cannot be undone."
        )
        if answer == QMessageBox.StandardButton.Yes:
            self.engine.memory.clear_facts()
            self.refresh_memory()

    def _selected_sample_id(self) -> Optional[int]:
        rows = self.samples_table.selectionModel().selectedRows()
        if not rows:
            return None
        item = self.samples_table.item(rows[0].row(), 0)
        return int(item.text()) if item else None

    def rate_sample(self, rating: int) -> None:
        sample_id = self._selected_sample_id()
        if sample_id is None:
            return
        self.engine.memory.rate_sample(sample_id, rating)
        self.refresh_memory()

    def delete_sample(self) -> None:
        sample_id = self._selected_sample_id()
        if sample_id is None:
            return
        self.engine.memory.delete_sample(sample_id)
        self.refresh_memory()

    # ================================================================== #
    def _workers_busy(self) -> bool:
        for worker in (self.gen_worker, self.train_worker, self.build_worker,
                       self.online_worker, self.import_worker):
            if worker is not None and worker.isRunning():
                QMessageBox.information(
                    self, "Busy", "Another job is still running. Wait for it to finish."
                )
                return True
        return False

    def show_about(self) -> None:
        s = self.engine.status()
        QMessageBox.about(
            self, "About AXON",
            f"<h3>AXON v{__version__}</h3>"
            f"<p><b>AXON</b> is the app. <b>{MODEL_FAMILY}</b> is the family of models it "
            "trains, in four sizes: Spark, Ember, Flare and Nova.</p>"
            "<p>A fully local language model: byte-level BPE tokenizer, decoder-only "
            "Transformer in PyTorch, SQLite memory, and continuous learning from your "
            "own conversations.</p>"
            "<p>No API keys. No network access. Everything stays on this machine.</p>"
            f"<p><b>Device:</b> {s['device']}<br>"
            f"<b>Checkpoint:</b> {s['checkpoint']}<br>"
            f"<b>Database:</b> {Paths.DB}</p>",
        )

    def closeEvent(self, event) -> None:  # noqa: N802
        for worker in (self.gen_worker, self.train_worker, self.build_worker,
                       self.online_worker, self.import_worker):
            if worker is not None and worker.isRunning():
                if hasattr(worker, "stop"):
                    worker.stop()
                worker.wait(4000)
        try:
            self._persist_settings()
            self.engine.close()
        except Exception:
            pass
        super().closeEvent(event)


def main() -> int:
    QGuiApplication.setAttribute(Qt.ApplicationAttribute.AA_DontUseNativeMenuBar, False)
    app = QApplication(sys.argv)
    app.setApplicationName("AXON")
    app.setStyleSheet(STYLESHEET)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
