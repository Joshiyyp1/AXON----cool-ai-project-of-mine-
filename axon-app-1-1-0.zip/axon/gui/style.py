"""AXON desktop theme - lila purple on black.

The look leans on restraint rather than decoration: one accent colour used
sparingly, generous spacing, quiet borders, and a clear type hierarchy. The
purple is desaturated on purpose so it reads as a product rather than a demo.
"""

# --------------------------------------------------------------------------- #
# palette
# --------------------------------------------------------------------------- #
# One family, top to bottom. Every colour here is a violet, a lilac or a
# near-black tinted with them - nothing warm, nothing green, so the accent
# never has to compete with a stray hue.
ACCENT = "#A97BFF"        # lila - the one bright thing on screen
ACCENT_HOVER = "#C2A2FF"
ACCENT_DEEP = "#7B52C9"
ACCENT_WASH = "#1F1733"   # lila at low weight, for selected rows
ACCENT_EDGE = "#4A3572"   # lila pushed back into the dark, for quiet borders

BG = "#09070E"            # near-black, violet-biased
PANEL = "#100D18"
PANEL_2 = "#171322"
PANEL_3 = "#20192E"
PANEL_4 = "#2A2140"       # raised surface, e.g. an active row
BORDER = "#251F31"
BORDER_LIT = "#3A2F52"

TEXT = "#F1EDF7"
MUTED = "#9A92AE"
FAINT = "#665E7B"
ON_ACCENT = "#120A1E"
DANGER = "#D9639F"        # magenta, still inside the violet family
OK = "#B79BFF"            # success reads as a lighter lila, not green

STYLESHEET = f"""
* {{
    font-family: "Segoe UI", "Inter", "Helvetica Neue", sans-serif;
    font-size: 13px;
    color: {TEXT};
}}

QMainWindow, QDialog {{ background: {BG}; }}
QWidget#Sidebar, QWidget#RightPanel {{ background: {PANEL}; }}
QWidget#ChatArea {{ background: {BG}; }}

/* ---------- brand + headings ---------- */
QLabel#Brand {{
    font-size: 17px;
    font-weight: 800;
    color: {TEXT};
    padding: 18px 16px 2px 16px;
    letter-spacing: 4px;
}}
QLabel#BrandSub {{
    font-size: 11px;
    color: {FAINT};
    padding: 0 16px 14px 16px;
    letter-spacing: 0.5px;
}}
QLabel#SectionTitle {{
    font-size: 10px;
    font-weight: 700;
    color: {FAINT};
    letter-spacing: 1.4px;
    padding: 8px 2px 2px 2px;
}}
QLabel#DialogTitle {{
    font-size: 22px;
    font-weight: 700;
    letter-spacing: -0.2px;
}}
QLabel#Muted {{ color: {MUTED}; }}
QLabel#StatBig {{ font-size: 15px; font-weight: 600; color: {TEXT}; }}

/* ---------- buttons ---------- */
QPushButton {{
    background: transparent;
    border: 1px solid {BORDER};
    border-radius: 9px;
    padding: 8px 15px;
    color: {TEXT};
}}
QPushButton:hover  {{ background: {PANEL_3}; border-color: {BORDER_LIT}; }}
QPushButton:pressed {{ background: #130F1E; }}
QPushButton:disabled {{ color: {FAINT}; background: #0E0B15; border-color: #1C1726; }}

QPushButton#Primary {{
    background: {ACCENT};
    border: 1px solid {ACCENT};
    color: {ON_ACCENT};
    font-weight: 700;
}}
QPushButton#Primary:hover {{ background: {ACCENT_HOVER}; border-color: {ACCENT_HOVER}; }}
QPushButton#Primary:pressed {{ background: {ACCENT_DEEP}; border-color: {ACCENT_DEEP}; }}
QPushButton#Primary:disabled {{ background: #2F2547; border-color: #2F2547; color: #8A81A2; }}
QPushButton#Danger {{ border-color: #4A2440; }}
QPushButton#Danger:hover {{ background: #2E1730; border-color: {DANGER}; color: {DANGER}; }}

QPushButton#RateButton {{
    background: transparent;
    border: 1px solid {BORDER};
    border-radius: 6px;
    padding: 3px 11px;
    font-size: 11px;
    color: {MUTED};
}}
QPushButton#RateButton:hover {{ color: {ACCENT}; border-color: {ACCENT}; }}
QPushButton#RateButton:disabled {{ background: transparent; border-color: {BORDER}; color: {FAINT}; }}
QWidget#RatingRow {{ background: transparent; }}

QPushButton#CardButton {{
    background: transparent;
    border: 1px solid {ACCENT};
    color: {ACCENT};
    border-radius: 7px;
    padding: 5px 13px;
    font-size: 12px;
    font-weight: 600;
}}
QPushButton#CardButton:hover {{ background: {ACCENT}; color: {ON_ACCENT}; }}

/* ---------- model switcher cards ---------- */
QFrame#ModelCard, QFrame#ModelCardActive, QFrame#ModelCardSoon {{
    border-radius: 12px;
    border: 1px solid {BORDER};
    background: {PANEL_2};
}}
QFrame#ModelCardActive {{ border: 1px solid {ACCENT_DEEP}; background: {ACCENT_WASH}; }}
QFrame#ModelCardSoon {{ background: #0E0B15; border: 1px dashed {BORDER_LIT}; }}

QLabel#CardTitle {{ font-size: 14px; font-weight: 700; color: {TEXT}; background: transparent; }}
QLabel#CardTitleSoon {{ font-size: 14px; font-weight: 700; color: {FAINT}; background: transparent; }}
QLabel#CardBlurb {{ color: {MUTED}; background: transparent; }}
QLabel#CardBlurbSoon {{ color: {FAINT}; background: transparent; }}
QLabel#CardMeta {{ color: {FAINT}; font-size: 11px; background: transparent; }}

QLabel#Badge, QLabel#BadgeActive, QLabel#BadgeSoon {{
    font-size: 9px;
    font-weight: 800;
    letter-spacing: 1.2px;
    padding: 3px 8px;
    border-radius: 5px;
    background: {PANEL_3};
    color: {MUTED};
}}
QLabel#BadgeActive {{ background: {ACCENT}; color: {ON_ACCENT}; }}
QLabel#BadgeSoon {{ background: transparent; color: {FAINT}; border: 1px solid {BORDER}; }}

/* ---------- inputs ---------- */
QLineEdit, QPlainTextEdit, QTextEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
    background: {PANEL_2};
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 7px 9px;
    selection-background-color: {ACCENT};
    selection-color: {ON_ACCENT};
}}
QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus,
QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{ border-color: {ACCENT}; }}
QComboBox::drop-down {{ border: none; width: 20px; }}
QComboBox QAbstractItemView {{
    background: {PANEL_2};
    border: 1px solid {BORDER};
    selection-background-color: {ACCENT};
    selection-color: {ON_ACCENT};
    outline: none;
    padding: 4px;
}}
/* the message box and its controls read as one surface */
QFrame#InputCard {{
    background: {PANEL_2};
    border: 1px solid {BORDER};
    border-radius: 16px;
}}
QFrame#InputCard:focus-within {{ border-color: {BORDER_LIT}; }}
QTextEdit#Composer {{
    font-size: 14px;
    padding: 12px 14px;
    background: transparent;
    border: none;
}}

QPushButton#ModelPicker {{
    background: transparent;
    border: 1px solid transparent;
    border-radius: 7px;
    padding: 5px 10px;
    color: {MUTED};
    font-size: 12px;
    font-weight: 600;
    text-align: right;
}}
QPushButton#ModelPicker:hover {{ color: {TEXT}; background: {PANEL_3}; border-color: {BORDER}; }}
QTextBrowser#NotesBody {{
    background: {PANEL_2};
    border: 1px solid {BORDER};
    border-radius: 10px;
    padding: 16px;
}}

/* ---------- lists / tables ---------- */
QListWidget {{
    background: transparent;
    border: none;
    outline: none;
}}
QTableWidget, QTreeWidget {{
    background: {PANEL_2};
    border: 1px solid {BORDER};
    border-radius: 10px;
    outline: none;
}}
QListWidget::item {{ padding: 9px 11px; border-radius: 8px; color: {MUTED}; }}
QListWidget::item:selected {{ color: {TEXT}; }}
QListWidget::item:selected {{ background: {PANEL_4}; color: {TEXT}; }}
QListWidget::item:hover {{ background: {PANEL_3}; }}
QHeaderView::section {{
    background: {PANEL};
    border: none;
    border-bottom: 1px solid {BORDER};
    padding: 7px;
    color: {FAINT};
    font-weight: 700;
    font-size: 10px;
    letter-spacing: 1px;
}}
QTableWidget {{ gridline-color: {BORDER}; }}
QTableWidget::item {{ padding: 4px; }}
QTableWidget::item:selected {{ background: {ACCENT_WASH}; }}

/* ---------- tabs ---------- */
QTabWidget::pane {{ border: none; background: {PANEL}; }}
QTabBar::tab {{
    background: transparent;
    color: {FAINT};
    padding: 12px 14px;
    border-bottom: 2px solid transparent;
    font-size: 12px;
}}
QTabBar::tab:selected {{ color: {TEXT}; border-bottom: 2px solid {ACCENT}; font-weight: 600; }}
QTabBar::tab:hover {{ color: {ACCENT_HOVER}; }}

/* ---------- group boxes ---------- */
QGroupBox {{
    border: none;
    border-top: 1px solid {BORDER};
    border-radius: 0;
    margin-top: 20px;
    padding: 16px 2px 8px 2px;
    background: transparent;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 0px;
    padding: 0 8px 0 0;
    color: {FAINT};
    font-weight: 700;
    font-size: 10px;
    letter-spacing: 1.4px;
}}

/* ---------- empty state ---------- */
QLabel#WelcomeTitle {{
    font-size: 26px;
    font-weight: 700;
    color: {TEXT};
    letter-spacing: -0.3px;
    background: transparent;
}}
QLabel#WelcomeBody {{
    font-size: 14px;
    color: {MUTED};
    background: transparent;
    line-height: 150%;
}}
QLabel#WelcomeHint {{
    font-size: 12px;
    color: {FAINT};
    background: transparent;
}}

/* ---------- chat bubbles ---------- */
QFrame#UserBubble {{
    background: {PANEL_2};
    border: none;
    border-radius: 16px;
}}
QFrame#BotBubble {{
    background: transparent;
    border: none;
    border-radius: 16px;
}}
QFrame#SystemBubble {{
    background: transparent;
    border: none;
    border-radius: 10px;
}}
QLabel#BubbleText {{ font-size: 14px; line-height: 152%; background: transparent; }}
QLabel#BubbleRole {{
    font-size: 9px;
    font-weight: 800;
    color: {FAINT};
    letter-spacing: 1.4px;
    background: transparent;
}}

/* ---------- misc ---------- */
QProgressBar {{
    background: {PANEL_2};
    border: 1px solid {BORDER};
    border-radius: 8px;
    height: 16px;
    text-align: center;
    color: {MUTED};
}}
QProgressBar::chunk {{ background: {ACCENT}; border-radius: 7px; }}

QScrollBar:vertical {{ background: transparent; width: 11px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: #2C2440; border-radius: 5px; min-height: 32px; }}
QScrollBar::handle:vertical:hover {{ background: {ACCENT_DEEP}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 11px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: #2C2440; border-radius: 5px; min-width: 32px; }}
QScrollBar::handle:horizontal:hover {{ background: {ACCENT_DEEP}; }}

QSplitter::handle {{ background: {BORDER}; }}
QSplitter::handle:horizontal {{ width: 1px; }}

QStatusBar {{ background: {PANEL}; color: {FAINT}; border-top: 1px solid {BORDER}; }}
QStatusBar::item {{ border: none; }}
QStatusBar QLabel {{ font-size: 11px; padding: 0 10px; }}

QMenuBar {{ background: {PANEL}; border-bottom: 1px solid {BORDER}; }}
QMenuBar::item {{ padding: 7px 13px; background: transparent; }}
QMenuBar::item:selected {{ background: {PANEL_2}; color: {ACCENT}; }}
QMenu {{ background: {PANEL_2}; border: 1px solid {BORDER}; padding: 5px; border-radius: 8px; }}
QMenu::item {{ padding: 7px 26px 7px 13px; border-radius: 6px; }}
QMenu::item:selected {{ background: {PANEL_4}; color: {TEXT}; }}
QMenu::separator {{ height: 1px; background: {BORDER}; margin: 5px 8px; }}

QCheckBox {{ spacing: 9px; }}
QCheckBox::indicator {{
    width: 15px; height: 15px;
    border: 1px solid {BORDER_LIT};
    border-radius: 4px;
    background: {PANEL_2};
}}
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}
QCheckBox::indicator:hover {{ border-color: {ACCENT}; }}

QLabel#ErrorText {{ color: {DANGER}; font-size: 12px; }}
QPushButton#LinkButton {{
    background: transparent;
    border: none;
    color: {ACCENT};
    padding: 6px;
    font-size: 12px;
}}
QPushButton#LinkButton:hover {{ color: {ACCENT_HOVER}; text-decoration: underline; }}

QToolTip {{
    background: {PANEL_2};
    color: {TEXT};
    border: 1px solid {BORDER_LIT};
    padding: 7px;
    border-radius: 7px;
}}
"""
