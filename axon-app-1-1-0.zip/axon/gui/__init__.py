"""PySide6 desktop interface for AXON."""

from axon.gui.app import main, MainWindow  # noqa: F401

__all__ = ["main", "MainWindow"]
