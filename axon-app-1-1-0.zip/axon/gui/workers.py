"""Background QThread workers.

Anything that touches the model runs here so the interface never freezes:
generation, tokenizer + model construction, full training runs and online
learning updates.
"""
from __future__ import annotations

import traceback
from pathlib import Path
from typing import Dict, List, Optional, Sequence

from PySide6.QtCore import QThread, Signal

from axon.config import GenerationConfig, ModelConfig, TrainConfig
from axon.engine import AxonEngine


class GenerateWorker(QThread):
    """Streams a reply, then records the exchange and (optionally) learns."""

    chunk = Signal(str)
    finished_ok = Signal(str, dict)   # full reply, record info
    failed = Signal(str)

    def __init__(
        self,
        engine: AxonEngine,
        message: str,
        generation: GenerationConfig,
        use_memory: bool = True,
        learn: bool = True,
    ) -> None:
        super().__init__()
        self.engine = engine
        self.message = message
        self.generation = generation
        self.use_memory = use_memory
        self.learn = learn
        self._stop = False

    def stop(self) -> None:
        self._stop = True

    def run(self) -> None:
        try:
            parts: List[str] = []
            for piece in self.engine.stream(
                self.message,
                use_memory=self.use_memory,
                generation=self.generation,
                should_stop=lambda: self._stop,
            ):
                parts.append(piece)
                self.chunk.emit(piece)

            reply = "".join(parts).strip()
            if not reply:
                reply = "(no output - the model needs more training)"
            info: Dict = {}
            try:
                info = self.engine.record_exchange(self.message, reply, learn=self.learn)
            except Exception as exc:                       # memory must never kill a reply
                info = {"error": str(exc)}
            self.finished_ok.emit(reply, info)
        except Exception:
            self.failed.emit(traceback.format_exc(limit=6))


class BuildWorker(QThread):
    """Trains a fresh tokenizer and initialises a new model."""

    progress = Signal(int, int, str)
    finished_ok = Signal(dict)
    failed = Signal(str)

    def __init__(
        self,
        engine: AxonEngine,
        paths: Sequence[str],
        model_config: ModelConfig,
        vocab_size: int,
        include_memory: bool = True,
    ) -> None:
        super().__init__()
        self.engine = engine
        self.paths = list(paths)
        self.model_config = model_config
        self.vocab_size = vocab_size
        self.include_memory = include_memory

    def run(self) -> None:
        try:
            info = self.engine.build_new_model(
                corpus_paths=self.paths,
                model_config=self.model_config,
                vocab_size=self.vocab_size,
                include_memory=self.include_memory,
                progress=lambda d, t, m: self.progress.emit(int(d), int(t), str(m)),
            )
            self.finished_ok.emit(info)
        except Exception:
            self.failed.emit(traceback.format_exc(limit=6))


class TrainWorker(QThread):
    """Runs a full training pass with live logging and a stop switch."""

    log = Signal(str)
    progress = Signal(dict)
    finished_ok = Signal(dict)
    failed = Signal(str)

    def __init__(
        self,
        engine: AxonEngine,
        paths: Sequence[str],
        train_config: TrainConfig,
        include_memory: bool = True,
        checkpoint: Optional[str] = None,
        max_pairs: int = 0,
        max_response_chars: int = 0,
    ) -> None:
        super().__init__()
        self.engine = engine
        self.paths = list(paths)
        self.train_config = train_config
        self.include_memory = include_memory
        self.checkpoint = checkpoint
        self.max_pairs = max_pairs
        self.max_response_chars = max_response_chars
        self._stop = False

    def stop(self) -> None:
        self._stop = True

    def run(self) -> None:
        try:
            result = self.engine.train_on(
                paths=self.paths,
                train_config=self.train_config,
                include_memory=self.include_memory,
                checkpoint=Path(self.checkpoint) if self.checkpoint else None,
                max_pairs=self.max_pairs,
                max_response_chars=self.max_response_chars,
                on_log=lambda msg: self.log.emit(str(msg)),
                on_progress=lambda p: self.progress.emit(
                    {
                        "epoch": p.epoch, "total_epochs": p.total_epochs,
                        "step": p.step, "total_steps": p.total_steps,
                        "loss": p.loss, "lr": p.lr,
                        "tokens_per_sec": p.tokens_per_sec,
                        "elapsed": p.elapsed, "val_loss": p.val_loss,
                    }
                ),
                should_stop=lambda: self._stop,
            )
            self.finished_ok.emit(result)
        except Exception:
            self.failed.emit(traceback.format_exc(limit=6))


class OnlineWorker(QThread):
    """Applies an online learning update off the UI thread."""

    finished_ok = Signal(object)      # float loss or None
    failed = Signal(str)

    def __init__(self, engine: AxonEngine) -> None:
        super().__init__()
        self.engine = engine

    def run(self) -> None:
        try:
            self.finished_ok.emit(self.engine.online_update())
        except Exception:
            self.failed.emit(traceback.format_exc(limit=4))


class ImportWorker(QThread):
    """Imports a dataset file into the memory database."""

    finished_ok = Signal(dict)
    failed = Signal(str)

    def __init__(self, engine: AxonEngine, paths: Sequence[str]) -> None:
        super().__init__()
        self.engine = engine
        self.paths = list(paths)

    def run(self) -> None:
        try:
            total = {"pairs_imported": 0, "documents_seen": 0}
            for p in self.paths:
                info = self.engine.import_dataset(p)
                total["pairs_imported"] += info["pairs_imported"]
                total["documents_seen"] += info["documents_seen"]
            self.finished_ok.emit(total)
        except Exception:
            self.failed.emit(traceback.format_exc(limit=4))
