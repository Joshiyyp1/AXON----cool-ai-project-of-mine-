"""Spotting replies that have fallen apart.

A small model sometimes emits token soup: `POFHThe`, `LNTOSGPh`, `BDL-BOShtha`.
That on its own is survivable - the problem is what happens next. The reply is
written into the conversation history, the history goes into the next prompt,
and the model happily continues the pattern. One bad reply becomes ten.

So AXON checks its own output. Replies that look like token soup are kept out
of the prompt history and are never used as training data.

The test is deliberately narrow: real English almost never puts a capital
letter in the middle of a word. Ordinary bad answers ("the sky is a dog") are
NOT flagged - only text that has stopped being words at all.
"""
from __future__ import annotations

import re

WORD = re.compile(r"[A-Za-z][A-Za-z'-]*")

# Words that legitimately carry an inner capital, so they are not evidence.
_ALLOWED = {
    "iphone", "ipad", "ipod", "imac", "youtube", "javascript", "github",
    "mcdonald", "mcdonalds", "macbook", "openai", "pytorch", "axon", "vesper",
}


def _inner_capital(word: str) -> bool:
    """True when a capital appears after the first character, e.g. 'POFHThe'."""
    if len(word) < 3 or word.lower() in _ALLOWED:
        return False
    if word.isupper():          # a fully upper-case run: SHOUTING or an acronym
        return len(word) > 4    # short acronyms (USA, NASA) are fine
    return any(c.isupper() for c in word[1:])


def degeneracy(text: str) -> float:
    """Fraction of real words that look like token soup. 0.0 = clean."""
    words = [w for w in WORD.findall(text or "") if len(w) >= 3]
    if len(words) < 4:          # too short to judge fairly
        return 0.0
    return sum(_inner_capital(w) for w in words) / len(words)


def stray_capitals(text: str) -> float:
    """Fraction of words that are capitalised where no name belongs.

    The other way this model falls apart is inventing proper nouns -
    'Winar, Tone, Stog, Stayen, Rurer' - which are shaped like words but are
    not any. Real sentences carry a few names; these carry almost nothing else.
    """
    tokens = list(WORD.finditer(text or ""))
    if len(tokens) < 5:
        return 0.0

    stray = counted = 0
    for i, match in enumerate(tokens):
        word = match.group()
        if word == "I" or len(word) < 2:
            continue
        # is this the first word of a sentence?
        before = text[: match.start()].rstrip(" \"'([")
        if i == 0 or (before and before[-1] in ".!?:;"):
            continue
        counted += 1
        if word[0].isupper():
            stray += 1
    return stray / counted if counted else 0.0


def looks_degenerate(text: str, threshold: float = 0.18) -> bool:
    """Has this reply stopped being English?"""
    if not text or not text.strip():
        return False
    if degeneracy(text) >= threshold:
        return True
    if stray_capitals(text) >= 0.35:
        return True

    # A wall of capitals with almost no lower case is the other failure mode.
    letters = [c for c in text if c.isalpha()]
    if len(letters) >= 20:
        upper = sum(c.isupper() for c in letters) / len(letters)
        if upper > 0.45:
            return True
    return False
