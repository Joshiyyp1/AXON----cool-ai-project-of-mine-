"""AxonEngine - the piece that ties tokenizer + model + memory together.

Both the GUI and the CLI drive this class; it owns the model, the device, the
SQLite memory and the online learner, and it is safe to call from a worker
thread (a re-entrant lock guards the model).
"""
from __future__ import annotations

import threading
import time
from pathlib import Path
from typing import Callable, Dict, Iterator, List, Optional, Sequence, Tuple

import torch

from axon.config import (
    GenerationConfig,
    ModelConfig,
    OnlineConfig,
    Paths,
    TrainConfig,
)
from axon.dataset import (
    DEFAULT_SYSTEM,
    build_chat_prompt,
    build_datasets,
    corpus_texts,
    gather_corpus,
)
from axon.memory import Memory
from axon.model import AxonTransformer, device_description, pick_device
from axon.quality import looks_degenerate
from axon.tokenizer import BOS, EOS, EOT, PAD, SYS, USER, BPETokenizer
from axon.trainer import (
    OnlineLearner,
    Trainer,
    load_checkpoint,
    save_checkpoint,
)


class AxonEngine:
    """High-level API: `respond()`, `train_on()`, `save()`, `load()`."""

    def __init__(
        self,
        checkpoint: Optional[str | Path] = None,
        db_path: Optional[str | Path] = None,
        device: str = "auto",
        generation: Optional[GenerationConfig] = None,
        online: Optional[OnlineConfig] = None,
        system_prompt: str = DEFAULT_SYSTEM,
        log: Optional[Callable[[str], None]] = None,
    ) -> None:
        Paths.ensure()
        self.log = log or (lambda msg: print(f"[axon] {msg}"))
        self.device = pick_device(device)
        self.memory = Memory(db_path or Paths.DB)
        self.generation = generation or GenerationConfig()
        self.online_cfg = online or OnlineConfig()
        self.system_prompt = system_prompt
        self.checkpoint_path = Path(checkpoint or Paths.DEFAULT_CHECKPOINT)

        self.model: Optional[AxonTransformer] = None
        self.tokenizer: Optional[BPETokenizer] = None
        self.meta: Dict = {}
        self._lock = threading.RLock()
        self._online: Optional[OnlineLearner] = None
        self._pending_since_update = 0

        self.conversation_id: Optional[int] = None

    # ------------------------------------------------------------------ #
    # status
    # ------------------------------------------------------------------ #
    @property
    def ready(self) -> bool:
        return self.model is not None and self.tokenizer is not None

    def device_name(self) -> str:
        return device_description(self.device)

    def status(self) -> Dict[str, object]:
        s: Dict[str, object] = {
            "device": self.device_name(),
            "checkpoint": str(self.checkpoint_path),
            "loaded": self.ready,
            **self.memory.stats(),
        }
        if self.ready:
            cfg = self.model.cfg
            s.update(
                parameters=self.model.num_parameters(),
                vocab_size=cfg.vocab_size,
                block_size=cfg.block_size,
                layers=cfg.n_layer,
                heads=cfg.n_head,
                width=cfg.n_embd,
                trained_steps=self.meta.get("step", 0),
                val_loss=self.meta.get("val_loss"),
            )
        return s

    # ------------------------------------------------------------------ #
    # model lifecycle
    # ------------------------------------------------------------------ #
    def load(self, path: Optional[str | Path] = None) -> bool:
        path = Path(path or self.checkpoint_path)
        if not path.exists():
            self.log(f"No checkpoint at {path}")
            return False
        with self._lock:
            model, tokenizer, meta = load_checkpoint(path, device=self.device)
            model.eval()
            self.model, self.tokenizer, self.meta = model, tokenizer, meta
            self.checkpoint_path = path
            self._online = None
        self.log(
            f"Loaded {path.name}: {model.num_parameters():,} params, "
            f"vocab {tokenizer.vocab_size:,}, step {meta.get('step', 0):,}"
        )
        return True

    def save(self, path: Optional[str | Path] = None) -> Path:
        if not self.ready:
            raise RuntimeError("Nothing to save - no model in memory.")
        path = Path(path or self.checkpoint_path)
        with self._lock:
            save_checkpoint(
                path, self.model, self.tokenizer,
                step=int(self.meta.get("step", 0)),
                epoch=int(self.meta.get("epoch", 0)),
                val_loss=self.meta.get("val_loss"),
            )
        self.checkpoint_path = path
        self.log(f"Saved checkpoint -> {path}")
        return path

    def build_new_model(
        self,
        corpus_paths: Sequence[str | Path] = (),
        model_config: Optional[ModelConfig] = None,
        vocab_size: int = 8192,
        include_memory: bool = True,
        progress: Optional[Callable[[int, int, str], None]] = None,
    ) -> Dict[str, int]:
        """Train a fresh tokenizer on the corpus and initialise a new model."""
        paths = list(corpus_paths)
        if not paths:
            paths = [p for p in (Paths.SEED_DIALOGUES, Paths.SEED_CORPUS) if Path(p).exists()]
        corpus = gather_corpus(paths, memory=self.memory, include_memory=include_memory)
        texts = corpus_texts(corpus, system=self.system_prompt)
        if not texts:
            raise ValueError("No training text found. Add .txt/.json files to data/ first.")

        self.log(f"Training tokenizer on {len(texts):,} documents...")
        tokenizer = BPETokenizer().train(texts, vocab_size=vocab_size, progress=progress)
        self.log(f"Tokenizer ready: {tokenizer.vocab_size:,} tokens")

        cfg = model_config or ModelConfig()
        cfg.vocab_size = tokenizer.vocab_size
        model = AxonTransformer(cfg).to(self.device)
        model.eval()

        with self._lock:
            self.tokenizer = tokenizer
            self.model = model
            self.meta = {"step": 0, "epoch": 0, "val_loss": None}
            self._online = None

        self.log(f"New model: {model.num_parameters():,} parameters on {self.device_name()}")
        return {
            "parameters": model.num_parameters(),
            "vocab_size": tokenizer.vocab_size,
            "pairs": len(corpus["pairs"]),
            "documents": len(corpus["docs"]),
        }

    def ensure_model(self, **kwargs) -> None:
        """Load the checkpoint if present, otherwise build a fresh model."""
        if self.ready:
            return
        if not self.load():
            self.build_new_model(**kwargs)

    # ------------------------------------------------------------------ #
    # conversations
    # ------------------------------------------------------------------ #
    def start_conversation(self, title: Optional[str] = None) -> int:
        self.conversation_id = self.memory.new_conversation(title or "New chat")
        return self.conversation_id

    def open_conversation(self, conv_id: int) -> List:
        self.conversation_id = conv_id
        return self.memory.get_messages(conv_id)

    def _history_pairs(self, turns: int = 6) -> List[Tuple[str, str]]:
        if self.conversation_id is None:
            return []
        msgs = self.memory.last_messages(self.conversation_id, n=turns * 2)
        # A reply that came out as token soup must not go back into the prompt:
        # the model would read its own noise and produce more of it.
        return [
            (m.role, m.content) for m in msgs
            if m.role in ("user", "bot")
            and not (m.role == "bot" and looks_degenerate(m.content))
        ]

    def _memory_block(self, user_message: str, use_memory: bool) -> Optional[str]:
        if not use_memory:
            return None
        facts = self.memory.relevant_facts(user_message, limit=6)
        if not facts:
            return None
        return " ".join(f"{k.split('.')[-1].replace('_', ' ')}: {v}." for k, v in facts)

    def build_prompt(self, user_message: str, use_memory: bool = True,
                     history_turns: int = 6) -> str:
        return build_chat_prompt(
            user_message,
            history=self._history_pairs(history_turns),
            system=self.system_prompt,
            memory=self._memory_block(user_message, use_memory),
        )

    # ------------------------------------------------------------------ #
    # generation
    # ------------------------------------------------------------------ #
    def _prompt_tensor(self, prompt: str) -> torch.Tensor:
        ids = self.tokenizer.encode(prompt)
        max_ctx = self.model.cfg.block_size - 8
        if len(ids) > max_ctx:
            ids = ids[-max_ctx:]
        return torch.tensor([ids], dtype=torch.long, device=self.device)

    def stream(
        self,
        user_message: str,
        use_memory: bool = True,
        generation: Optional[GenerationConfig] = None,
        should_stop: Optional[Callable[[], bool]] = None,
    ) -> Iterator[str]:
        """Yield decoded text fragments as the model generates them."""
        if not self.ready:
            raise RuntimeError("No model loaded.")
        gen = generation or self.generation
        prompt = self.build_prompt(user_message, use_memory=use_memory)

        generator = None
        if gen.seed is not None and gen.seed >= 0:
            generator = torch.Generator(device=self.device).manual_seed(int(gen.seed))

        tok = self.tokenizer
        stop_ids = [tok.special_id(EOT), tok.special_id(EOS), tok.pad_id]
        banned = [tok.special_id(BOS), tok.special_id(SYS), tok.special_id(USER)]

        with self._lock:
            idx = self._prompt_tensor(prompt)
            pending: List[int] = []
            for token_id in self.model.generate_stream(
                idx,
                max_new_tokens=gen.max_new_tokens,
                temperature=gen.temperature,
                top_k=gen.top_k,
                top_p=gen.top_p,
                repetition_penalty=gen.repetition_penalty,
                presence_penalty=gen.presence_penalty,
                stop_ids=stop_ids,
                banned_ids=banned,
                generator=generator,
                should_stop=should_stop,
            ):
                pending.append(token_id)
                text = tok.decode(pending, skip_special=True)
                # an incomplete UTF-8 sequence decodes to U+FFFD: wait for the rest,
                # but never buffer forever if the bytes are genuinely invalid
                if "�" in text and len(pending) < 8:
                    continue
                pending = []
                if text:
                    yield text
            if pending:
                text = tok.decode(pending, skip_special=True)
                if text:
                    yield text

    def respond(self, user_message: str, **kwargs) -> str:
        return "".join(self.stream(user_message, **kwargs)).strip()

    # ------------------------------------------------------------------ #
    # learning from chat
    # ------------------------------------------------------------------ #
    def record_exchange(
        self, user_message: str, reply: str, rating: int = 0, learn: bool = True
    ) -> Dict[str, object]:
        """Persist a turn: message log, extracted facts, and a training sample."""
        if self.conversation_id is None:
            self.start_conversation()
        self.memory.add_message(self.conversation_id, "user", user_message)
        self.memory.add_message(self.conversation_id, "bot", reply)

        facts = self.memory.extract_facts(user_message)

        # Broken output is stored (so you can see it) but marked bad, so it can
        # never be trained on and never poisons a later run.
        auto_rejected = rating == 0 and looks_degenerate(reply)
        if auto_rejected:
            rating = -1
        sample_id = self.memory.add_sample(user_message, reply, source="chat", rating=rating)

        # name the conversation after its first user message
        msgs = self.memory.get_messages(self.conversation_id, limit=3)
        if len(msgs) <= 2:
            title = user_message.strip().replace("\n", " ")[:48] or "New chat"
            self.memory.rename_conversation(self.conversation_id, title)

        result: Dict[str, object] = {
            "sample_id": sample_id, "facts": facts, "online_loss": None,
            "auto_rejected": auto_rejected,
        }

        if learn and self.online_cfg.enabled and rating >= 0:
            self._pending_since_update += 1
            if self._pending_since_update >= max(1, self.online_cfg.every_n_exchanges):
                self._pending_since_update = 0
                result["online_loss"] = self.online_update()
        return result

    def online_update(self, extra_pairs: Sequence[Tuple[str, str]] = ()) -> Optional[float]:
        """Replay recent exchanges through the model at a low learning rate."""
        if not self.ready:
            return None
        cfg = self.online_cfg
        # Only replay exchanges a human approved. Training on the model's own
        # unreviewed replies feeds its mistakes back into the weights.
        samples = self.memory.recent_samples(n=cfg.recent_window, min_rating=cfg.min_rating)
        pairs: List[Tuple[str, str]] = [(s.prompt, s.response) for s in samples]
        pairs.extend(extra_pairs)
        if not pairs:
            return None

        lr = cfg.safe_learning_rate()
        if lr != cfg.learning_rate:
            self.log(f"Online learning rate clamped from {cfg.learning_rate:g} to {lr:g}")

        with self._lock:
            if self._online is None:
                self._online = OnlineLearner(self.model, self.tokenizer, self.device, lr)
            self._online.set_learning_rate(lr)
            loss = self._online.update(
                pairs, steps=cfg.steps, batch_size=cfg.batch_size
            )
            self.model.eval()
        if loss is not None:
            self.meta["step"] = int(self.meta.get("step", 0)) + cfg.steps
            self.log(f"Online update: loss {loss:.4f} over {len(pairs)} recent samples")
        return loss

    # ------------------------------------------------------------------ #
    # full training
    # ------------------------------------------------------------------ #
    def train_on(
        self,
        paths: Sequence[str | Path] = (),
        train_config: Optional[TrainConfig] = None,
        include_memory: bool = True,
        checkpoint: Optional[str | Path] = None,
        on_log: Optional[Callable[[str], None]] = None,
        on_progress: Optional[Callable] = None,
        should_stop: Optional[Callable[[], bool]] = None,
        min_rating: int = 0,
        max_pairs: int = 0,
        max_prompt_chars: int = 0,
        max_response_chars: int = 0,
        max_docs: int = 0,
    ) -> Dict[str, object]:
        """Run a full training pass over files plus stored conversations."""
        if not self.ready:
            raise RuntimeError("No model loaded - build or load one first.")
        cfg = train_config or TrainConfig()
        log = on_log or self.log

        corpus = gather_corpus(
            paths, memory=self.memory, include_memory=include_memory, min_rating=min_rating,
            max_pairs=max_pairs, max_prompt_chars=max_prompt_chars,
            max_response_chars=max_response_chars, max_docs=max_docs,
        )
        train_set, val_set, stats = build_datasets(
            corpus, self.tokenizer, self.model.cfg.block_size, val_split=cfg.val_split
        )
        log(
            f"Corpus: {stats['pairs']:,} pairs, {stats['documents']:,} documents "
            f"-> {stats['total_examples']:,} training examples"
        )
        if len(train_set) == 0:
            raise ValueError("Nothing to train on. Add data files or chat a bit first.")

        with self._lock:
            trainer = Trainer(
                self.model, self.tokenizer, self.device, cfg,
                checkpoint_path=checkpoint or self.checkpoint_path,
                on_log=log, on_progress=on_progress, should_stop=should_stop,
            )
            result = trainer.train(train_set, val_set)
            self.model.eval()
            self._online = None      # optimizer state is stale after full training

        self.meta["step"] = int(self.meta.get("step", 0)) + int(result["steps"])
        self.meta["val_loss"] = result["val_loss"]
        result.update(stats)
        result["history"] = trainer.history
        return result

    # ------------------------------------------------------------------ #
    def import_dataset(self, path: str | Path, min_rating: int = 0) -> Dict[str, int]:
        """Load a dataset file into the memory database as training samples."""
        from axon.dataset import load_path

        pairs, docs = load_path(path)
        n = self.memory.add_samples(pairs, source="import")
        return {"pairs_imported": n, "documents_seen": len(docs)}

    def close(self) -> None:
        self.memory.close()
