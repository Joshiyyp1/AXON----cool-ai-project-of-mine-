"""Terminal chat with AXON - the same engine the GUI uses, without Qt.

    python chat.py
    python chat.py --temperature 0.7 --no-learn

Commands inside the chat:
    /new          start a new conversation
    /memory       list stored facts
    /remember k v store a fact by hand
    /forget k     delete a fact
    /learn        run an online learning update now
    /save         save a checkpoint
    /stats        show model + memory statistics
    /quit         exit
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from axon.config import GenerationConfig, Paths  # noqa: E402
from axon.engine import AxonEngine  # noqa: E402


def _utf8_console() -> None:
    """Windows consoles default to cp1252 and crash on model output. Fix that."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Chat with AXON in the terminal.")
    p.add_argument("--checkpoint", default=str(Paths.DEFAULT_CHECKPOINT))
    p.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])
    p.add_argument("--temperature", type=float, default=0.9)
    p.add_argument("--top-k", type=int, default=50)
    p.add_argument("--top-p", type=float, default=0.92)
    p.add_argument("--repetition-penalty", type=float, default=1.15)
    p.add_argument("--max-new-tokens", type=int, default=200)
    p.add_argument("--no-memory", action="store_true", help="do not inject stored facts")
    p.add_argument("--no-learn", action="store_true", help="do not learn from this session")
    return p.parse_args()


def main() -> int:
    _utf8_console()
    args = parse_args()
    engine = AxonEngine(
        checkpoint=args.checkpoint,
        device=args.device,
        generation=GenerationConfig(
            max_new_tokens=args.max_new_tokens,
            temperature=args.temperature,
            top_k=args.top_k,
            top_p=args.top_p,
            repetition_penalty=args.repetition_penalty,
        ),
    )
    print(f"AXON - device: {engine.device_name()}")
    if not engine.load(args.checkpoint):
        print("No checkpoint found. Build one first:  python train.py --new --epochs 20")
        return 1

    s = engine.status()
    print(f"{s['parameters']:,} parameters, vocab {s['vocab_size']:,}, "
          f"context {s['block_size']} tokens, {s['trained_steps']:,} trained steps")
    print("Type /quit to exit, /help for commands.\n")
    engine.start_conversation("terminal session")

    while True:
        try:
            message = input("you > ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not message:
            continue

        if message.startswith("/"):
            parts = message.split(maxsplit=2)
            cmd = parts[0].lower()
            if cmd in ("/quit", "/exit"):
                break
            if cmd == "/help":
                print(__doc__)
            elif cmd == "/new":
                engine.start_conversation()
                print("(new conversation)")
            elif cmd == "/memory":
                for row in engine.memory.list_facts():
                    print(f"  {row['key']:<24} {row['value']}")
            elif cmd == "/remember" and len(parts) >= 3:
                engine.memory.upsert_fact(parts[1], parts[2], source="manual")
                print(f"(stored {parts[1]})")
            elif cmd == "/forget" and len(parts) >= 2:
                engine.memory.delete_fact(parts[1])
                print(f"(deleted {parts[1]})")
            elif cmd == "/learn":
                loss = engine.online_update()
                print(f"(online loss: {loss:.4f})" if loss else "(nothing to learn from yet)")
            elif cmd == "/save":
                engine.save()
            elif cmd == "/stats":
                for k, v in engine.status().items():
                    print(f"  {k:<16} {v}")
            else:
                print("(unknown command - try /help)")
            continue

        print("axon> ", end="", flush=True)
        pieces = []
        for chunk in engine.stream(message, use_memory=not args.no_memory):
            pieces.append(chunk)
            print(chunk, end="", flush=True)
        print("\n")

        reply = "".join(pieces).strip() or "(no output - the model needs more training)"
        info = engine.record_exchange(message, reply, learn=not args.no_learn)
        if info.get("facts"):
            print(f"(remembered: {info['facts']})\n")
        if info.get("online_loss"):
            print(f"(online update, loss {info['online_loss']:.4f})\n")

    engine.close()
    print("bye.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
