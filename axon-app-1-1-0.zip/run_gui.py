"""Launch the AXON desktop app.

    python run_gui.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def main() -> int:
    try:
        from axon.gui.app import main as gui_main
    except ImportError as exc:
        print("Failed to import the GUI. Are the dependencies installed?")
        print("    pip install -r requirements.txt")
        print(f"\nOriginal error: {exc}")
        return 1
    return gui_main()


if __name__ == "__main__":
    raise SystemExit(main())
